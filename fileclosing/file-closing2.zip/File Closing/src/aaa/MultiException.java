package aaa;

import java.util.Collections;
import java.util.List;

public class MultiException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private List<Throwable> causes;
    public MultiException(List<Throwable> causes) {
        super(causes.get(0));
        this.causes = causes;
    }
    public MultiException(String message, List<Throwable> causes) {
        super(message, causes.get(0));
        this.causes = causes;
    }
    public List<Throwable> getCauses() {
        return Collections.unmodifiableList(causes);
    }
}
