package aaa;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public abstract class AutoFileCloser<WrapperExceptionType extends Throwable> {
    protected abstract void doWork() throws WrapperExceptionType;
    private List<Closeable> streams = new ArrayList<Closeable>();
    protected final <T extends Closeable> T watch(T closeable) {
        streams.add(closeable);
        return closeable;
    }
    protected abstract WrapperExceptionType wrap(Throwable t);
    public AutoFileCloser(Class<WrapperExceptionType> wrapperExceptionType) throws WrapperExceptionType {
		Throwable pending = null;
        try {
            doWork();
        } catch (ThreadDeath t) {
            throw t;
        } catch (Throwable t) {
            pending = t;
        } finally {
            for (Closeable c : streams) {
                try {
                    c.close();
                } catch (IOException e) {
                    // report and/or log error
                    if (pending == null)
                        pending = e;
                }
            }
            if (pending != null)
                if (wrapperExceptionType.isAssignableFrom(pending.getClass()))
                    throw wrapperExceptionType.cast(pending);
                else
                    throw wrap(pending);
        }

    }
public static abstract class AutoFileCloserThrowsOops extends AutoFileCloser<OopsException> {
    public AutoFileCloserThrowsOops() {
        super(OopsException.class);
    }
    @Override protected OopsException wrap(Throwable t) {
        return new OopsException(t);
    }
}


public static void main(String[] args) {
}    
}



