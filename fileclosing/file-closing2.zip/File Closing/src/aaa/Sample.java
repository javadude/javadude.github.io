//*****************************************************************************/
/*                              COPYRIGHT NOTICE                              */
/* Copyright (c) 2009 The Johns Hopkins University/Applied Physics Laboratory */
/*                            All rights reserved.                            */
/*                                                                            */
/* This material may only be used, modified, or reproduced by or for the      */
/* U.S. Government pursuant to the license rights granted under FAR clause    */
/* 52.227-14 or DFARS clauses 252.227-7013/7014.                              */
/*                                                                            */
/* For any other permissions, please contact the Legal Office at JHU/APL.     */
//*****************************************************************************/

package aaa;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Scott Stanchfield
 *
 */
public class Sample {
	private static Closeable WRAPPER;
	private static Closeable NESTEDSTREAM;
	public static void main(String[] args) {
List<Closeable> streams = new ArrayList<Closeable>();
Throwable pending = null;
try {
    // VARIANT: OPEN AND DO STUFF WITH THE STREAMS � STORE EACH STREAM IN streams LIST
} catch (ThreadDeath t) {
    throw t;
} catch (Throwable t) {
    pending = t;
} finally {
    for (Closeable c : streams) {
        try {
            c.close();
            break;
        } catch (IOException e) {
            // report and/or log error
            if (pending == null)
                pending = e;
        }
    }
    if (pending != null)
        if (pending instanceof SomeWrapperException)
            throw (SomeWrapperException) pending;
        else
            throw new SomeWrapperException(pending);
}
	}
}
