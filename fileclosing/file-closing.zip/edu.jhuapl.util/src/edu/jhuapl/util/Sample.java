//*****************************************************************************/
/*                              COPYRIGHT NOTICE                              */
/* Copyright (c) 2009 The Johns Hopkins University/Applied Physics Laboratory */
/*                            All rights reserved.                            */
/*                                                                            */
/* This material may only be used, modified, or reproduced by or for the      */
/* U.S. Government pursuant to the license rights granted under FAR clause    */
/* 52.227-14 or DFARS clauses 252.227-7013/7014.                              */
/*                                                                            */
/* For any other permissions, please contact the Legal Office at JHU/APL.     */
//*****************************************************************************/

package edu.jhuapl.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * Sample usage of the AutoFileCloser
 * @author Scott Stanchfield
 */
public class Sample {
	public static void main(String[] args) {
		try {
			// example where we don't need to return a value
			// example of copying lines from one file to another
			//   (inefficient, but useful example of AutoFileCloser
			new AutoFileCloser() {
				@Override protected void doWork() throws Throwable {
					FileReader fr     = watch(new FileReader("foo.txt"));
					BufferedReader br = watch(new BufferedReader(fr));
					FileWriter fw     = watch(new FileWriter("fee.txt"));
					BufferedWriter bw = watch(new BufferedWriter(fw));
					PrintWriter pw    = watch(new PrintWriter(bw));
					String line;
					while ((line = br.readLine()) != null) {
						pw.println(line);
					}
				}
			};
		} catch (MultiException e) {
			System.out.println("Multi");
			e.printStackTrace();
			for (Throwable t : e.getCauses()) {
				System.out.println("!!!Cause");
				t.printStackTrace();
			}
		}

		// example where we need to return a value
		// example of copying lines from one file to another
		//   (inefficient, but useful example of AutoFileCloser
		AutoFileCloser afc = new AutoFileCloser() {
			@Override protected void doWork() throws Throwable {
				FileReader fr     = watch(new FileReader("foo.txt"));
				BufferedReader br = watch(new BufferedReader(fr));
				FileWriter fw     = watch(new FileWriter("fee.txt"));
				BufferedWriter bw = watch(new BufferedWriter(fw));
				PrintWriter pw    = watch(new PrintWriter(bw));
				String line;
				while ((line = br.readLine()) != null) {
					pw.println(line);
				}
				setResult("foo");
			}
		};

		System.out.println(afc.getResult());
	}
}
