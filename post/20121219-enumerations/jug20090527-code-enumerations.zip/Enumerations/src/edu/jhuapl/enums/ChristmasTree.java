//*****************************************************************************/
/*                              COPYRIGHT NOTICE                              */
/* Copyright (c) 2009 The Johns Hopkins University/Applied Physics Laboratory */
/*                            All rights reserved.                            */
/*                                                                            */
/* This material may only be used, modified, or reproduced by or for the      */
/* U.S. Government pursuant to the license rights granted under FAR clause    */
/* 52.227-14 or DFARS clauses 252.227-7013/7014.                              */
/*                                                                            */
/* For any other permissions, please contact the Legal Office at JHU/APL.     */
//*****************************************************************************/

package edu.jhuapl.enums;

/**
 * @author Scott Stanchfield
 *
 */
public class ChristmasTree {
	@SuppressWarnings("unused")
	private enum MyStates implements State {
		// Current						Event		Action			Next State
		Unlit {
			@Override public MyStates 	water() 	{/*fireHeat();*/	return Wet;}
			@Override public MyStates 	heat() 		{				return Burning;}
			@Override public MyStates 	eOn() 		{				return Lit;}
		}
		,
		Lit {
			@Override public MyStates 	water() 	{				return Burnt;}
			@Override public MyStates 	heat() 		{				return Burning;}
			@Override public MyStates 	eOff() 		{				return Unlit;}
		},
		Wet, // similar...
		Burning, // similar...
		Burnt; // similar...
		public MyStates water() {return this;}
		public MyStates heat() {return this;}
		public MyStates eOn() {return this;}
		public MyStates eOff() {return this;}
		public MyStates pulse() {return this;}
	}
	private State state;
	public void transition(State.Methods m) {
		state = m.invoke(state);
	}
}