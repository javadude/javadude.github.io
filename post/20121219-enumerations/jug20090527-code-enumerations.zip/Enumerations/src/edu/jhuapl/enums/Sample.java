//*****************************************************************************/
/*                              COPYRIGHT NOTICE                              */
/* Copyright (c) 2009 The Johns Hopkins University/Applied Physics Laboratory */
/*                            All rights reserved.                            */
/*                                                                            */
/* This material may only be used, modified, or reproduced by or for the      */
/* U.S. Government pursuant to the license rights granted under FAR clause    */
/* 52.227-14 or DFARS clauses 252.227-7013/7014.                              */
/*                                                                            */
/* For any other permissions, please contact the Legal Office at JHU/APL.     */
//*****************************************************************************/

package edu.jhuapl.enums;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;
import java.util.Set;

/**
 * @author Scott Stanchfield
 *
 */
public class Sample {

	public enum Flags {
		POPUP, PUSH, CHECK;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		Set<Flags> flags = EnumSet.of(Flags.POPUP, Flags.CHECK);
		@SuppressWarnings("unused")
		Map<Suit, String> suitName = new EnumMap<Suit, String>(Suit.class);
		
		Card card = new Card(2, Suit.Diamonds);
		if (card.getSuit() == Suit.Diamonds) {}
		switch (card.getSuit()) {
			case Clubs:
				
			case Diamonds:
			case Hearts:
			case Spades:
		}
		System.out.println(card.getSuit().ordinal());
		System.out.println(card.getSuit().name());
		System.out.println(card.getSuit().getValue());
		System.out.println(Suit.valueOf("Spades").getValue());
		ChristmasTree tree = new ChristmasTree();
		tree.transition(State.Methods.eOff);
	}
	
}
