//*****************************************************************************/
/*                              COPYRIGHT NOTICE                              */
/* Copyright (c) 2009 The Johns Hopkins University/Applied Physics Laboratory */
/*                            All rights reserved.                            */
/*                                                                            */
/* This material may only be used, modified, or reproduced by or for the      */
/* U.S. Government pursuant to the license rights granted under FAR clause    */
/* 52.227-14 or DFARS clauses 252.227-7013/7014.                              */
/*                                                                            */
/* For any other permissions, please contact the Legal Office at JHU/APL.     */
//*****************************************************************************/

package edu.jhuapl.enums;

/**
 * @author Scott Stanchfield
 *
 */
public interface State {
	public State water();
	public State heat();
	public State eOn();
	public State eOff();
	public State pulse();
	public enum Methods {
		water { @Override public State invoke(State s) { return s.water(); } },
		heat { @Override public State invoke(State s) { return s.heat(); } },
		eOn { @Override public State invoke(State s) { return s.eOn(); } },
		eOff { @Override public State invoke(State s) { return s.eOff(); } },
		pulse { @Override public State invoke(State s) { return s.pulse(); } };
		public abstract State invoke(State s);
	}
}
