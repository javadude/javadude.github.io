package com.javadude.dynamic.proxies;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class App {
	public static void main(String[] args) {
		doStuff(Factory.createTeller());
		doStuff(Factory.createLoggingTeller());
		doStuff(Factory.createDecoratedLoggingTeller(Factory.createTeller()));
		doStuff(Factory.createDynamicProxyLoggingTeller(Factory.createTeller()));
		doStuff(new PersonImpl());
		doStuff(Factory.createDynamicProxyLogger(new PersonImpl(), Person.class, Driver.class));
		doStuff(Factory.createDynamicBean(Person.class));
	}

	private static void doStuff(Person person) {
		person.addPropertyChangeListener(new PropertyChangeListener() {
			@Override public void propertyChange(PropertyChangeEvent evt) {
				System.out.println(evt.getPropertyName() + " changed from " + evt.getOldValue() + " to " + evt.getNewValue());
			}});
		System.out.println("------------------");
		person.setName("Scott");
		person.setAddress("123 Sesame");
		person.setPhone("867-5309");
		person.setFax("111-2222");
		person.setName(null);
//		((Driver)person).drive();
		System.out.println(person.getName());
		System.out.println(person.getAddress());
	}
	private static void doStuff(Teller teller) {
		System.out.println("------------------");
		teller.deposit(101, 100);
		teller.withdraw(101, 20);
		teller.transfer(101, 102, 50);
	}
}
