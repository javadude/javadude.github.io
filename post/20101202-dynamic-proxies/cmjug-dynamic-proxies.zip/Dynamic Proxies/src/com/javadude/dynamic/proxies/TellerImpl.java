package com.javadude.dynamic.proxies;

public class TellerImpl implements Teller {
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Teller#deposit(int, int)
	 */
	@Override
	public void deposit(int accountId, int amount) {
		// log
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Teller#withdraw(int, int)
	 */
	@Override
	public void withdraw(int accountId, int amount) {
		// log
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Teller#transfer(int, int, int)
	 */
	@Override
	public void transfer(int fromAccountId, int toAccountId, int amount) {
		// log
		deposit(toAccountId, amount);
		withdraw(fromAccountId, amount);
	}
}
