package com.javadude.dynamic.proxies;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Factory {
	public static boolean log = false;
	public static Teller createTeller() {
		Teller t = new TellerImpl();
		if (log)
			t = new TellerLoggingDecorator(t);
		return t;
	}
	public static Teller createLoggingTeller() {
		return new LoggingTellerImpl();
	}
	public static Teller createDecoratedLoggingTeller() {
		return new TellerLoggingDecorator(createTeller());
	}
	public static Teller createDecoratedLoggingTeller(Teller teller) {
		return new TellerLoggingDecorator(teller);
	}
	
	public static Teller createDynamicProxyLoggingTeller(final Teller teller) {
		// create a decorator that logs and calls the invoked method
		return (Teller) Proxy.newProxyInstance(Teller.class.getClassLoader(), 
				new Class<?>[] {Teller.class},
				new InvocationHandler() {
					@Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
						System.out.println(method.toGenericString() + " args: " + Arrays.toString(args));
						return method.invoke(teller, args);
					}
				});
	}
	@SuppressWarnings("unchecked")
	public static <T> T createDynamicProxyLogger(final Object object, Class<T> clazz, Class<?>... otherInterfaces) {
		Class<?>[] interfaces = new Class<?>[otherInterfaces.length+1];
		interfaces[0] = clazz;
		System.arraycopy(otherInterfaces, 0, interfaces, 1, otherInterfaces.length);
		
		// check that the object implements those interfaces
		// USE object.getClass().getInterfaces();
		
		// create a decorator that logs and calls the invoked method
		return (T) Proxy.newProxyInstance(object.getClass().getClassLoader(), 
				interfaces,
				new InvocationHandler() {
			@Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				System.out.println(method.toGenericString() + " args: " + Arrays.toString(args));
				return method.invoke(object, args);
			}
		});
	}
	
	private static final Method addPCLMethod;
	private static final Method removePCLMethod;
	static {
		try {
			addPCLMethod = PropertyChangeNotifier.class.getMethod("addPropertyChangeListener", PropertyChangeListener.class);
			removePCLMethod = PropertyChangeNotifier.class.getMethod("removePropertyChangeListener", PropertyChangeListener.class);
		} catch (Throwable t) {
			throw new ExceptionInInitializerError(t);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T createDynamicBean(Class<T> clazz) {
		Class<?>[] interfaces = {clazz};
		
		// create a decorator that logs and calls the invoked method
		return (T) Proxy.newProxyInstance(Factory.class.getClassLoader(), 
				interfaces,
				new InvocationHandler() {
			private PropertyChangeSupport pcs;
			
			private void addPropertyChangeListener( PropertyChangeListener listener) {
				pcs.addPropertyChangeListener(listener);
			}
			private void removePropertyChangeListener( PropertyChangeListener listener) {
				pcs.removePropertyChangeListener(listener);
			}
			private void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
				pcs.firePropertyChange(propertyName, oldValue, newValue);
			}
			private Map<String, Object> values = new HashMap<String, Object>();
			private void setValue(String name, Object value) {
				values.put(name, value);
			}
			private Object getValue(String name) {
				return values.get(name);
			}
			@Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				if (pcs == null)
					pcs = new PropertyChangeSupport(proxy);
				if (method.equals(addPCLMethod)) {
					addPropertyChangeListener((PropertyChangeListener)args[0]);
					return null;
				}
				if (method.equals(removePCLMethod)) {
					removePropertyChangeListener((PropertyChangeListener)args[0]);
					return null;
				}
				System.out.println("+++" + method.toGenericString() + " args: " + Arrays.toString(args));
				if (method.getParameterTypes().length == 0) {
					if (method.getName().startsWith("get") && method.getReturnType() != void.class) {
						String propertyName = getPropertyName(method.getName());
						return getValue(propertyName);
					}
				} else if (method.getParameterTypes().length == 1) {
					String propertyName = getPropertyName(method.getName());
					if (method.getName().startsWith("set") && method.getReturnType() == void.class) {
						boolean bound = method.isAnnotationPresent(Bound.class);
						if (method.isAnnotationPresent(NotNull.class))
							if (args[0] == null)
								throw new NullPointerException("Can't set property '" + propertyName + "' to null");
						Object oldValue = null;
						if (bound)
							oldValue = getValue(propertyName);
						setValue(propertyName, args[0]);
						if (bound)
							firePropertyChange(propertyName, oldValue, args[0]);
						return null;
					}
				}
				throw new UnsupportedOperationException(method.toGenericString());
			}
			private String getPropertyName(String name) {
				String result = String.valueOf(Character.toLowerCase(name.charAt(3)));
				if (name.length() > 4)
					result += name.substring(4);
				return result;
			}
		});
	}
	
}
