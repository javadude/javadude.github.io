package com.javadude.dynamic.proxies;

public interface Person extends PropertyChangeNotifier {
	String getName();

	@Bound @NotNull void setName(String name);
	String getAddress();
	@Bound void setAddress(String address);
	String getPhone();
	void setPhone(String phone);
	String getFax();
	@Bound void setFax(String fax);
}