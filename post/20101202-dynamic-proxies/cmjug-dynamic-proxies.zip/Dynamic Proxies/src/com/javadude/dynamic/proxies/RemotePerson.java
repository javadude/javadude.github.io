package com.javadude.dynamic.proxies;

import java.rmi.Remote;

@RemotesFor(Person.class)
public interface RemotePerson extends Remote {

}
