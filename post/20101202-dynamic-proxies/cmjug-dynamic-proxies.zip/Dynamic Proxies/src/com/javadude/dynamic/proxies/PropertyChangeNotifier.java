package com.javadude.dynamic.proxies;

import java.beans.PropertyChangeListener;

public interface PropertyChangeNotifier {
	public void addPropertyChangeListener(PropertyChangeListener changeListener);
	public void removePropertyChangeListener(PropertyChangeListener changeListener);
}
