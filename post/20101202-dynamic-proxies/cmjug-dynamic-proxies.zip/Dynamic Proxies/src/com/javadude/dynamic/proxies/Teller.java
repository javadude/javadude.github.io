package com.javadude.dynamic.proxies;

public interface Teller {

	void deposit(int accountId, int amount);

	void withdraw(int accountId, int amount);

	void transfer(int fromAccountId, int toAccountId, int amount);

}