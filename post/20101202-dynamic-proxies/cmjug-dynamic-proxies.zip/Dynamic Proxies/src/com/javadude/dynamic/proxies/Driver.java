package com.javadude.dynamic.proxies;

public interface Driver {

	public abstract void drive();

}