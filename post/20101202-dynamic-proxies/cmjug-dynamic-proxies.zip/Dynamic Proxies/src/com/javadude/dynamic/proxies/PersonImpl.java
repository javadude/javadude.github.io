package com.javadude.dynamic.proxies;

import java.beans.PropertyChangeListener;

public class PersonImpl implements Person, Driver {
	private String name;
	private String address;
	private String phone;
	private String fax;
	
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Driver#drive()
	 */
	@Override
	public void drive() {
		
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#getName()
	 */
	@Override
	public String getName() {
		return name;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#setName(java.lang.String)
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#getAddress()
	 */
	@Override
	public String getAddress() {
		return address;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#setAddress(java.lang.String)
	 */
	@Override
	public void setAddress(String address) {
		this.address = address;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#getPhone()
	 */
	@Override
	public String getPhone() {
		return phone;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#setPhone(java.lang.String)
	 */
	@Override
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#getFax()
	 */
	@Override
	public String getFax() {
		return fax;
	}
	/* (non-Javadoc)
	 * @see com.javadude.dynamic.proxies.Person#setFax(java.lang.String)
	 */
	@Override
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Override
	public void addPropertyChangeListener(PropertyChangeListener changeListener) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void removePropertyChangeListener(
			PropertyChangeListener changeListener) {
		// TODO Auto-generated method stub
		
	}
}
