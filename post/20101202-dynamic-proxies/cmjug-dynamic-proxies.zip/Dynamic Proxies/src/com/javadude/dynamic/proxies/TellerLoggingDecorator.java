package com.javadude.dynamic.proxies;

public class TellerLoggingDecorator implements Teller {
	private Teller teller;

	public TellerLoggingDecorator(Teller teller) {
		this.teller = teller;
	}

	public void deposit(int accountId, int amount) {
		System.out.println("deposit");
		teller.deposit(accountId, amount);
	}

	public void withdraw(int accountId, int amount) {
		System.out.println("withdraw");
		teller.withdraw(accountId, amount);
	}

	public void transfer(int fromAccountId, int toAccountId, int amount) {
		System.out.println("transfer");
		teller.transfer(fromAccountId, toAccountId, amount);
	}
	
}
