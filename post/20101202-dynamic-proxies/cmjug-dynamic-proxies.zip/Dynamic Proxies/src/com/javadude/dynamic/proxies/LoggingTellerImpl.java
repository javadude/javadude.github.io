package com.javadude.dynamic.proxies;

public class LoggingTellerImpl extends TellerImpl {

	@Override
	public void deposit(int accountId, int amount) {
		System.out.println("deposit");
		super.deposit(accountId, amount);
	}

	@Override
	public void withdraw(int accountId, int amount) {
		System.out.println("withdraw");
		super.withdraw(accountId, amount);
	}

	@Override
	public void transfer(int fromAccountId, int toAccountId, int amount) {
		System.out.println("transfer");
		super.transfer(fromAccountId, toAccountId, amount);
	}

}
