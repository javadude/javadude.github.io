package com.javadude.annotation.samples;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class UI extends JFrame {

	private final JButton addButton;
	private final JButton removeButton;
	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		new UI();
	}

	public UI() throws Throwable {
		setLayout(new FlowLayout());
		addButton = new JButton("add");
		removeButton = new JButton("remove");
		add(addButton);
		add(removeButton);
		UISetup.setup(this);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}

	@Action(field="addButton")
	public void add() {
		System.out.println("add");
	}
	@Action(field="removeButton")
	public void remove() {
		System.out.println("remove");
	}

}
