package com.javadude.annotation.samples;

public class Person {

}
