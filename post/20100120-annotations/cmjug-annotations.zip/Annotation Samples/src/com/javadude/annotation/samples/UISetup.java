package com.javadude.annotation.samples;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class UISetup {
	public static void setup(final Object o) throws Throwable {
		Class<?> c = o.getClass();
		// look at all methods in the class
		Method[] methods = c.getDeclaredMethods();
		for (final Method method : methods) {
			Action action = method.getAnnotation(Action.class);
			if (action == null) {
				continue;
			}
			String fieldName = action.field();
			Field field = c.getDeclaredField(fieldName);
			field.setAccessible(true);
			Object object = field.get(o);
			Method addALMethod = object.getClass().getMethod("addActionListener", ActionListener.class);
			addALMethod.invoke(object, new ActionListener() {
				@Override public void actionPerformed(ActionEvent e) {
					// call that method
					try {
						method.invoke(o);
					} catch (IllegalArgumentException e1) {
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						e1.printStackTrace();
					} catch (InvocationTargetException e1) {
						e1.printStackTrace();
					}
				}});
		}
		// for any methods with @Action
		//   lookup the field for that Action
		//   create an ActionListener that calls the method
		//   add the action listener to the field object
	}
}
