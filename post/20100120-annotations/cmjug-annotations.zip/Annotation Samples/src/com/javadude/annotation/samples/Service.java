package com.javadude.annotation.samples;

@GenerateRMI
public interface Service {

}
