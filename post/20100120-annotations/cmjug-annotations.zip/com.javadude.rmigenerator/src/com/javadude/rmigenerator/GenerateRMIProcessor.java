package com.javadude.rmigenerator;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;

import com.sun.mirror.apt.AnnotationProcessor;
import com.sun.mirror.apt.AnnotationProcessorEnvironment;
import com.sun.mirror.declaration.AnnotationMirror;
import com.sun.mirror.declaration.InterfaceDeclaration;
import com.sun.mirror.declaration.MethodDeclaration;
import com.sun.mirror.declaration.ParameterDeclaration;
import com.sun.mirror.declaration.TypeDeclaration;

public class GenerateRMIProcessor implements AnnotationProcessor {
	private final AnnotationProcessorEnvironment env;

	public GenerateRMIProcessor(AnnotationProcessorEnvironment env) {
		this.env = env;
	}

	@Override
	public void process() {
		Collection<TypeDeclaration> typeDeclarations = env.getTypeDeclarations();
		for (TypeDeclaration typeDeclaration : typeDeclarations) {
			Collection<AnnotationMirror> annotationMirrors = typeDeclaration.getAnnotationMirrors();
			for (AnnotationMirror annotationMirror : annotationMirrors) {
				if ("aaaa.GenerateRMI".equals(
						annotationMirror.getAnnotationType().getDeclaration().getQualifiedName())) {
					if (!(typeDeclaration instanceof InterfaceDeclaration)){
						env.getMessager().printError(annotationMirror.getPosition(),
								"GenerateRMI can only appear on interfaces");
					}

					String packageName = typeDeclaration.getPackage().getQualifiedName();
					String interfaceName = typeDeclaration.getSimpleName();
					try {
						PrintWriter writer = env.getFiler().createSourceFile(packageName + '.' + interfaceName + "RMI");
						writer.println("package " + packageName + ";");
						writer.println("");
						writer.println("@javax.annotation.Generated(value=\"" + getClass().getName() + "\", date=\"" + new Date() + "\", comments=\"DO NOT EDIT!!!!\")");
						writer.println("public interface " + interfaceName + "RMI extends java.rmi.Remote {");

						Collection<? extends MethodDeclaration> methods = typeDeclaration.getMethods();
						for (MethodDeclaration m : methods) {
							String decl = m.getReturnType() + " " + m.getSimpleName() + "(";
							boolean first = true;
							Collection<ParameterDeclaration> parameters = m.getParameters();
							for (ParameterDeclaration p : parameters) {
								if (!first) {
									decl += ", ";
								} else {
									first = false;
								}
								decl += p.getType().toString() + " " + p.getSimpleName();
							}
							writer.println("    " + decl + ") throws java.rmi.RemoteException;");
						}

						writer.println("}");
						writer.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
