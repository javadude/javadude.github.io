package coloredit;

import java.awt.Color;
import java.awt.Canvas;

/** A simple bean to test the color editors */
public class ColorBean extends Canvas {
  public Color getColor() {return getBackground();} 
  public void setColor(Color color) {setBackground(color);} 
}