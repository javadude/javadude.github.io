// $ANTLR 2.8.0rc1 (20050208): "xl2.g" -> "XLRecognizer.java"$

package com.javadude.xl2;

import java.io.*;

public interface XLRecognizerTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int LITERAL_program = 4;
	int IDENT = 5;
	int EQUALS = 6;
	int DOT = 7;
	int LITERAL_begin = 8;
	int LITERAL_end = 9;
	int LITERAL_var = 10;
	int COLON = 11;
	int BECOMES = 12;
	int SEMI = 13;
	int LITERAL_constant = 14;
	int COMMA = 15;
	int INTLIT = 16;
	int STRING_LITERAL = 17;
	int LITERAL_type = 18;
	int LITERAL_array = 19;
	int LBRACKET = 20;
	int DOTDOT = 21;
	int RBRACKET = 22;
	int LITERAL_of = 23;
	int LITERAL_record = 24;
	int LITERAL_Integer = 25;
	int LITERAL_Boolean = 26;
	int LITERAL_procedure = 27;
	int LPAREN = 28;
	int RPAREN = 29;
	int LITERAL_exit = 30;
	int LITERAL_when = 31;
	int LITERAL_return = 32;
	int LITERAL_if = 33;
	int LITERAL_then = 34;
	int LITERAL_elsif = 35;
	int LITERAL_else = 36;
	int LITERAL_while = 37;
	int LITERAL_loop = 38;
	int LITERAL_put = 39;
	int LITERAL_get = 40;
	int LITERAL_newLine = 41;
	int LITERAL_skipLine = 42;
	int LITERAL_not = 43;
	int PLUS = 44;
	int MINUS = 45;
	int TIMES = 46;
	int DIV = 47;
	int LITERAL_mod = 48;
	int NOT_EQUALS = 49;
	int GT = 50;
	int GTE = 51;
	int LT = 52;
	int LTE = 53;
	int LITERAL_and = 54;
	int LITERAL_or = 55;
	int COMMENT = 56;
	int DIGIT = 57;
	int CHARLIT = 58;
	int WS = 59;
}
