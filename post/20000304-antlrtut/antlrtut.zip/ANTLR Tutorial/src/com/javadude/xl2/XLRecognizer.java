// $ANTLR 2.8.0rc1 (20050208): "xl2.g" -> "XLRecognizer.java"$

package com.javadude.xl2;

import java.io.*;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;


public class XLRecognizer extends antlr.LLkParser       implements XLRecognizerTokenTypes
 {

  // Define a main
  public static void main(String[] args) {
    // Use a try/catch block for parser exceptions
    try {
      // if we have at least one command-line argument
      if (args.length > 0 ) {
        System.err.println("Parsing...");

        // for each directory/file specified on the command line
        for(int i=0; i< args.length;i++)
          doFile(new File(args[i])); // parse it
      }
      else
        System.err.println("Usage: java XLRecogizer <directory name>");

    }
    catch(Exception e) {
      System.err.println("exception: "+e);
      e.printStackTrace(System.err);   // so we can get stack trace
    }
  }


  // This method decides what action to take based on the type of
  //   file we are looking at
  public static void doFile(File f) throws Exception {
    // If this is a directory, walk each file/dir in that directory
    if (f.isDirectory()) {
      String files[] = f.list();
      for(int i=0; i < files.length; i++)
        doFile(new File(f, files[i]));
    }

    // otherwise, if this is a java file, parse it!
    else if ((f.getName().length()>5) &&
             f.getName().substring(f.getName().length()-3).equals(".xl")) {
      System.err.println("-------------------------------------------");
      System.err.println(f.getAbsolutePath());
      parseFile(new FileInputStream(f));
    }
  }

  // Here's where we do the real work...
  public static void parseFile(InputStream s) throws Exception {
    try {
      // Create a scanner that reads from the input stream passed to us
      XLLexer lexer = new XLLexer(s);

      // Create a parser that reads from the scanner
      XLRecognizer parser = new XLRecognizer(lexer);

      // start parsing at the compilationUnit rule
      parser.program();
    }
    catch (Exception e) {
      System.err.println("parser exception: "+e);
      e.printStackTrace();   // so we can get stack trace		
    }
  }

protected XLRecognizer(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public XLRecognizer(TokenBuffer tokenBuf) {
  this(tokenBuf,1);
}

protected XLRecognizer(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public XLRecognizer(TokenStream lexer) {
  this(lexer,1);
}

public XLRecognizer(ParserSharedInputState state) {
  super(state,1);
  tokenNames = _tokenNames;
}

	public final void program() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_program);
			match(IDENT);
			match(EQUALS);
			subprogramBody();
			match(DOT);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void subprogramBody() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			_loop4:
			do {
				if ((LA(1)==LITERAL_var||LA(1)==LITERAL_constant||LA(1)==LITERAL_type)) {
					basicDecl();
				}
				else {
					break _loop4;
				}
				
			} while (true);
			}
			{
			_loop6:
			do {
				if ((LA(1)==LITERAL_procedure)) {
					procedureDecl();
				}
				else {
					break _loop6;
				}
				
			} while (true);
			}
			match(LITERAL_begin);
			statementList();
			match(LITERAL_end);
			match(IDENT);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_1);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void basicDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_var:
			{
				varDecl();
				break;
			}
			case LITERAL_constant:
			{
				constDecl();
				break;
			}
			case LITERAL_type:
			{
				typeDecl();
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void procedureDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_procedure);
			match(IDENT);
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				formalParameters();
				break;
			}
			case EQUALS:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(EQUALS);
			subprogramBody();
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void statementList() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			if ((_tokenSet_4.member(LA(1)))) {
				statement();
				statementList();
			}
			else {
				boolean synPredMatched36 = false;
				if (((LA(1)==LITERAL_end))) {
					int _m36 = mark();
					synPredMatched36 = true;
					inputState.guessing++;
					try {
						{
						endStatement();
						}
					}
					catch (RecognitionException pe) {
						synPredMatched36 = false;
					}
					rewind(_m36);
					inputState.guessing--;
				}
				if ( synPredMatched36 ) {
					endStatement();
					statementList();
				}
				else if ((LA(1)==LITERAL_end||LA(1)==LITERAL_elsif||LA(1)==LITERAL_else)) {
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
			}
			catch (RecognitionException ex) {
				if (inputState.guessing==0) {
					reportError(ex);
					recover(ex,_tokenSet_5);
				} else {
				  throw ex;
				}
			}
		}
		
	public final void varDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_var);
			identList();
			match(COLON);
			typeName();
			{
			switch ( LA(1)) {
			case BECOMES:
			{
				match(BECOMES);
				constantValue();
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void constDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_constant);
			identList();
			match(COLON);
			typeName();
			match(BECOMES);
			constantValue();
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void typeDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_type);
			match(IDENT);
			match(EQUALS);
			{
			switch ( LA(1)) {
			case LITERAL_array:
			{
				arrayDecl();
				break;
			}
			case LITERAL_record:
			{
				recordDecl();
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void identList() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(IDENT);
			{
			_loop13:
			do {
				if ((LA(1)==COMMA)) {
					match(COMMA);
					match(IDENT);
				}
				else {
					break _loop13;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_6);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void typeName() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case IDENT:
			{
				match(IDENT);
				break;
			}
			case LITERAL_Integer:
			{
				match(LITERAL_Integer);
				break;
			}
			case LITERAL_Boolean:
			{
				match(LITERAL_Boolean);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_7);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void constantValue() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case INTLIT:
			{
				match(INTLIT);
				break;
			}
			case STRING_LITERAL:
			{
				match(STRING_LITERAL);
				break;
			}
			case IDENT:
			{
				match(IDENT);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void arrayDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_array);
			match(LBRACKET);
			integerConstant();
			match(DOTDOT);
			integerConstant();
			match(RBRACKET);
			match(LITERAL_of);
			typeName();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void recordDecl() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_record);
			{
			int _cnt21=0;
			_loop21:
			do {
				if ((LA(1)==IDENT)) {
					identList();
					match(COLON);
					typeName();
					match(SEMI);
				}
				else {
					if ( _cnt21>=1 ) { break _loop21; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt21++;
			} while (true);
			}
			match(LITERAL_end);
			match(LITERAL_record);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void integerConstant() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case INTLIT:
			{
				match(INTLIT);
				break;
			}
			case IDENT:
			{
				match(IDENT);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_10);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void formalParameters() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LPAREN);
			parameterSpec();
			{
			_loop27:
			do {
				if ((LA(1)==SEMI)) {
					match(SEMI);
					parameterSpec();
				}
				else {
					break _loop27;
				}
				
			} while (true);
			}
			match(RPAREN);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_11);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void parameterSpec() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_var:
			{
				match(LITERAL_var);
				break;
			}
			case IDENT:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			identList();
			match(COLON);
			typeName();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_12);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void statement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_exit:
			{
				exitStatement();
				break;
			}
			case LITERAL_return:
			{
				returnStatement();
				break;
			}
			case LITERAL_if:
			{
				ifStatement();
				break;
			}
			case LITERAL_while:
			case LITERAL_loop:
			{
				loopStatement();
				break;
			}
			case LITERAL_put:
			case LITERAL_get:
			case LITERAL_newLine:
			case LITERAL_skipLine:
			{
				ioStatement();
				break;
			}
			default:
				boolean synPredMatched33 = false;
				if (((LA(1)==IDENT))) {
					int _m33 = mark();
					synPredMatched33 = true;
					inputState.guessing++;
					try {
						{
						match(IDENT);
						{
						switch ( LA(1)) {
						case LPAREN:
						{
							match(LPAREN);
							break;
						}
						case SEMI:
						{
							match(SEMI);
							break;
						}
						default:
						{
							throw new NoViableAltException(LT(1), getFilename());
						}
						}
						}
						}
					}
					catch (RecognitionException pe) {
						synPredMatched33 = false;
					}
					rewind(_m33);
					inputState.guessing--;
				}
				if ( synPredMatched33 ) {
					procedureCallStatement();
				}
				else if ((LA(1)==IDENT)) {
					assignmentStatement();
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void exitStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_exit);
			match(LITERAL_when);
			expression();
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void returnStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_return);
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void ifStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_if);
			ifPart();
			match(LITERAL_end);
			match(LITERAL_if);
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void loopStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_while:
			{
				match(LITERAL_while);
				expression();
				break;
			}
			case LITERAL_loop:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(LITERAL_loop);
			statementList();
			match(LITERAL_end);
			match(LITERAL_loop);
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void ioStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_put:
			{
				match(LITERAL_put);
				match(LPAREN);
				expression();
				match(RPAREN);
				match(SEMI);
				break;
			}
			case LITERAL_get:
			{
				match(LITERAL_get);
				match(LPAREN);
				variableReference();
				match(RPAREN);
				match(SEMI);
				break;
			}
			case LITERAL_newLine:
			{
				match(LITERAL_newLine);
				{
				switch ( LA(1)) {
				case LPAREN:
				{
					match(LPAREN);
					match(RPAREN);
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(SEMI);
				break;
			}
			case LITERAL_skipLine:
			{
				match(LITERAL_skipLine);
				{
				switch ( LA(1)) {
				case LPAREN:
				{
					match(LPAREN);
					match(RPAREN);
					break;
				}
				case SEMI:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(SEMI);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void procedureCallStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(IDENT);
			{
			switch ( LA(1)) {
			case LPAREN:
			{
				actualParameters();
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void assignmentStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			variableReference();
			match(BECOMES);
			expression();
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void endStatement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LITERAL_end);
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void variableReference() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(IDENT);
			{
			_loop54:
			do {
				switch ( LA(1)) {
				case LBRACKET:
				{
					match(LBRACKET);
					expression();
					match(RBRACKET);
					break;
				}
				case DOT:
				{
					match(DOT);
					match(IDENT);
					break;
				}
				default:
				{
					break _loop54;
				}
				}
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_14);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void expression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			relationalExpression();
			{
			_loop81:
			do {
				if ((LA(1)==LITERAL_and||LA(1)==LITERAL_or)) {
					{
					switch ( LA(1)) {
					case LITERAL_and:
					{
						match(LITERAL_and);
						break;
					}
					case LITERAL_or:
					{
						match(LITERAL_or);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					relationalExpression();
				}
				else {
					break _loop81;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_15);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void actualParameters() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			match(LPAREN);
			{
			switch ( LA(1)) {
			case IDENT:
			case INTLIT:
			case STRING_LITERAL:
			case LPAREN:
			case LITERAL_not:
			case PLUS:
			case MINUS:
			{
				expression();
				{
				_loop44:
				do {
					if ((LA(1)==COMMA)) {
						match(COMMA);
						expression();
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				break;
			}
			case RPAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(RPAREN);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_9);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void ifPart() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			expression();
			match(LITERAL_then);
			statementList();
			{
			switch ( LA(1)) {
			case LITERAL_elsif:
			{
				match(LITERAL_elsif);
				ifPart();
				break;
			}
			case LITERAL_else:
			{
				match(LITERAL_else);
				statementList();
				break;
			}
			case LITERAL_end:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_16);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void primitiveElement() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			if ((LA(1)==IDENT)) {
				variableReference();
			}
			else if ((LA(1)==IDENT||LA(1)==INTLIT||LA(1)==STRING_LITERAL)) {
				constantValue();
			}
			else if ((LA(1)==LPAREN)) {
				match(LPAREN);
				expression();
				match(RPAREN);
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void booleanNegationExpression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			_loop61:
			do {
				if ((LA(1)==LITERAL_not)) {
					match(LITERAL_not);
				}
				else {
					break _loop61;
				}
				
			} while (true);
			}
			primitiveElement();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void signExpression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			{
			_loop65:
			do {
				if ((LA(1)==PLUS||LA(1)==MINUS)) {
					{
					switch ( LA(1)) {
					case PLUS:
					{
						match(PLUS);
						break;
					}
					case MINUS:
					{
						match(MINUS);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
				}
				else {
					break _loop65;
				}
				
			} while (true);
			}
			booleanNegationExpression();
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_8);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void multiplyingExpression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			signExpression();
			{
			_loop69:
			do {
				if (((LA(1) >= TIMES && LA(1) <= LITERAL_mod))) {
					{
					switch ( LA(1)) {
					case TIMES:
					{
						match(TIMES);
						break;
					}
					case DIV:
					{
						match(DIV);
						break;
					}
					case LITERAL_mod:
					{
						match(LITERAL_mod);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					signExpression();
				}
				else {
					break _loop69;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_17);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void addingExpression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			multiplyingExpression();
			{
			_loop73:
			do {
				if ((LA(1)==PLUS||LA(1)==MINUS)) {
					{
					switch ( LA(1)) {
					case PLUS:
					{
						match(PLUS);
						break;
					}
					case MINUS:
					{
						match(MINUS);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					multiplyingExpression();
				}
				else {
					break _loop73;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_18);
			} else {
			  throw ex;
			}
		}
	}
	
	public final void relationalExpression() throws RecognitionException, TokenStreamException {
		
		
		try {      // for error handling
			addingExpression();
			{
			_loop77:
			do {
				if ((_tokenSet_19.member(LA(1)))) {
					{
					switch ( LA(1)) {
					case EQUALS:
					{
						match(EQUALS);
						break;
					}
					case NOT_EQUALS:
					{
						match(NOT_EQUALS);
						break;
					}
					case GT:
					{
						match(GT);
						break;
					}
					case GTE:
					{
						match(GTE);
						break;
					}
					case LT:
					{
						match(LT);
						break;
					}
					case LTE:
					{
						match(LTE);
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					addingExpression();
				}
				else {
					break _loop77;
				}
				
			} while (true);
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_20);
			} else {
			  throw ex;
			}
		}
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"program\"",
		"IDENT",
		"EQUALS",
		"DOT",
		"\"begin\"",
		"\"end\"",
		"\"var\"",
		"COLON",
		"BECOMES",
		"SEMI",
		"\"constant\"",
		"COMMA",
		"INTLIT",
		"STRING_LITERAL",
		"\"type\"",
		"\"array\"",
		"LBRACKET",
		"DOTDOT",
		"RBRACKET",
		"\"of\"",
		"\"record\"",
		"\"Integer\"",
		"\"Boolean\"",
		"\"procedure\"",
		"LPAREN",
		"RPAREN",
		"\"exit\"",
		"\"when\"",
		"\"return\"",
		"\"if\"",
		"\"then\"",
		"\"elsif\"",
		"\"else\"",
		"\"while\"",
		"\"loop\"",
		"\"put\"",
		"\"get\"",
		"\"newLine\"",
		"\"skipLine\"",
		"\"not\"",
		"PLUS",
		"MINUS",
		"TIMES",
		"DIV",
		"\"mod\"",
		"NOT_EQUALS",
		"GT",
		"GTE",
		"LT",
		"LTE",
		"\"and\"",
		"\"or\"",
		"COMMENT",
		"DIGIT",
		"CHARLIT",
		"WS"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 8320L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 134497536L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 134217984L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 8672612712480L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 103079215616L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 2048L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 536883200L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 72040294450765888L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 8192L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 6291456L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 64L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 536879104L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 8775691928096L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 72040294450769984L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	private static final long[] mk_tokenSet_15() {
		long[] data = { 292598882304L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
	private static final long[] mk_tokenSet_16() {
		long[] data = { 512L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
	private static final long[] mk_tokenSet_17() {
		long[] data = { 71547713241522240L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
	private static final long[] mk_tokenSet_18() {
		long[] data = { 71494936683388992L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
	private static final long[] mk_tokenSet_19() {
		long[] data = { 17451448556060736L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
	private static final long[] mk_tokenSet_20() {
		long[] data = { 54043488127328256L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
	
	}
