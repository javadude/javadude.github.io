package com.javadude.auto1;

public class Person {
	private String name;
	public String getName() {
		return this.name;
	}
	public Person setName(String name) {
		this.name = name;
		return this;
	}
	private int age;
	public int getAge() {
		return this.age;
	}
	public Person setAge(int age) {
		this.age = age;
		return this;
	}
	private boolean alive;
	public boolean isAlive() {
		return this.alive;
	}
	public Person setAlive(boolean alive) {
		this.alive = alive;
		return this;
	}
	private final java.util.List<Address> addresses = new java.util.ArrayList<>();
	private final java.util.List<Address> unmodifiableAddresses = java.util.Collections.unmodifiableList(addresses);
	public java.util.List<Address> getAddresses() {
		return unmodifiableAddresses;
	}
	public Person addAddress(Address item) {
		this.addresses.add(item);
		return this;
	}
	public Person removeAddress(Address item) {
		this.addresses.remove(item);
		return this;
	}
}
