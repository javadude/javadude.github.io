package com.javadude.manual2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Person {
	private String name;
	public String getName() {
		return this.name;
	}
	public Person setName(String name) {
		this.name = name;
		return this;
	}
	private int age;
	public int getAge() {
		return this.age;
	}
	public Person setAge(int age) {
		this.age = age;
		return this;
	}
	private boolean alive;
	public boolean isAlive() {
		return this.alive;
	}
	public Person setAlive(boolean alive) {
		this.alive = alive;
		return this;
	}
	private final List<Address> addresses = new ArrayList<>();
	private final List<Address> unmodifiableAddresses = Collections.unmodifiableList(addresses);
	public List<Address> getAddresses() {
		return unmodifiableAddresses;
	}
	public Person addAddress(Address item) {
		this.addresses.add(item);
		return this;
	}
	public Person removeAddress(Address item) {
		this.addresses.remove(item);
		return this;
	}
}
