package com.javadude.manual2;

public class Address {
	private String street;
	public String getStreet() {
		return this.street;
	}
	public Address setStreet(String street) {
		this.street = street;
		return this;
	}
	private String city;
	public String getCity() {
		return this.city;
	}
	public Address setCity(String city) {
		this.city = city;
		return this;
	}
}
