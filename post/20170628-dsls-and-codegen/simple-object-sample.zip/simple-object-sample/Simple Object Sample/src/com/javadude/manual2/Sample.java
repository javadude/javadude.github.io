package com.javadude.manual2;

public class Sample {

	public static void main(String[] args) {
		Person person = new Person()
				.setName("Scott")
				.setAge(50)
				.addAddress(new Address()
						.setStreet("123 Sesame")
						.setCity("New York"))
				.addAddress(new Address()
						.setStreet("1313 Mockingbird Lane")
						.setCity("Mockingbird Heights"));
		
		System.out.println("Name: " + person.getName());
		System.out.println("Age: " + person.getAge());
		person.getAddresses().stream().forEach(address -> {
			System.out.println("Address");
			System.out.println("	Street: " + address.getStreet());
			System.out.println("	City: " + address.getCity());
		});
	}

}
