package com.javadude.manual1;

public class Sample {

	public static void main(String[] args) {
		Address address1 = new Address();
		address1.setStreet("123 Sesame");
		address1.setCity("New York");
		
		Address address2 = new Address();
		address2.setStreet("1313 Mockingbird Lane");
		address2.setCity("Mockingbird Heights");
		
		Person person = new Person();
		person.setName("Scott");
		person.setAge(50);
		person.addAddress(address1);
		person.addAddress(address2);
		
		System.out.println("Name: " + person.getName());
		System.out.println("Age: " + person.getAge());
		person.getAddresses().stream().forEach(address -> {
			System.out.println("Address");
			System.out.println("	Street: " + address.getStreet());
			System.out.println("	City: " + address.getCity());
		});
	}

}
