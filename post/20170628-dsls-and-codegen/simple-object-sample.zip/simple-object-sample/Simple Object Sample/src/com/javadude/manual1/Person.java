package com.javadude.manual1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Person {
	private String name;
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private int age;
	public int getAge() {
		return this.age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	private boolean alive;
	public boolean isAlive() {
		return this.alive;
	}
	public void setAlive(boolean alive) {
		this.alive = alive;
	}
	private final List<Address> addresses = new ArrayList<>();
	private final List<Address> unmodifiableAddresses = Collections.unmodifiableList(addresses);
	public List<Address> getAddresses() {
		return unmodifiableAddresses;
	}
	public void addAddress(Address item) {
		this.addresses.add(item);
	}
	public void removeAddress(Address item) {
		this.addresses.remove(item);
	}
}
