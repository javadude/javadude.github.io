package com.javadude.simpleobjectdsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import com.javadude.simpleobjectdsl.services.SimpleObjectDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSimpleObjectDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'.'", "'class'", "'{'", "'}'", "'String'", "'int'", "'boolean'", "'List'", "'singular'", "'enum'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSimpleObjectDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSimpleObjectDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSimpleObjectDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSimpleObjectDsl.g"; }



     	private SimpleObjectDslGrammarAccess grammarAccess;

        public InternalSimpleObjectDslParser(TokenStream input, SimpleObjectDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected SimpleObjectDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalSimpleObjectDsl.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalSimpleObjectDsl.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalSimpleObjectDsl.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSimpleObjectDsl.g:71:1: ruleModel returns [EObject current=null] : (otherlv_0= 'package' ( (lv_pkg_1_0= ruleqid ) ) ( (lv_classes_2_0= ruleClassType ) )* ( (lv_enums_3_0= ruleEnumType ) )* ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_pkg_1_0 = null;

        EObject lv_classes_2_0 = null;

        EObject lv_enums_3_0 = null;



        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:77:2: ( (otherlv_0= 'package' ( (lv_pkg_1_0= ruleqid ) ) ( (lv_classes_2_0= ruleClassType ) )* ( (lv_enums_3_0= ruleEnumType ) )* ) )
            // InternalSimpleObjectDsl.g:78:2: (otherlv_0= 'package' ( (lv_pkg_1_0= ruleqid ) ) ( (lv_classes_2_0= ruleClassType ) )* ( (lv_enums_3_0= ruleEnumType ) )* )
            {
            // InternalSimpleObjectDsl.g:78:2: (otherlv_0= 'package' ( (lv_pkg_1_0= ruleqid ) ) ( (lv_classes_2_0= ruleClassType ) )* ( (lv_enums_3_0= ruleEnumType ) )* )
            // InternalSimpleObjectDsl.g:79:3: otherlv_0= 'package' ( (lv_pkg_1_0= ruleqid ) ) ( (lv_classes_2_0= ruleClassType ) )* ( (lv_enums_3_0= ruleEnumType ) )*
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getModelAccess().getPackageKeyword_0());
            		
            // InternalSimpleObjectDsl.g:83:3: ( (lv_pkg_1_0= ruleqid ) )
            // InternalSimpleObjectDsl.g:84:4: (lv_pkg_1_0= ruleqid )
            {
            // InternalSimpleObjectDsl.g:84:4: (lv_pkg_1_0= ruleqid )
            // InternalSimpleObjectDsl.g:85:5: lv_pkg_1_0= ruleqid
            {

            					newCompositeNode(grammarAccess.getModelAccess().getPkgQidParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_pkg_1_0=ruleqid();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getModelRule());
            					}
            					set(
            						current,
            						"pkg",
            						lv_pkg_1_0,
            						"com.javadude.simpleobjectdsl.SimpleObjectDsl.qid");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSimpleObjectDsl.g:102:3: ( (lv_classes_2_0= ruleClassType ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:103:4: (lv_classes_2_0= ruleClassType )
            	    {
            	    // InternalSimpleObjectDsl.g:103:4: (lv_classes_2_0= ruleClassType )
            	    // InternalSimpleObjectDsl.g:104:5: lv_classes_2_0= ruleClassType
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getClassesClassTypeParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_classes_2_0=ruleClassType();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"classes",
            	    						lv_classes_2_0,
            	    						"com.javadude.simpleobjectdsl.SimpleObjectDsl.ClassType");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSimpleObjectDsl.g:121:3: ( (lv_enums_3_0= ruleEnumType ) )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==21) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:122:4: (lv_enums_3_0= ruleEnumType )
            	    {
            	    // InternalSimpleObjectDsl.g:122:4: (lv_enums_3_0= ruleEnumType )
            	    // InternalSimpleObjectDsl.g:123:5: lv_enums_3_0= ruleEnumType
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getEnumsEnumTypeParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_5);
            	    lv_enums_3_0=ruleEnumType();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"enums",
            	    						lv_enums_3_0,
            	    						"com.javadude.simpleobjectdsl.SimpleObjectDsl.EnumType");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleqid"
    // InternalSimpleObjectDsl.g:144:1: entryRuleqid returns [String current=null] : iv_ruleqid= ruleqid EOF ;
    public final String entryRuleqid() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleqid = null;


        try {
            // InternalSimpleObjectDsl.g:144:43: (iv_ruleqid= ruleqid EOF )
            // InternalSimpleObjectDsl.g:145:2: iv_ruleqid= ruleqid EOF
            {
             newCompositeNode(grammarAccess.getQidRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleqid=ruleqid();

            state._fsp--;

             current =iv_ruleqid.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleqid"


    // $ANTLR start "ruleqid"
    // InternalSimpleObjectDsl.g:151:1: ruleqid returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleqid() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;


        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:157:2: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // InternalSimpleObjectDsl.g:158:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // InternalSimpleObjectDsl.g:158:2: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // InternalSimpleObjectDsl.g:159:3: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_6); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getQidAccess().getIDTerminalRuleCall_0());
            		
            // InternalSimpleObjectDsl.g:166:3: (kw= '.' this_ID_2= RULE_ID )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==12) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:167:4: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,12,FOLLOW_3); 

            	    				current.merge(kw);
            	    				newLeafNode(kw, grammarAccess.getQidAccess().getFullStopKeyword_1_0());
            	    			
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_6); 

            	    				current.merge(this_ID_2);
            	    			

            	    				newLeafNode(this_ID_2, grammarAccess.getQidAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleqid"


    // $ANTLR start "entryRuleClassType"
    // InternalSimpleObjectDsl.g:184:1: entryRuleClassType returns [EObject current=null] : iv_ruleClassType= ruleClassType EOF ;
    public final EObject entryRuleClassType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClassType = null;


        try {
            // InternalSimpleObjectDsl.g:184:50: (iv_ruleClassType= ruleClassType EOF )
            // InternalSimpleObjectDsl.g:185:2: iv_ruleClassType= ruleClassType EOF
            {
             newCompositeNode(grammarAccess.getClassTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClassType=ruleClassType();

            state._fsp--;

             current =iv_ruleClassType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClassType"


    // $ANTLR start "ruleClassType"
    // InternalSimpleObjectDsl.g:191:1: ruleClassType returns [EObject current=null] : (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_fields_3_0= ruleFieldDecl ) )* otherlv_4= '}' ) ;
    public final EObject ruleClassType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_fields_3_0 = null;



        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:197:2: ( (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_fields_3_0= ruleFieldDecl ) )* otherlv_4= '}' ) )
            // InternalSimpleObjectDsl.g:198:2: (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_fields_3_0= ruleFieldDecl ) )* otherlv_4= '}' )
            {
            // InternalSimpleObjectDsl.g:198:2: (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_fields_3_0= ruleFieldDecl ) )* otherlv_4= '}' )
            // InternalSimpleObjectDsl.g:199:3: otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_fields_3_0= ruleFieldDecl ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,13,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getClassTypeAccess().getClassKeyword_0());
            		
            // InternalSimpleObjectDsl.g:203:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:204:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:204:4: (lv_name_1_0= RULE_ID )
            // InternalSimpleObjectDsl.g:205:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_1_0, grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClassTypeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_8); 

            			newLeafNode(otherlv_2, grammarAccess.getClassTypeAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSimpleObjectDsl.g:225:3: ( (lv_fields_3_0= ruleFieldDecl ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID||(LA4_0>=16 && LA4_0<=19)) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:226:4: (lv_fields_3_0= ruleFieldDecl )
            	    {
            	    // InternalSimpleObjectDsl.g:226:4: (lv_fields_3_0= ruleFieldDecl )
            	    // InternalSimpleObjectDsl.g:227:5: lv_fields_3_0= ruleFieldDecl
            	    {

            	    					newCompositeNode(grammarAccess.getClassTypeAccess().getFieldsFieldDeclParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_8);
            	    lv_fields_3_0=ruleFieldDecl();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getClassTypeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"fields",
            	    						lv_fields_3_0,
            	    						"com.javadude.simpleobjectdsl.SimpleObjectDsl.FieldDecl");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getClassTypeAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClassType"


    // $ANTLR start "entryRuleFieldDecl"
    // InternalSimpleObjectDsl.g:252:1: entryRuleFieldDecl returns [EObject current=null] : iv_ruleFieldDecl= ruleFieldDecl EOF ;
    public final EObject entryRuleFieldDecl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFieldDecl = null;


        try {
            // InternalSimpleObjectDsl.g:252:50: (iv_ruleFieldDecl= ruleFieldDecl EOF )
            // InternalSimpleObjectDsl.g:253:2: iv_ruleFieldDecl= ruleFieldDecl EOF
            {
             newCompositeNode(grammarAccess.getFieldDeclRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFieldDecl=ruleFieldDecl();

            state._fsp--;

             current =iv_ruleFieldDecl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFieldDecl"


    // $ANTLR start "ruleFieldDecl"
    // InternalSimpleObjectDsl.g:259:1: ruleFieldDecl returns [EObject current=null] : (this_BasicField_0= ruleBasicField | this_ListField_1= ruleListField | this_PrimitiveField_2= rulePrimitiveField ) ;
    public final EObject ruleFieldDecl() throws RecognitionException {
        EObject current = null;

        EObject this_BasicField_0 = null;

        EObject this_ListField_1 = null;

        EObject this_PrimitiveField_2 = null;



        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:265:2: ( (this_BasicField_0= ruleBasicField | this_ListField_1= ruleListField | this_PrimitiveField_2= rulePrimitiveField ) )
            // InternalSimpleObjectDsl.g:266:2: (this_BasicField_0= ruleBasicField | this_ListField_1= ruleListField | this_PrimitiveField_2= rulePrimitiveField )
            {
            // InternalSimpleObjectDsl.g:266:2: (this_BasicField_0= ruleBasicField | this_ListField_1= ruleListField | this_PrimitiveField_2= rulePrimitiveField )
            int alt5=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt5=1;
                }
                break;
            case 19:
                {
                alt5=2;
                }
                break;
            case 16:
            case 17:
            case 18:
                {
                alt5=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }

            switch (alt5) {
                case 1 :
                    // InternalSimpleObjectDsl.g:267:3: this_BasicField_0= ruleBasicField
                    {

                    			newCompositeNode(grammarAccess.getFieldDeclAccess().getBasicFieldParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_BasicField_0=ruleBasicField();

                    state._fsp--;


                    			current = this_BasicField_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSimpleObjectDsl.g:276:3: this_ListField_1= ruleListField
                    {

                    			newCompositeNode(grammarAccess.getFieldDeclAccess().getListFieldParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ListField_1=ruleListField();

                    state._fsp--;


                    			current = this_ListField_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSimpleObjectDsl.g:285:3: this_PrimitiveField_2= rulePrimitiveField
                    {

                    			newCompositeNode(grammarAccess.getFieldDeclAccess().getPrimitiveFieldParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_PrimitiveField_2=rulePrimitiveField();

                    state._fsp--;


                    			current = this_PrimitiveField_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFieldDecl"


    // $ANTLR start "entryRuleBasicField"
    // InternalSimpleObjectDsl.g:297:1: entryRuleBasicField returns [EObject current=null] : iv_ruleBasicField= ruleBasicField EOF ;
    public final EObject entryRuleBasicField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBasicField = null;


        try {
            // InternalSimpleObjectDsl.g:297:51: (iv_ruleBasicField= ruleBasicField EOF )
            // InternalSimpleObjectDsl.g:298:2: iv_ruleBasicField= ruleBasicField EOF
            {
             newCompositeNode(grammarAccess.getBasicFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBasicField=ruleBasicField();

            state._fsp--;

             current =iv_ruleBasicField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBasicField"


    // $ANTLR start "ruleBasicField"
    // InternalSimpleObjectDsl.g:304:1: ruleBasicField returns [EObject current=null] : ( ( (otherlv_0= RULE_ID ) ) ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject ruleBasicField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:310:2: ( ( ( (otherlv_0= RULE_ID ) ) ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalSimpleObjectDsl.g:311:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalSimpleObjectDsl.g:311:2: ( ( (otherlv_0= RULE_ID ) ) ( (lv_name_1_0= RULE_ID ) ) )
            // InternalSimpleObjectDsl.g:312:3: ( (otherlv_0= RULE_ID ) ) ( (lv_name_1_0= RULE_ID ) )
            {
            // InternalSimpleObjectDsl.g:312:3: ( (otherlv_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:313:4: (otherlv_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:313:4: (otherlv_0= RULE_ID )
            // InternalSimpleObjectDsl.g:314:5: otherlv_0= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getBasicFieldRule());
            					}
            				
            otherlv_0=(Token)match(input,RULE_ID,FOLLOW_3); 

            					newLeafNode(otherlv_0, grammarAccess.getBasicFieldAccess().getTypeDeclaredTypeCrossReference_0_0());
            				

            }


            }

            // InternalSimpleObjectDsl.g:325:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:326:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:326:4: (lv_name_1_0= RULE_ID )
            // InternalSimpleObjectDsl.g:327:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_1_0, grammarAccess.getBasicFieldAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getBasicFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBasicField"


    // $ANTLR start "entryRulePrimitiveField"
    // InternalSimpleObjectDsl.g:347:1: entryRulePrimitiveField returns [EObject current=null] : iv_rulePrimitiveField= rulePrimitiveField EOF ;
    public final EObject entryRulePrimitiveField() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrimitiveField = null;


        try {
            // InternalSimpleObjectDsl.g:347:55: (iv_rulePrimitiveField= rulePrimitiveField EOF )
            // InternalSimpleObjectDsl.g:348:2: iv_rulePrimitiveField= rulePrimitiveField EOF
            {
             newCompositeNode(grammarAccess.getPrimitiveFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePrimitiveField=rulePrimitiveField();

            state._fsp--;

             current =iv_rulePrimitiveField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrimitiveField"


    // $ANTLR start "rulePrimitiveField"
    // InternalSimpleObjectDsl.g:354:1: rulePrimitiveField returns [EObject current=null] : ( ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject rulePrimitiveField() throws RecognitionException {
        EObject current = null;

        Token lv_type_0_1=null;
        Token lv_type_0_2=null;
        Token lv_type_0_3=null;
        Token lv_name_1_0=null;


        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:360:2: ( ( ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) ) ( (lv_name_1_0= RULE_ID ) ) ) )
            // InternalSimpleObjectDsl.g:361:2: ( ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) ) ( (lv_name_1_0= RULE_ID ) ) )
            {
            // InternalSimpleObjectDsl.g:361:2: ( ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) ) ( (lv_name_1_0= RULE_ID ) ) )
            // InternalSimpleObjectDsl.g:362:3: ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) ) ( (lv_name_1_0= RULE_ID ) )
            {
            // InternalSimpleObjectDsl.g:362:3: ( ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) ) )
            // InternalSimpleObjectDsl.g:363:4: ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) )
            {
            // InternalSimpleObjectDsl.g:363:4: ( (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' ) )
            // InternalSimpleObjectDsl.g:364:5: (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' )
            {
            // InternalSimpleObjectDsl.g:364:5: (lv_type_0_1= 'String' | lv_type_0_2= 'int' | lv_type_0_3= 'boolean' )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt6=1;
                }
                break;
            case 17:
                {
                alt6=2;
                }
                break;
            case 18:
                {
                alt6=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSimpleObjectDsl.g:365:6: lv_type_0_1= 'String'
                    {
                    lv_type_0_1=(Token)match(input,16,FOLLOW_3); 

                    						newLeafNode(lv_type_0_1, grammarAccess.getPrimitiveFieldAccess().getTypeStringKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrimitiveFieldRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSimpleObjectDsl.g:376:6: lv_type_0_2= 'int'
                    {
                    lv_type_0_2=(Token)match(input,17,FOLLOW_3); 

                    						newLeafNode(lv_type_0_2, grammarAccess.getPrimitiveFieldAccess().getTypeIntKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrimitiveFieldRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSimpleObjectDsl.g:387:6: lv_type_0_3= 'boolean'
                    {
                    lv_type_0_3=(Token)match(input,18,FOLLOW_3); 

                    						newLeafNode(lv_type_0_3, grammarAccess.getPrimitiveFieldAccess().getTypeBooleanKeyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPrimitiveFieldRule());
                    						}
                    						setWithLastConsumed(current, "type", lv_type_0_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSimpleObjectDsl.g:400:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:401:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:401:4: (lv_name_1_0= RULE_ID )
            // InternalSimpleObjectDsl.g:402:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_name_1_0, grammarAccess.getPrimitiveFieldAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPrimitiveFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrimitiveField"


    // $ANTLR start "entryRuleListField"
    // InternalSimpleObjectDsl.g:422:1: entryRuleListField returns [EObject current=null] : iv_ruleListField= ruleListField EOF ;
    public final EObject entryRuleListField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListField = null;


        try {
            // InternalSimpleObjectDsl.g:422:50: (iv_ruleListField= ruleListField EOF )
            // InternalSimpleObjectDsl.g:423:2: iv_ruleListField= ruleListField EOF
            {
             newCompositeNode(grammarAccess.getListFieldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleListField=ruleListField();

            state._fsp--;

             current =iv_ruleListField; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListField"


    // $ANTLR start "ruleListField"
    // InternalSimpleObjectDsl.g:429:1: ruleListField returns [EObject current=null] : (otherlv_0= 'List' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'singular' ( (lv_singular_4_0= RULE_ID ) ) ) ;
    public final EObject ruleListField() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;
        Token lv_singular_4_0=null;


        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:435:2: ( (otherlv_0= 'List' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'singular' ( (lv_singular_4_0= RULE_ID ) ) ) )
            // InternalSimpleObjectDsl.g:436:2: (otherlv_0= 'List' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'singular' ( (lv_singular_4_0= RULE_ID ) ) )
            {
            // InternalSimpleObjectDsl.g:436:2: (otherlv_0= 'List' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'singular' ( (lv_singular_4_0= RULE_ID ) ) )
            // InternalSimpleObjectDsl.g:437:3: otherlv_0= 'List' ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= 'singular' ( (lv_singular_4_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getListFieldAccess().getListKeyword_0());
            		
            // InternalSimpleObjectDsl.g:441:3: ( (otherlv_1= RULE_ID ) )
            // InternalSimpleObjectDsl.g:442:4: (otherlv_1= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:442:4: (otherlv_1= RULE_ID )
            // InternalSimpleObjectDsl.g:443:5: otherlv_1= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getListFieldRule());
            					}
            				
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_3); 

            					newLeafNode(otherlv_1, grammarAccess.getListFieldAccess().getTypeClassTypeCrossReference_1_0());
            				

            }


            }

            // InternalSimpleObjectDsl.g:454:3: ( (lv_name_2_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:455:4: (lv_name_2_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:455:4: (lv_name_2_0= RULE_ID )
            // InternalSimpleObjectDsl.g:456:5: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_name_2_0, grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getListFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,20,FOLLOW_3); 

            			newLeafNode(otherlv_3, grammarAccess.getListFieldAccess().getSingularKeyword_3());
            		
            // InternalSimpleObjectDsl.g:476:3: ( (lv_singular_4_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:477:4: (lv_singular_4_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:477:4: (lv_singular_4_0= RULE_ID )
            // InternalSimpleObjectDsl.g:478:5: lv_singular_4_0= RULE_ID
            {
            lv_singular_4_0=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(lv_singular_4_0, grammarAccess.getListFieldAccess().getSingularIDTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getListFieldRule());
            					}
            					setWithLastConsumed(
            						current,
            						"singular",
            						lv_singular_4_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListField"


    // $ANTLR start "entryRuleEnumType"
    // InternalSimpleObjectDsl.g:498:1: entryRuleEnumType returns [EObject current=null] : iv_ruleEnumType= ruleEnumType EOF ;
    public final EObject entryRuleEnumType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnumType = null;


        try {
            // InternalSimpleObjectDsl.g:498:49: (iv_ruleEnumType= ruleEnumType EOF )
            // InternalSimpleObjectDsl.g:499:2: iv_ruleEnumType= ruleEnumType EOF
            {
             newCompositeNode(grammarAccess.getEnumTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnumType=ruleEnumType();

            state._fsp--;

             current =iv_ruleEnumType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnumType"


    // $ANTLR start "ruleEnumType"
    // InternalSimpleObjectDsl.g:505:1: ruleEnumType returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_values_3_0= ruleEnumValue ) )* otherlv_4= '}' ) ;
    public final EObject ruleEnumType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_values_3_0 = null;



        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:511:2: ( (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_values_3_0= ruleEnumValue ) )* otherlv_4= '}' ) )
            // InternalSimpleObjectDsl.g:512:2: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_values_3_0= ruleEnumValue ) )* otherlv_4= '}' )
            {
            // InternalSimpleObjectDsl.g:512:2: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_values_3_0= ruleEnumValue ) )* otherlv_4= '}' )
            // InternalSimpleObjectDsl.g:513:3: otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_values_3_0= ruleEnumValue ) )* otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumTypeAccess().getEnumKeyword_0());
            		
            // InternalSimpleObjectDsl.g:517:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:518:4: (lv_name_1_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:518:4: (lv_name_1_0= RULE_ID )
            // InternalSimpleObjectDsl.g:519:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_7); 

            					newLeafNode(lv_name_1_0, grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumTypeRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,14,FOLLOW_10); 

            			newLeafNode(otherlv_2, grammarAccess.getEnumTypeAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSimpleObjectDsl.g:539:3: ( (lv_values_3_0= ruleEnumValue ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:540:4: (lv_values_3_0= ruleEnumValue )
            	    {
            	    // InternalSimpleObjectDsl.g:540:4: (lv_values_3_0= ruleEnumValue )
            	    // InternalSimpleObjectDsl.g:541:5: lv_values_3_0= ruleEnumValue
            	    {

            	    					newCompositeNode(grammarAccess.getEnumTypeAccess().getValuesEnumValueParserRuleCall_3_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_values_3_0=ruleEnumValue();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getEnumTypeRule());
            	    					}
            	    					add(
            	    						current,
            	    						"values",
            	    						lv_values_3_0,
            	    						"com.javadude.simpleobjectdsl.SimpleObjectDsl.EnumValue");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getEnumTypeAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnumType"


    // $ANTLR start "entryRuleEnumValue"
    // InternalSimpleObjectDsl.g:566:1: entryRuleEnumValue returns [EObject current=null] : iv_ruleEnumValue= ruleEnumValue EOF ;
    public final EObject entryRuleEnumValue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnumValue = null;


        try {
            // InternalSimpleObjectDsl.g:566:50: (iv_ruleEnumValue= ruleEnumValue EOF )
            // InternalSimpleObjectDsl.g:567:2: iv_ruleEnumValue= ruleEnumValue EOF
            {
             newCompositeNode(grammarAccess.getEnumValueRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnumValue=ruleEnumValue();

            state._fsp--;

             current =iv_ruleEnumValue; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnumValue"


    // $ANTLR start "ruleEnumValue"
    // InternalSimpleObjectDsl.g:573:1: ruleEnumValue returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_displayName_1_0= RULE_STRING ) ) ) ;
    public final EObject ruleEnumValue() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token lv_displayName_1_0=null;


        	enterRule();

        try {
            // InternalSimpleObjectDsl.g:579:2: ( ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_displayName_1_0= RULE_STRING ) ) ) )
            // InternalSimpleObjectDsl.g:580:2: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_displayName_1_0= RULE_STRING ) ) )
            {
            // InternalSimpleObjectDsl.g:580:2: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_displayName_1_0= RULE_STRING ) ) )
            // InternalSimpleObjectDsl.g:581:3: ( (lv_name_0_0= RULE_ID ) ) ( (lv_displayName_1_0= RULE_STRING ) )
            {
            // InternalSimpleObjectDsl.g:581:3: ( (lv_name_0_0= RULE_ID ) )
            // InternalSimpleObjectDsl.g:582:4: (lv_name_0_0= RULE_ID )
            {
            // InternalSimpleObjectDsl.g:582:4: (lv_name_0_0= RULE_ID )
            // InternalSimpleObjectDsl.g:583:5: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_11); 

            					newLeafNode(lv_name_0_0, grammarAccess.getEnumValueAccess().getNameIDTerminalRuleCall_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumValueRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_0_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSimpleObjectDsl.g:599:3: ( (lv_displayName_1_0= RULE_STRING ) )
            // InternalSimpleObjectDsl.g:600:4: (lv_displayName_1_0= RULE_STRING )
            {
            // InternalSimpleObjectDsl.g:600:4: (lv_displayName_1_0= RULE_STRING )
            // InternalSimpleObjectDsl.g:601:5: lv_displayName_1_0= RULE_STRING
            {
            lv_displayName_1_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

            					newLeafNode(lv_displayName_1_0, grammarAccess.getEnumValueAccess().getDisplayNameSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumValueRule());
            					}
            					setWithLastConsumed(
            						current,
            						"displayName",
            						lv_displayName_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnumValue"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000202002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000001002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000000F8010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000008010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000020L});

}