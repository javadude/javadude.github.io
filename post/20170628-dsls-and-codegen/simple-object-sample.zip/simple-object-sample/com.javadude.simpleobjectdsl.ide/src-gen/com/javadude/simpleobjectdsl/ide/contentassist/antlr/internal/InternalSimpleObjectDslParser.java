package com.javadude.simpleobjectdsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import com.javadude.simpleobjectdsl.services.SimpleObjectDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSimpleObjectDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'String'", "'int'", "'boolean'", "'package'", "'.'", "'class'", "'{'", "'}'", "'List'", "'singular'", "'enum'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalSimpleObjectDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSimpleObjectDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSimpleObjectDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSimpleObjectDsl.g"; }


    	private SimpleObjectDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(SimpleObjectDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalSimpleObjectDsl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:54:1: ( ruleModel EOF )
            // InternalSimpleObjectDsl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalSimpleObjectDsl.g:62:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalSimpleObjectDsl.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:69:3: ( rule__Model__Group__0 )
            // InternalSimpleObjectDsl.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleqid"
    // InternalSimpleObjectDsl.g:78:1: entryRuleqid : ruleqid EOF ;
    public final void entryRuleqid() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:79:1: ( ruleqid EOF )
            // InternalSimpleObjectDsl.g:80:1: ruleqid EOF
            {
             before(grammarAccess.getQidRule()); 
            pushFollow(FOLLOW_1);
            ruleqid();

            state._fsp--;

             after(grammarAccess.getQidRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleqid"


    // $ANTLR start "ruleqid"
    // InternalSimpleObjectDsl.g:87:1: ruleqid : ( ( rule__Qid__Group__0 ) ) ;
    public final void ruleqid() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:91:2: ( ( ( rule__Qid__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:92:2: ( ( rule__Qid__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:92:2: ( ( rule__Qid__Group__0 ) )
            // InternalSimpleObjectDsl.g:93:3: ( rule__Qid__Group__0 )
            {
             before(grammarAccess.getQidAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:94:3: ( rule__Qid__Group__0 )
            // InternalSimpleObjectDsl.g:94:4: rule__Qid__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Qid__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getQidAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleqid"


    // $ANTLR start "entryRuleClassType"
    // InternalSimpleObjectDsl.g:103:1: entryRuleClassType : ruleClassType EOF ;
    public final void entryRuleClassType() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:104:1: ( ruleClassType EOF )
            // InternalSimpleObjectDsl.g:105:1: ruleClassType EOF
            {
             before(grammarAccess.getClassTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleClassType();

            state._fsp--;

             after(grammarAccess.getClassTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClassType"


    // $ANTLR start "ruleClassType"
    // InternalSimpleObjectDsl.g:112:1: ruleClassType : ( ( rule__ClassType__Group__0 ) ) ;
    public final void ruleClassType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:116:2: ( ( ( rule__ClassType__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:117:2: ( ( rule__ClassType__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:117:2: ( ( rule__ClassType__Group__0 ) )
            // InternalSimpleObjectDsl.g:118:3: ( rule__ClassType__Group__0 )
            {
             before(grammarAccess.getClassTypeAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:119:3: ( rule__ClassType__Group__0 )
            // InternalSimpleObjectDsl.g:119:4: rule__ClassType__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ClassType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClassTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClassType"


    // $ANTLR start "entryRuleFieldDecl"
    // InternalSimpleObjectDsl.g:128:1: entryRuleFieldDecl : ruleFieldDecl EOF ;
    public final void entryRuleFieldDecl() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:129:1: ( ruleFieldDecl EOF )
            // InternalSimpleObjectDsl.g:130:1: ruleFieldDecl EOF
            {
             before(grammarAccess.getFieldDeclRule()); 
            pushFollow(FOLLOW_1);
            ruleFieldDecl();

            state._fsp--;

             after(grammarAccess.getFieldDeclRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFieldDecl"


    // $ANTLR start "ruleFieldDecl"
    // InternalSimpleObjectDsl.g:137:1: ruleFieldDecl : ( ( rule__FieldDecl__Alternatives ) ) ;
    public final void ruleFieldDecl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:141:2: ( ( ( rule__FieldDecl__Alternatives ) ) )
            // InternalSimpleObjectDsl.g:142:2: ( ( rule__FieldDecl__Alternatives ) )
            {
            // InternalSimpleObjectDsl.g:142:2: ( ( rule__FieldDecl__Alternatives ) )
            // InternalSimpleObjectDsl.g:143:3: ( rule__FieldDecl__Alternatives )
            {
             before(grammarAccess.getFieldDeclAccess().getAlternatives()); 
            // InternalSimpleObjectDsl.g:144:3: ( rule__FieldDecl__Alternatives )
            // InternalSimpleObjectDsl.g:144:4: rule__FieldDecl__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__FieldDecl__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getFieldDeclAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFieldDecl"


    // $ANTLR start "entryRuleBasicField"
    // InternalSimpleObjectDsl.g:153:1: entryRuleBasicField : ruleBasicField EOF ;
    public final void entryRuleBasicField() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:154:1: ( ruleBasicField EOF )
            // InternalSimpleObjectDsl.g:155:1: ruleBasicField EOF
            {
             before(grammarAccess.getBasicFieldRule()); 
            pushFollow(FOLLOW_1);
            ruleBasicField();

            state._fsp--;

             after(grammarAccess.getBasicFieldRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleBasicField"


    // $ANTLR start "ruleBasicField"
    // InternalSimpleObjectDsl.g:162:1: ruleBasicField : ( ( rule__BasicField__Group__0 ) ) ;
    public final void ruleBasicField() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:166:2: ( ( ( rule__BasicField__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:167:2: ( ( rule__BasicField__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:167:2: ( ( rule__BasicField__Group__0 ) )
            // InternalSimpleObjectDsl.g:168:3: ( rule__BasicField__Group__0 )
            {
             before(grammarAccess.getBasicFieldAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:169:3: ( rule__BasicField__Group__0 )
            // InternalSimpleObjectDsl.g:169:4: rule__BasicField__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__BasicField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getBasicFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBasicField"


    // $ANTLR start "entryRulePrimitiveField"
    // InternalSimpleObjectDsl.g:178:1: entryRulePrimitiveField : rulePrimitiveField EOF ;
    public final void entryRulePrimitiveField() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:179:1: ( rulePrimitiveField EOF )
            // InternalSimpleObjectDsl.g:180:1: rulePrimitiveField EOF
            {
             before(grammarAccess.getPrimitiveFieldRule()); 
            pushFollow(FOLLOW_1);
            rulePrimitiveField();

            state._fsp--;

             after(grammarAccess.getPrimitiveFieldRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrimitiveField"


    // $ANTLR start "rulePrimitiveField"
    // InternalSimpleObjectDsl.g:187:1: rulePrimitiveField : ( ( rule__PrimitiveField__Group__0 ) ) ;
    public final void rulePrimitiveField() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:191:2: ( ( ( rule__PrimitiveField__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:192:2: ( ( rule__PrimitiveField__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:192:2: ( ( rule__PrimitiveField__Group__0 ) )
            // InternalSimpleObjectDsl.g:193:3: ( rule__PrimitiveField__Group__0 )
            {
             before(grammarAccess.getPrimitiveFieldAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:194:3: ( rule__PrimitiveField__Group__0 )
            // InternalSimpleObjectDsl.g:194:4: rule__PrimitiveField__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PrimitiveField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrimitiveField"


    // $ANTLR start "entryRuleListField"
    // InternalSimpleObjectDsl.g:203:1: entryRuleListField : ruleListField EOF ;
    public final void entryRuleListField() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:204:1: ( ruleListField EOF )
            // InternalSimpleObjectDsl.g:205:1: ruleListField EOF
            {
             before(grammarAccess.getListFieldRule()); 
            pushFollow(FOLLOW_1);
            ruleListField();

            state._fsp--;

             after(grammarAccess.getListFieldRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListField"


    // $ANTLR start "ruleListField"
    // InternalSimpleObjectDsl.g:212:1: ruleListField : ( ( rule__ListField__Group__0 ) ) ;
    public final void ruleListField() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:216:2: ( ( ( rule__ListField__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:217:2: ( ( rule__ListField__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:217:2: ( ( rule__ListField__Group__0 ) )
            // InternalSimpleObjectDsl.g:218:3: ( rule__ListField__Group__0 )
            {
             before(grammarAccess.getListFieldAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:219:3: ( rule__ListField__Group__0 )
            // InternalSimpleObjectDsl.g:219:4: rule__ListField__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ListField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListField"


    // $ANTLR start "entryRuleEnumType"
    // InternalSimpleObjectDsl.g:228:1: entryRuleEnumType : ruleEnumType EOF ;
    public final void entryRuleEnumType() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:229:1: ( ruleEnumType EOF )
            // InternalSimpleObjectDsl.g:230:1: ruleEnumType EOF
            {
             before(grammarAccess.getEnumTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleEnumType();

            state._fsp--;

             after(grammarAccess.getEnumTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnumType"


    // $ANTLR start "ruleEnumType"
    // InternalSimpleObjectDsl.g:237:1: ruleEnumType : ( ( rule__EnumType__Group__0 ) ) ;
    public final void ruleEnumType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:241:2: ( ( ( rule__EnumType__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:242:2: ( ( rule__EnumType__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:242:2: ( ( rule__EnumType__Group__0 ) )
            // InternalSimpleObjectDsl.g:243:3: ( rule__EnumType__Group__0 )
            {
             before(grammarAccess.getEnumTypeAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:244:3: ( rule__EnumType__Group__0 )
            // InternalSimpleObjectDsl.g:244:4: rule__EnumType__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EnumType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnumType"


    // $ANTLR start "entryRuleEnumValue"
    // InternalSimpleObjectDsl.g:253:1: entryRuleEnumValue : ruleEnumValue EOF ;
    public final void entryRuleEnumValue() throws RecognitionException {
        try {
            // InternalSimpleObjectDsl.g:254:1: ( ruleEnumValue EOF )
            // InternalSimpleObjectDsl.g:255:1: ruleEnumValue EOF
            {
             before(grammarAccess.getEnumValueRule()); 
            pushFollow(FOLLOW_1);
            ruleEnumValue();

            state._fsp--;

             after(grammarAccess.getEnumValueRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnumValue"


    // $ANTLR start "ruleEnumValue"
    // InternalSimpleObjectDsl.g:262:1: ruleEnumValue : ( ( rule__EnumValue__Group__0 ) ) ;
    public final void ruleEnumValue() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:266:2: ( ( ( rule__EnumValue__Group__0 ) ) )
            // InternalSimpleObjectDsl.g:267:2: ( ( rule__EnumValue__Group__0 ) )
            {
            // InternalSimpleObjectDsl.g:267:2: ( ( rule__EnumValue__Group__0 ) )
            // InternalSimpleObjectDsl.g:268:3: ( rule__EnumValue__Group__0 )
            {
             before(grammarAccess.getEnumValueAccess().getGroup()); 
            // InternalSimpleObjectDsl.g:269:3: ( rule__EnumValue__Group__0 )
            // InternalSimpleObjectDsl.g:269:4: rule__EnumValue__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EnumValue__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumValueAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnumValue"


    // $ANTLR start "rule__FieldDecl__Alternatives"
    // InternalSimpleObjectDsl.g:277:1: rule__FieldDecl__Alternatives : ( ( ruleBasicField ) | ( ruleListField ) | ( rulePrimitiveField ) );
    public final void rule__FieldDecl__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:281:1: ( ( ruleBasicField ) | ( ruleListField ) | ( rulePrimitiveField ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case RULE_ID:
                {
                alt1=1;
                }
                break;
            case 19:
                {
                alt1=2;
                }
                break;
            case 11:
            case 12:
            case 13:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalSimpleObjectDsl.g:282:2: ( ruleBasicField )
                    {
                    // InternalSimpleObjectDsl.g:282:2: ( ruleBasicField )
                    // InternalSimpleObjectDsl.g:283:3: ruleBasicField
                    {
                     before(grammarAccess.getFieldDeclAccess().getBasicFieldParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleBasicField();

                    state._fsp--;

                     after(grammarAccess.getFieldDeclAccess().getBasicFieldParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimpleObjectDsl.g:288:2: ( ruleListField )
                    {
                    // InternalSimpleObjectDsl.g:288:2: ( ruleListField )
                    // InternalSimpleObjectDsl.g:289:3: ruleListField
                    {
                     before(grammarAccess.getFieldDeclAccess().getListFieldParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleListField();

                    state._fsp--;

                     after(grammarAccess.getFieldDeclAccess().getListFieldParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSimpleObjectDsl.g:294:2: ( rulePrimitiveField )
                    {
                    // InternalSimpleObjectDsl.g:294:2: ( rulePrimitiveField )
                    // InternalSimpleObjectDsl.g:295:3: rulePrimitiveField
                    {
                     before(grammarAccess.getFieldDeclAccess().getPrimitiveFieldParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    rulePrimitiveField();

                    state._fsp--;

                     after(grammarAccess.getFieldDeclAccess().getPrimitiveFieldParserRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FieldDecl__Alternatives"


    // $ANTLR start "rule__PrimitiveField__TypeAlternatives_0_0"
    // InternalSimpleObjectDsl.g:304:1: rule__PrimitiveField__TypeAlternatives_0_0 : ( ( 'String' ) | ( 'int' ) | ( 'boolean' ) );
    public final void rule__PrimitiveField__TypeAlternatives_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:308:1: ( ( 'String' ) | ( 'int' ) | ( 'boolean' ) )
            int alt2=3;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt2=1;
                }
                break;
            case 12:
                {
                alt2=2;
                }
                break;
            case 13:
                {
                alt2=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalSimpleObjectDsl.g:309:2: ( 'String' )
                    {
                    // InternalSimpleObjectDsl.g:309:2: ( 'String' )
                    // InternalSimpleObjectDsl.g:310:3: 'String'
                    {
                     before(grammarAccess.getPrimitiveFieldAccess().getTypeStringKeyword_0_0_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getPrimitiveFieldAccess().getTypeStringKeyword_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSimpleObjectDsl.g:315:2: ( 'int' )
                    {
                    // InternalSimpleObjectDsl.g:315:2: ( 'int' )
                    // InternalSimpleObjectDsl.g:316:3: 'int'
                    {
                     before(grammarAccess.getPrimitiveFieldAccess().getTypeIntKeyword_0_0_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getPrimitiveFieldAccess().getTypeIntKeyword_0_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSimpleObjectDsl.g:321:2: ( 'boolean' )
                    {
                    // InternalSimpleObjectDsl.g:321:2: ( 'boolean' )
                    // InternalSimpleObjectDsl.g:322:3: 'boolean'
                    {
                     before(grammarAccess.getPrimitiveFieldAccess().getTypeBooleanKeyword_0_0_2()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getPrimitiveFieldAccess().getTypeBooleanKeyword_0_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__TypeAlternatives_0_0"


    // $ANTLR start "rule__Model__Group__0"
    // InternalSimpleObjectDsl.g:331:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:335:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalSimpleObjectDsl.g:336:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalSimpleObjectDsl.g:343:1: rule__Model__Group__0__Impl : ( 'package' ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:347:1: ( ( 'package' ) )
            // InternalSimpleObjectDsl.g:348:1: ( 'package' )
            {
            // InternalSimpleObjectDsl.g:348:1: ( 'package' )
            // InternalSimpleObjectDsl.g:349:2: 'package'
            {
             before(grammarAccess.getModelAccess().getPackageKeyword_0()); 
            match(input,14,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getPackageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalSimpleObjectDsl.g:358:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:362:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // InternalSimpleObjectDsl.g:363:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalSimpleObjectDsl.g:370:1: rule__Model__Group__1__Impl : ( ( rule__Model__PkgAssignment_1 ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:374:1: ( ( ( rule__Model__PkgAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:375:1: ( ( rule__Model__PkgAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:375:1: ( ( rule__Model__PkgAssignment_1 ) )
            // InternalSimpleObjectDsl.g:376:2: ( rule__Model__PkgAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getPkgAssignment_1()); 
            // InternalSimpleObjectDsl.g:377:2: ( rule__Model__PkgAssignment_1 )
            // InternalSimpleObjectDsl.g:377:3: rule__Model__PkgAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Model__PkgAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getPkgAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // InternalSimpleObjectDsl.g:385:1: rule__Model__Group__2 : rule__Model__Group__2__Impl rule__Model__Group__3 ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:389:1: ( rule__Model__Group__2__Impl rule__Model__Group__3 )
            // InternalSimpleObjectDsl.g:390:2: rule__Model__Group__2__Impl rule__Model__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Model__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // InternalSimpleObjectDsl.g:397:1: rule__Model__Group__2__Impl : ( ( rule__Model__ClassesAssignment_2 )* ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:401:1: ( ( ( rule__Model__ClassesAssignment_2 )* ) )
            // InternalSimpleObjectDsl.g:402:1: ( ( rule__Model__ClassesAssignment_2 )* )
            {
            // InternalSimpleObjectDsl.g:402:1: ( ( rule__Model__ClassesAssignment_2 )* )
            // InternalSimpleObjectDsl.g:403:2: ( rule__Model__ClassesAssignment_2 )*
            {
             before(grammarAccess.getModelAccess().getClassesAssignment_2()); 
            // InternalSimpleObjectDsl.g:404:2: ( rule__Model__ClassesAssignment_2 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==16) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:404:3: rule__Model__ClassesAssignment_2
            	    {
            	    pushFollow(FOLLOW_5);
            	    rule__Model__ClassesAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getClassesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Model__Group__3"
    // InternalSimpleObjectDsl.g:412:1: rule__Model__Group__3 : rule__Model__Group__3__Impl ;
    public final void rule__Model__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:416:1: ( rule__Model__Group__3__Impl )
            // InternalSimpleObjectDsl.g:417:2: rule__Model__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3"


    // $ANTLR start "rule__Model__Group__3__Impl"
    // InternalSimpleObjectDsl.g:423:1: rule__Model__Group__3__Impl : ( ( rule__Model__EnumsAssignment_3 )* ) ;
    public final void rule__Model__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:427:1: ( ( ( rule__Model__EnumsAssignment_3 )* ) )
            // InternalSimpleObjectDsl.g:428:1: ( ( rule__Model__EnumsAssignment_3 )* )
            {
            // InternalSimpleObjectDsl.g:428:1: ( ( rule__Model__EnumsAssignment_3 )* )
            // InternalSimpleObjectDsl.g:429:2: ( rule__Model__EnumsAssignment_3 )*
            {
             before(grammarAccess.getModelAccess().getEnumsAssignment_3()); 
            // InternalSimpleObjectDsl.g:430:2: ( rule__Model__EnumsAssignment_3 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==21) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:430:3: rule__Model__EnumsAssignment_3
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Model__EnumsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getEnumsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3__Impl"


    // $ANTLR start "rule__Qid__Group__0"
    // InternalSimpleObjectDsl.g:439:1: rule__Qid__Group__0 : rule__Qid__Group__0__Impl rule__Qid__Group__1 ;
    public final void rule__Qid__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:443:1: ( rule__Qid__Group__0__Impl rule__Qid__Group__1 )
            // InternalSimpleObjectDsl.g:444:2: rule__Qid__Group__0__Impl rule__Qid__Group__1
            {
            pushFollow(FOLLOW_7);
            rule__Qid__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Qid__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group__0"


    // $ANTLR start "rule__Qid__Group__0__Impl"
    // InternalSimpleObjectDsl.g:451:1: rule__Qid__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__Qid__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:455:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:456:1: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:456:1: ( RULE_ID )
            // InternalSimpleObjectDsl.g:457:2: RULE_ID
            {
             before(grammarAccess.getQidAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQidAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group__0__Impl"


    // $ANTLR start "rule__Qid__Group__1"
    // InternalSimpleObjectDsl.g:466:1: rule__Qid__Group__1 : rule__Qid__Group__1__Impl ;
    public final void rule__Qid__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:470:1: ( rule__Qid__Group__1__Impl )
            // InternalSimpleObjectDsl.g:471:2: rule__Qid__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Qid__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group__1"


    // $ANTLR start "rule__Qid__Group__1__Impl"
    // InternalSimpleObjectDsl.g:477:1: rule__Qid__Group__1__Impl : ( ( rule__Qid__Group_1__0 )* ) ;
    public final void rule__Qid__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:481:1: ( ( ( rule__Qid__Group_1__0 )* ) )
            // InternalSimpleObjectDsl.g:482:1: ( ( rule__Qid__Group_1__0 )* )
            {
            // InternalSimpleObjectDsl.g:482:1: ( ( rule__Qid__Group_1__0 )* )
            // InternalSimpleObjectDsl.g:483:2: ( rule__Qid__Group_1__0 )*
            {
             before(grammarAccess.getQidAccess().getGroup_1()); 
            // InternalSimpleObjectDsl.g:484:2: ( rule__Qid__Group_1__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==15) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:484:3: rule__Qid__Group_1__0
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__Qid__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getQidAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group__1__Impl"


    // $ANTLR start "rule__Qid__Group_1__0"
    // InternalSimpleObjectDsl.g:493:1: rule__Qid__Group_1__0 : rule__Qid__Group_1__0__Impl rule__Qid__Group_1__1 ;
    public final void rule__Qid__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:497:1: ( rule__Qid__Group_1__0__Impl rule__Qid__Group_1__1 )
            // InternalSimpleObjectDsl.g:498:2: rule__Qid__Group_1__0__Impl rule__Qid__Group_1__1
            {
            pushFollow(FOLLOW_3);
            rule__Qid__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Qid__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group_1__0"


    // $ANTLR start "rule__Qid__Group_1__0__Impl"
    // InternalSimpleObjectDsl.g:505:1: rule__Qid__Group_1__0__Impl : ( '.' ) ;
    public final void rule__Qid__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:509:1: ( ( '.' ) )
            // InternalSimpleObjectDsl.g:510:1: ( '.' )
            {
            // InternalSimpleObjectDsl.g:510:1: ( '.' )
            // InternalSimpleObjectDsl.g:511:2: '.'
            {
             before(grammarAccess.getQidAccess().getFullStopKeyword_1_0()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getQidAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group_1__0__Impl"


    // $ANTLR start "rule__Qid__Group_1__1"
    // InternalSimpleObjectDsl.g:520:1: rule__Qid__Group_1__1 : rule__Qid__Group_1__1__Impl ;
    public final void rule__Qid__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:524:1: ( rule__Qid__Group_1__1__Impl )
            // InternalSimpleObjectDsl.g:525:2: rule__Qid__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Qid__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group_1__1"


    // $ANTLR start "rule__Qid__Group_1__1__Impl"
    // InternalSimpleObjectDsl.g:531:1: rule__Qid__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__Qid__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:535:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:536:1: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:536:1: ( RULE_ID )
            // InternalSimpleObjectDsl.g:537:2: RULE_ID
            {
             before(grammarAccess.getQidAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getQidAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Qid__Group_1__1__Impl"


    // $ANTLR start "rule__ClassType__Group__0"
    // InternalSimpleObjectDsl.g:547:1: rule__ClassType__Group__0 : rule__ClassType__Group__0__Impl rule__ClassType__Group__1 ;
    public final void rule__ClassType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:551:1: ( rule__ClassType__Group__0__Impl rule__ClassType__Group__1 )
            // InternalSimpleObjectDsl.g:552:2: rule__ClassType__Group__0__Impl rule__ClassType__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__ClassType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClassType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__0"


    // $ANTLR start "rule__ClassType__Group__0__Impl"
    // InternalSimpleObjectDsl.g:559:1: rule__ClassType__Group__0__Impl : ( 'class' ) ;
    public final void rule__ClassType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:563:1: ( ( 'class' ) )
            // InternalSimpleObjectDsl.g:564:1: ( 'class' )
            {
            // InternalSimpleObjectDsl.g:564:1: ( 'class' )
            // InternalSimpleObjectDsl.g:565:2: 'class'
            {
             before(grammarAccess.getClassTypeAccess().getClassKeyword_0()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getClassTypeAccess().getClassKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__0__Impl"


    // $ANTLR start "rule__ClassType__Group__1"
    // InternalSimpleObjectDsl.g:574:1: rule__ClassType__Group__1 : rule__ClassType__Group__1__Impl rule__ClassType__Group__2 ;
    public final void rule__ClassType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:578:1: ( rule__ClassType__Group__1__Impl rule__ClassType__Group__2 )
            // InternalSimpleObjectDsl.g:579:2: rule__ClassType__Group__1__Impl rule__ClassType__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__ClassType__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClassType__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__1"


    // $ANTLR start "rule__ClassType__Group__1__Impl"
    // InternalSimpleObjectDsl.g:586:1: rule__ClassType__Group__1__Impl : ( ( rule__ClassType__NameAssignment_1 ) ) ;
    public final void rule__ClassType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:590:1: ( ( ( rule__ClassType__NameAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:591:1: ( ( rule__ClassType__NameAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:591:1: ( ( rule__ClassType__NameAssignment_1 ) )
            // InternalSimpleObjectDsl.g:592:2: ( rule__ClassType__NameAssignment_1 )
            {
             before(grammarAccess.getClassTypeAccess().getNameAssignment_1()); 
            // InternalSimpleObjectDsl.g:593:2: ( rule__ClassType__NameAssignment_1 )
            // InternalSimpleObjectDsl.g:593:3: rule__ClassType__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ClassType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClassTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__1__Impl"


    // $ANTLR start "rule__ClassType__Group__2"
    // InternalSimpleObjectDsl.g:601:1: rule__ClassType__Group__2 : rule__ClassType__Group__2__Impl rule__ClassType__Group__3 ;
    public final void rule__ClassType__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:605:1: ( rule__ClassType__Group__2__Impl rule__ClassType__Group__3 )
            // InternalSimpleObjectDsl.g:606:2: rule__ClassType__Group__2__Impl rule__ClassType__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__ClassType__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClassType__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__2"


    // $ANTLR start "rule__ClassType__Group__2__Impl"
    // InternalSimpleObjectDsl.g:613:1: rule__ClassType__Group__2__Impl : ( '{' ) ;
    public final void rule__ClassType__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:617:1: ( ( '{' ) )
            // InternalSimpleObjectDsl.g:618:1: ( '{' )
            {
            // InternalSimpleObjectDsl.g:618:1: ( '{' )
            // InternalSimpleObjectDsl.g:619:2: '{'
            {
             before(grammarAccess.getClassTypeAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getClassTypeAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__2__Impl"


    // $ANTLR start "rule__ClassType__Group__3"
    // InternalSimpleObjectDsl.g:628:1: rule__ClassType__Group__3 : rule__ClassType__Group__3__Impl rule__ClassType__Group__4 ;
    public final void rule__ClassType__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:632:1: ( rule__ClassType__Group__3__Impl rule__ClassType__Group__4 )
            // InternalSimpleObjectDsl.g:633:2: rule__ClassType__Group__3__Impl rule__ClassType__Group__4
            {
            pushFollow(FOLLOW_10);
            rule__ClassType__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ClassType__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__3"


    // $ANTLR start "rule__ClassType__Group__3__Impl"
    // InternalSimpleObjectDsl.g:640:1: rule__ClassType__Group__3__Impl : ( ( rule__ClassType__FieldsAssignment_3 )* ) ;
    public final void rule__ClassType__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:644:1: ( ( ( rule__ClassType__FieldsAssignment_3 )* ) )
            // InternalSimpleObjectDsl.g:645:1: ( ( rule__ClassType__FieldsAssignment_3 )* )
            {
            // InternalSimpleObjectDsl.g:645:1: ( ( rule__ClassType__FieldsAssignment_3 )* )
            // InternalSimpleObjectDsl.g:646:2: ( rule__ClassType__FieldsAssignment_3 )*
            {
             before(grammarAccess.getClassTypeAccess().getFieldsAssignment_3()); 
            // InternalSimpleObjectDsl.g:647:2: ( rule__ClassType__FieldsAssignment_3 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID||(LA6_0>=11 && LA6_0<=13)||LA6_0==19) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:647:3: rule__ClassType__FieldsAssignment_3
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__ClassType__FieldsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getClassTypeAccess().getFieldsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__3__Impl"


    // $ANTLR start "rule__ClassType__Group__4"
    // InternalSimpleObjectDsl.g:655:1: rule__ClassType__Group__4 : rule__ClassType__Group__4__Impl ;
    public final void rule__ClassType__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:659:1: ( rule__ClassType__Group__4__Impl )
            // InternalSimpleObjectDsl.g:660:2: rule__ClassType__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ClassType__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__4"


    // $ANTLR start "rule__ClassType__Group__4__Impl"
    // InternalSimpleObjectDsl.g:666:1: rule__ClassType__Group__4__Impl : ( '}' ) ;
    public final void rule__ClassType__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:670:1: ( ( '}' ) )
            // InternalSimpleObjectDsl.g:671:1: ( '}' )
            {
            // InternalSimpleObjectDsl.g:671:1: ( '}' )
            // InternalSimpleObjectDsl.g:672:2: '}'
            {
             before(grammarAccess.getClassTypeAccess().getRightCurlyBracketKeyword_4()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getClassTypeAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__4__Impl"


    // $ANTLR start "rule__BasicField__Group__0"
    // InternalSimpleObjectDsl.g:682:1: rule__BasicField__Group__0 : rule__BasicField__Group__0__Impl rule__BasicField__Group__1 ;
    public final void rule__BasicField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:686:1: ( rule__BasicField__Group__0__Impl rule__BasicField__Group__1 )
            // InternalSimpleObjectDsl.g:687:2: rule__BasicField__Group__0__Impl rule__BasicField__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__BasicField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__BasicField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__Group__0"


    // $ANTLR start "rule__BasicField__Group__0__Impl"
    // InternalSimpleObjectDsl.g:694:1: rule__BasicField__Group__0__Impl : ( ( rule__BasicField__TypeAssignment_0 ) ) ;
    public final void rule__BasicField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:698:1: ( ( ( rule__BasicField__TypeAssignment_0 ) ) )
            // InternalSimpleObjectDsl.g:699:1: ( ( rule__BasicField__TypeAssignment_0 ) )
            {
            // InternalSimpleObjectDsl.g:699:1: ( ( rule__BasicField__TypeAssignment_0 ) )
            // InternalSimpleObjectDsl.g:700:2: ( rule__BasicField__TypeAssignment_0 )
            {
             before(grammarAccess.getBasicFieldAccess().getTypeAssignment_0()); 
            // InternalSimpleObjectDsl.g:701:2: ( rule__BasicField__TypeAssignment_0 )
            // InternalSimpleObjectDsl.g:701:3: rule__BasicField__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__BasicField__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getBasicFieldAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__Group__0__Impl"


    // $ANTLR start "rule__BasicField__Group__1"
    // InternalSimpleObjectDsl.g:709:1: rule__BasicField__Group__1 : rule__BasicField__Group__1__Impl ;
    public final void rule__BasicField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:713:1: ( rule__BasicField__Group__1__Impl )
            // InternalSimpleObjectDsl.g:714:2: rule__BasicField__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__BasicField__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__Group__1"


    // $ANTLR start "rule__BasicField__Group__1__Impl"
    // InternalSimpleObjectDsl.g:720:1: rule__BasicField__Group__1__Impl : ( ( rule__BasicField__NameAssignment_1 ) ) ;
    public final void rule__BasicField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:724:1: ( ( ( rule__BasicField__NameAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:725:1: ( ( rule__BasicField__NameAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:725:1: ( ( rule__BasicField__NameAssignment_1 ) )
            // InternalSimpleObjectDsl.g:726:2: ( rule__BasicField__NameAssignment_1 )
            {
             before(grammarAccess.getBasicFieldAccess().getNameAssignment_1()); 
            // InternalSimpleObjectDsl.g:727:2: ( rule__BasicField__NameAssignment_1 )
            // InternalSimpleObjectDsl.g:727:3: rule__BasicField__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__BasicField__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getBasicFieldAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__Group__1__Impl"


    // $ANTLR start "rule__PrimitiveField__Group__0"
    // InternalSimpleObjectDsl.g:736:1: rule__PrimitiveField__Group__0 : rule__PrimitiveField__Group__0__Impl rule__PrimitiveField__Group__1 ;
    public final void rule__PrimitiveField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:740:1: ( rule__PrimitiveField__Group__0__Impl rule__PrimitiveField__Group__1 )
            // InternalSimpleObjectDsl.g:741:2: rule__PrimitiveField__Group__0__Impl rule__PrimitiveField__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__PrimitiveField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__PrimitiveField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__Group__0"


    // $ANTLR start "rule__PrimitiveField__Group__0__Impl"
    // InternalSimpleObjectDsl.g:748:1: rule__PrimitiveField__Group__0__Impl : ( ( rule__PrimitiveField__TypeAssignment_0 ) ) ;
    public final void rule__PrimitiveField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:752:1: ( ( ( rule__PrimitiveField__TypeAssignment_0 ) ) )
            // InternalSimpleObjectDsl.g:753:1: ( ( rule__PrimitiveField__TypeAssignment_0 ) )
            {
            // InternalSimpleObjectDsl.g:753:1: ( ( rule__PrimitiveField__TypeAssignment_0 ) )
            // InternalSimpleObjectDsl.g:754:2: ( rule__PrimitiveField__TypeAssignment_0 )
            {
             before(grammarAccess.getPrimitiveFieldAccess().getTypeAssignment_0()); 
            // InternalSimpleObjectDsl.g:755:2: ( rule__PrimitiveField__TypeAssignment_0 )
            // InternalSimpleObjectDsl.g:755:3: rule__PrimitiveField__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__PrimitiveField__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveFieldAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__Group__0__Impl"


    // $ANTLR start "rule__PrimitiveField__Group__1"
    // InternalSimpleObjectDsl.g:763:1: rule__PrimitiveField__Group__1 : rule__PrimitiveField__Group__1__Impl ;
    public final void rule__PrimitiveField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:767:1: ( rule__PrimitiveField__Group__1__Impl )
            // InternalSimpleObjectDsl.g:768:2: rule__PrimitiveField__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PrimitiveField__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__Group__1"


    // $ANTLR start "rule__PrimitiveField__Group__1__Impl"
    // InternalSimpleObjectDsl.g:774:1: rule__PrimitiveField__Group__1__Impl : ( ( rule__PrimitiveField__NameAssignment_1 ) ) ;
    public final void rule__PrimitiveField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:778:1: ( ( ( rule__PrimitiveField__NameAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:779:1: ( ( rule__PrimitiveField__NameAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:779:1: ( ( rule__PrimitiveField__NameAssignment_1 ) )
            // InternalSimpleObjectDsl.g:780:2: ( rule__PrimitiveField__NameAssignment_1 )
            {
             before(grammarAccess.getPrimitiveFieldAccess().getNameAssignment_1()); 
            // InternalSimpleObjectDsl.g:781:2: ( rule__PrimitiveField__NameAssignment_1 )
            // InternalSimpleObjectDsl.g:781:3: rule__PrimitiveField__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PrimitiveField__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveFieldAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__Group__1__Impl"


    // $ANTLR start "rule__ListField__Group__0"
    // InternalSimpleObjectDsl.g:790:1: rule__ListField__Group__0 : rule__ListField__Group__0__Impl rule__ListField__Group__1 ;
    public final void rule__ListField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:794:1: ( rule__ListField__Group__0__Impl rule__ListField__Group__1 )
            // InternalSimpleObjectDsl.g:795:2: rule__ListField__Group__0__Impl rule__ListField__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__ListField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__0"


    // $ANTLR start "rule__ListField__Group__0__Impl"
    // InternalSimpleObjectDsl.g:802:1: rule__ListField__Group__0__Impl : ( 'List' ) ;
    public final void rule__ListField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:806:1: ( ( 'List' ) )
            // InternalSimpleObjectDsl.g:807:1: ( 'List' )
            {
            // InternalSimpleObjectDsl.g:807:1: ( 'List' )
            // InternalSimpleObjectDsl.g:808:2: 'List'
            {
             before(grammarAccess.getListFieldAccess().getListKeyword_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getListFieldAccess().getListKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__0__Impl"


    // $ANTLR start "rule__ListField__Group__1"
    // InternalSimpleObjectDsl.g:817:1: rule__ListField__Group__1 : rule__ListField__Group__1__Impl rule__ListField__Group__2 ;
    public final void rule__ListField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:821:1: ( rule__ListField__Group__1__Impl rule__ListField__Group__2 )
            // InternalSimpleObjectDsl.g:822:2: rule__ListField__Group__1__Impl rule__ListField__Group__2
            {
            pushFollow(FOLLOW_3);
            rule__ListField__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListField__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__1"


    // $ANTLR start "rule__ListField__Group__1__Impl"
    // InternalSimpleObjectDsl.g:829:1: rule__ListField__Group__1__Impl : ( ( rule__ListField__TypeAssignment_1 ) ) ;
    public final void rule__ListField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:833:1: ( ( ( rule__ListField__TypeAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:834:1: ( ( rule__ListField__TypeAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:834:1: ( ( rule__ListField__TypeAssignment_1 ) )
            // InternalSimpleObjectDsl.g:835:2: ( rule__ListField__TypeAssignment_1 )
            {
             before(grammarAccess.getListFieldAccess().getTypeAssignment_1()); 
            // InternalSimpleObjectDsl.g:836:2: ( rule__ListField__TypeAssignment_1 )
            // InternalSimpleObjectDsl.g:836:3: rule__ListField__TypeAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ListField__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__1__Impl"


    // $ANTLR start "rule__ListField__Group__2"
    // InternalSimpleObjectDsl.g:844:1: rule__ListField__Group__2 : rule__ListField__Group__2__Impl rule__ListField__Group__3 ;
    public final void rule__ListField__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:848:1: ( rule__ListField__Group__2__Impl rule__ListField__Group__3 )
            // InternalSimpleObjectDsl.g:849:2: rule__ListField__Group__2__Impl rule__ListField__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__ListField__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListField__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__2"


    // $ANTLR start "rule__ListField__Group__2__Impl"
    // InternalSimpleObjectDsl.g:856:1: rule__ListField__Group__2__Impl : ( ( rule__ListField__NameAssignment_2 ) ) ;
    public final void rule__ListField__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:860:1: ( ( ( rule__ListField__NameAssignment_2 ) ) )
            // InternalSimpleObjectDsl.g:861:1: ( ( rule__ListField__NameAssignment_2 ) )
            {
            // InternalSimpleObjectDsl.g:861:1: ( ( rule__ListField__NameAssignment_2 ) )
            // InternalSimpleObjectDsl.g:862:2: ( rule__ListField__NameAssignment_2 )
            {
             before(grammarAccess.getListFieldAccess().getNameAssignment_2()); 
            // InternalSimpleObjectDsl.g:863:2: ( rule__ListField__NameAssignment_2 )
            // InternalSimpleObjectDsl.g:863:3: rule__ListField__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ListField__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__2__Impl"


    // $ANTLR start "rule__ListField__Group__3"
    // InternalSimpleObjectDsl.g:871:1: rule__ListField__Group__3 : rule__ListField__Group__3__Impl rule__ListField__Group__4 ;
    public final void rule__ListField__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:875:1: ( rule__ListField__Group__3__Impl rule__ListField__Group__4 )
            // InternalSimpleObjectDsl.g:876:2: rule__ListField__Group__3__Impl rule__ListField__Group__4
            {
            pushFollow(FOLLOW_3);
            rule__ListField__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ListField__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__3"


    // $ANTLR start "rule__ListField__Group__3__Impl"
    // InternalSimpleObjectDsl.g:883:1: rule__ListField__Group__3__Impl : ( 'singular' ) ;
    public final void rule__ListField__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:887:1: ( ( 'singular' ) )
            // InternalSimpleObjectDsl.g:888:1: ( 'singular' )
            {
            // InternalSimpleObjectDsl.g:888:1: ( 'singular' )
            // InternalSimpleObjectDsl.g:889:2: 'singular'
            {
             before(grammarAccess.getListFieldAccess().getSingularKeyword_3()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getListFieldAccess().getSingularKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__3__Impl"


    // $ANTLR start "rule__ListField__Group__4"
    // InternalSimpleObjectDsl.g:898:1: rule__ListField__Group__4 : rule__ListField__Group__4__Impl ;
    public final void rule__ListField__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:902:1: ( rule__ListField__Group__4__Impl )
            // InternalSimpleObjectDsl.g:903:2: rule__ListField__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ListField__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__4"


    // $ANTLR start "rule__ListField__Group__4__Impl"
    // InternalSimpleObjectDsl.g:909:1: rule__ListField__Group__4__Impl : ( ( rule__ListField__SingularAssignment_4 ) ) ;
    public final void rule__ListField__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:913:1: ( ( ( rule__ListField__SingularAssignment_4 ) ) )
            // InternalSimpleObjectDsl.g:914:1: ( ( rule__ListField__SingularAssignment_4 ) )
            {
            // InternalSimpleObjectDsl.g:914:1: ( ( rule__ListField__SingularAssignment_4 ) )
            // InternalSimpleObjectDsl.g:915:2: ( rule__ListField__SingularAssignment_4 )
            {
             before(grammarAccess.getListFieldAccess().getSingularAssignment_4()); 
            // InternalSimpleObjectDsl.g:916:2: ( rule__ListField__SingularAssignment_4 )
            // InternalSimpleObjectDsl.g:916:3: rule__ListField__SingularAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__ListField__SingularAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getSingularAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__4__Impl"


    // $ANTLR start "rule__EnumType__Group__0"
    // InternalSimpleObjectDsl.g:925:1: rule__EnumType__Group__0 : rule__EnumType__Group__0__Impl rule__EnumType__Group__1 ;
    public final void rule__EnumType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:929:1: ( rule__EnumType__Group__0__Impl rule__EnumType__Group__1 )
            // InternalSimpleObjectDsl.g:930:2: rule__EnumType__Group__0__Impl rule__EnumType__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__EnumType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnumType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__0"


    // $ANTLR start "rule__EnumType__Group__0__Impl"
    // InternalSimpleObjectDsl.g:937:1: rule__EnumType__Group__0__Impl : ( 'enum' ) ;
    public final void rule__EnumType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:941:1: ( ( 'enum' ) )
            // InternalSimpleObjectDsl.g:942:1: ( 'enum' )
            {
            // InternalSimpleObjectDsl.g:942:1: ( 'enum' )
            // InternalSimpleObjectDsl.g:943:2: 'enum'
            {
             before(grammarAccess.getEnumTypeAccess().getEnumKeyword_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getEnumTypeAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__0__Impl"


    // $ANTLR start "rule__EnumType__Group__1"
    // InternalSimpleObjectDsl.g:952:1: rule__EnumType__Group__1 : rule__EnumType__Group__1__Impl rule__EnumType__Group__2 ;
    public final void rule__EnumType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:956:1: ( rule__EnumType__Group__1__Impl rule__EnumType__Group__2 )
            // InternalSimpleObjectDsl.g:957:2: rule__EnumType__Group__1__Impl rule__EnumType__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__EnumType__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnumType__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__1"


    // $ANTLR start "rule__EnumType__Group__1__Impl"
    // InternalSimpleObjectDsl.g:964:1: rule__EnumType__Group__1__Impl : ( ( rule__EnumType__NameAssignment_1 ) ) ;
    public final void rule__EnumType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:968:1: ( ( ( rule__EnumType__NameAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:969:1: ( ( rule__EnumType__NameAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:969:1: ( ( rule__EnumType__NameAssignment_1 ) )
            // InternalSimpleObjectDsl.g:970:2: ( rule__EnumType__NameAssignment_1 )
            {
             before(grammarAccess.getEnumTypeAccess().getNameAssignment_1()); 
            // InternalSimpleObjectDsl.g:971:2: ( rule__EnumType__NameAssignment_1 )
            // InternalSimpleObjectDsl.g:971:3: rule__EnumType__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__EnumType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__1__Impl"


    // $ANTLR start "rule__EnumType__Group__2"
    // InternalSimpleObjectDsl.g:979:1: rule__EnumType__Group__2 : rule__EnumType__Group__2__Impl rule__EnumType__Group__3 ;
    public final void rule__EnumType__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:983:1: ( rule__EnumType__Group__2__Impl rule__EnumType__Group__3 )
            // InternalSimpleObjectDsl.g:984:2: rule__EnumType__Group__2__Impl rule__EnumType__Group__3
            {
            pushFollow(FOLLOW_13);
            rule__EnumType__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnumType__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__2"


    // $ANTLR start "rule__EnumType__Group__2__Impl"
    // InternalSimpleObjectDsl.g:991:1: rule__EnumType__Group__2__Impl : ( '{' ) ;
    public final void rule__EnumType__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:995:1: ( ( '{' ) )
            // InternalSimpleObjectDsl.g:996:1: ( '{' )
            {
            // InternalSimpleObjectDsl.g:996:1: ( '{' )
            // InternalSimpleObjectDsl.g:997:2: '{'
            {
             before(grammarAccess.getEnumTypeAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getEnumTypeAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__2__Impl"


    // $ANTLR start "rule__EnumType__Group__3"
    // InternalSimpleObjectDsl.g:1006:1: rule__EnumType__Group__3 : rule__EnumType__Group__3__Impl rule__EnumType__Group__4 ;
    public final void rule__EnumType__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1010:1: ( rule__EnumType__Group__3__Impl rule__EnumType__Group__4 )
            // InternalSimpleObjectDsl.g:1011:2: rule__EnumType__Group__3__Impl rule__EnumType__Group__4
            {
            pushFollow(FOLLOW_13);
            rule__EnumType__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnumType__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__3"


    // $ANTLR start "rule__EnumType__Group__3__Impl"
    // InternalSimpleObjectDsl.g:1018:1: rule__EnumType__Group__3__Impl : ( ( rule__EnumType__ValuesAssignment_3 )* ) ;
    public final void rule__EnumType__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1022:1: ( ( ( rule__EnumType__ValuesAssignment_3 )* ) )
            // InternalSimpleObjectDsl.g:1023:1: ( ( rule__EnumType__ValuesAssignment_3 )* )
            {
            // InternalSimpleObjectDsl.g:1023:1: ( ( rule__EnumType__ValuesAssignment_3 )* )
            // InternalSimpleObjectDsl.g:1024:2: ( rule__EnumType__ValuesAssignment_3 )*
            {
             before(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 
            // InternalSimpleObjectDsl.g:1025:2: ( rule__EnumType__ValuesAssignment_3 )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalSimpleObjectDsl.g:1025:3: rule__EnumType__ValuesAssignment_3
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__EnumType__ValuesAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

             after(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__3__Impl"


    // $ANTLR start "rule__EnumType__Group__4"
    // InternalSimpleObjectDsl.g:1033:1: rule__EnumType__Group__4 : rule__EnumType__Group__4__Impl ;
    public final void rule__EnumType__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1037:1: ( rule__EnumType__Group__4__Impl )
            // InternalSimpleObjectDsl.g:1038:2: rule__EnumType__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EnumType__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__4"


    // $ANTLR start "rule__EnumType__Group__4__Impl"
    // InternalSimpleObjectDsl.g:1044:1: rule__EnumType__Group__4__Impl : ( '}' ) ;
    public final void rule__EnumType__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1048:1: ( ( '}' ) )
            // InternalSimpleObjectDsl.g:1049:1: ( '}' )
            {
            // InternalSimpleObjectDsl.g:1049:1: ( '}' )
            // InternalSimpleObjectDsl.g:1050:2: '}'
            {
             before(grammarAccess.getEnumTypeAccess().getRightCurlyBracketKeyword_4()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getEnumTypeAccess().getRightCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__4__Impl"


    // $ANTLR start "rule__EnumValue__Group__0"
    // InternalSimpleObjectDsl.g:1060:1: rule__EnumValue__Group__0 : rule__EnumValue__Group__0__Impl rule__EnumValue__Group__1 ;
    public final void rule__EnumValue__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1064:1: ( rule__EnumValue__Group__0__Impl rule__EnumValue__Group__1 )
            // InternalSimpleObjectDsl.g:1065:2: rule__EnumValue__Group__0__Impl rule__EnumValue__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__EnumValue__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EnumValue__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__Group__0"


    // $ANTLR start "rule__EnumValue__Group__0__Impl"
    // InternalSimpleObjectDsl.g:1072:1: rule__EnumValue__Group__0__Impl : ( ( rule__EnumValue__NameAssignment_0 ) ) ;
    public final void rule__EnumValue__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1076:1: ( ( ( rule__EnumValue__NameAssignment_0 ) ) )
            // InternalSimpleObjectDsl.g:1077:1: ( ( rule__EnumValue__NameAssignment_0 ) )
            {
            // InternalSimpleObjectDsl.g:1077:1: ( ( rule__EnumValue__NameAssignment_0 ) )
            // InternalSimpleObjectDsl.g:1078:2: ( rule__EnumValue__NameAssignment_0 )
            {
             before(grammarAccess.getEnumValueAccess().getNameAssignment_0()); 
            // InternalSimpleObjectDsl.g:1079:2: ( rule__EnumValue__NameAssignment_0 )
            // InternalSimpleObjectDsl.g:1079:3: rule__EnumValue__NameAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__EnumValue__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getEnumValueAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__Group__0__Impl"


    // $ANTLR start "rule__EnumValue__Group__1"
    // InternalSimpleObjectDsl.g:1087:1: rule__EnumValue__Group__1 : rule__EnumValue__Group__1__Impl ;
    public final void rule__EnumValue__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1091:1: ( rule__EnumValue__Group__1__Impl )
            // InternalSimpleObjectDsl.g:1092:2: rule__EnumValue__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EnumValue__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__Group__1"


    // $ANTLR start "rule__EnumValue__Group__1__Impl"
    // InternalSimpleObjectDsl.g:1098:1: rule__EnumValue__Group__1__Impl : ( ( rule__EnumValue__DisplayNameAssignment_1 ) ) ;
    public final void rule__EnumValue__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1102:1: ( ( ( rule__EnumValue__DisplayNameAssignment_1 ) ) )
            // InternalSimpleObjectDsl.g:1103:1: ( ( rule__EnumValue__DisplayNameAssignment_1 ) )
            {
            // InternalSimpleObjectDsl.g:1103:1: ( ( rule__EnumValue__DisplayNameAssignment_1 ) )
            // InternalSimpleObjectDsl.g:1104:2: ( rule__EnumValue__DisplayNameAssignment_1 )
            {
             before(grammarAccess.getEnumValueAccess().getDisplayNameAssignment_1()); 
            // InternalSimpleObjectDsl.g:1105:2: ( rule__EnumValue__DisplayNameAssignment_1 )
            // InternalSimpleObjectDsl.g:1105:3: rule__EnumValue__DisplayNameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__EnumValue__DisplayNameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumValueAccess().getDisplayNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__Group__1__Impl"


    // $ANTLR start "rule__Model__PkgAssignment_1"
    // InternalSimpleObjectDsl.g:1114:1: rule__Model__PkgAssignment_1 : ( ruleqid ) ;
    public final void rule__Model__PkgAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1118:1: ( ( ruleqid ) )
            // InternalSimpleObjectDsl.g:1119:2: ( ruleqid )
            {
            // InternalSimpleObjectDsl.g:1119:2: ( ruleqid )
            // InternalSimpleObjectDsl.g:1120:3: ruleqid
            {
             before(grammarAccess.getModelAccess().getPkgQidParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleqid();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPkgQidParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PkgAssignment_1"


    // $ANTLR start "rule__Model__ClassesAssignment_2"
    // InternalSimpleObjectDsl.g:1129:1: rule__Model__ClassesAssignment_2 : ( ruleClassType ) ;
    public final void rule__Model__ClassesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1133:1: ( ( ruleClassType ) )
            // InternalSimpleObjectDsl.g:1134:2: ( ruleClassType )
            {
            // InternalSimpleObjectDsl.g:1134:2: ( ruleClassType )
            // InternalSimpleObjectDsl.g:1135:3: ruleClassType
            {
             before(grammarAccess.getModelAccess().getClassesClassTypeParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleClassType();

            state._fsp--;

             after(grammarAccess.getModelAccess().getClassesClassTypeParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ClassesAssignment_2"


    // $ANTLR start "rule__Model__EnumsAssignment_3"
    // InternalSimpleObjectDsl.g:1144:1: rule__Model__EnumsAssignment_3 : ( ruleEnumType ) ;
    public final void rule__Model__EnumsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1148:1: ( ( ruleEnumType ) )
            // InternalSimpleObjectDsl.g:1149:2: ( ruleEnumType )
            {
            // InternalSimpleObjectDsl.g:1149:2: ( ruleEnumType )
            // InternalSimpleObjectDsl.g:1150:3: ruleEnumType
            {
             before(grammarAccess.getModelAccess().getEnumsEnumTypeParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEnumType();

            state._fsp--;

             after(grammarAccess.getModelAccess().getEnumsEnumTypeParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__EnumsAssignment_3"


    // $ANTLR start "rule__ClassType__NameAssignment_1"
    // InternalSimpleObjectDsl.g:1159:1: rule__ClassType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__ClassType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1163:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1164:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1164:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1165:3: RULE_ID
            {
             before(grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__NameAssignment_1"


    // $ANTLR start "rule__ClassType__FieldsAssignment_3"
    // InternalSimpleObjectDsl.g:1174:1: rule__ClassType__FieldsAssignment_3 : ( ruleFieldDecl ) ;
    public final void rule__ClassType__FieldsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1178:1: ( ( ruleFieldDecl ) )
            // InternalSimpleObjectDsl.g:1179:2: ( ruleFieldDecl )
            {
            // InternalSimpleObjectDsl.g:1179:2: ( ruleFieldDecl )
            // InternalSimpleObjectDsl.g:1180:3: ruleFieldDecl
            {
             before(grammarAccess.getClassTypeAccess().getFieldsFieldDeclParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleFieldDecl();

            state._fsp--;

             after(grammarAccess.getClassTypeAccess().getFieldsFieldDeclParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__FieldsAssignment_3"


    // $ANTLR start "rule__BasicField__TypeAssignment_0"
    // InternalSimpleObjectDsl.g:1189:1: rule__BasicField__TypeAssignment_0 : ( ( RULE_ID ) ) ;
    public final void rule__BasicField__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1193:1: ( ( ( RULE_ID ) ) )
            // InternalSimpleObjectDsl.g:1194:2: ( ( RULE_ID ) )
            {
            // InternalSimpleObjectDsl.g:1194:2: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1195:3: ( RULE_ID )
            {
             before(grammarAccess.getBasicFieldAccess().getTypeDeclaredTypeCrossReference_0_0()); 
            // InternalSimpleObjectDsl.g:1196:3: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1197:4: RULE_ID
            {
             before(grammarAccess.getBasicFieldAccess().getTypeDeclaredTypeIDTerminalRuleCall_0_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getBasicFieldAccess().getTypeDeclaredTypeIDTerminalRuleCall_0_0_1()); 

            }

             after(grammarAccess.getBasicFieldAccess().getTypeDeclaredTypeCrossReference_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__TypeAssignment_0"


    // $ANTLR start "rule__BasicField__NameAssignment_1"
    // InternalSimpleObjectDsl.g:1208:1: rule__BasicField__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__BasicField__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1212:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1213:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1213:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1214:3: RULE_ID
            {
             before(grammarAccess.getBasicFieldAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getBasicFieldAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__BasicField__NameAssignment_1"


    // $ANTLR start "rule__PrimitiveField__TypeAssignment_0"
    // InternalSimpleObjectDsl.g:1223:1: rule__PrimitiveField__TypeAssignment_0 : ( ( rule__PrimitiveField__TypeAlternatives_0_0 ) ) ;
    public final void rule__PrimitiveField__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1227:1: ( ( ( rule__PrimitiveField__TypeAlternatives_0_0 ) ) )
            // InternalSimpleObjectDsl.g:1228:2: ( ( rule__PrimitiveField__TypeAlternatives_0_0 ) )
            {
            // InternalSimpleObjectDsl.g:1228:2: ( ( rule__PrimitiveField__TypeAlternatives_0_0 ) )
            // InternalSimpleObjectDsl.g:1229:3: ( rule__PrimitiveField__TypeAlternatives_0_0 )
            {
             before(grammarAccess.getPrimitiveFieldAccess().getTypeAlternatives_0_0()); 
            // InternalSimpleObjectDsl.g:1230:3: ( rule__PrimitiveField__TypeAlternatives_0_0 )
            // InternalSimpleObjectDsl.g:1230:4: rule__PrimitiveField__TypeAlternatives_0_0
            {
            pushFollow(FOLLOW_2);
            rule__PrimitiveField__TypeAlternatives_0_0();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveFieldAccess().getTypeAlternatives_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__TypeAssignment_0"


    // $ANTLR start "rule__PrimitiveField__NameAssignment_1"
    // InternalSimpleObjectDsl.g:1238:1: rule__PrimitiveField__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__PrimitiveField__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1242:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1243:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1243:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1244:3: RULE_ID
            {
             before(grammarAccess.getPrimitiveFieldAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPrimitiveFieldAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveField__NameAssignment_1"


    // $ANTLR start "rule__ListField__TypeAssignment_1"
    // InternalSimpleObjectDsl.g:1253:1: rule__ListField__TypeAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__ListField__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1257:1: ( ( ( RULE_ID ) ) )
            // InternalSimpleObjectDsl.g:1258:2: ( ( RULE_ID ) )
            {
            // InternalSimpleObjectDsl.g:1258:2: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1259:3: ( RULE_ID )
            {
             before(grammarAccess.getListFieldAccess().getTypeClassTypeCrossReference_1_0()); 
            // InternalSimpleObjectDsl.g:1260:3: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1261:4: RULE_ID
            {
             before(grammarAccess.getListFieldAccess().getTypeClassTypeIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getListFieldAccess().getTypeClassTypeIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getListFieldAccess().getTypeClassTypeCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__TypeAssignment_1"


    // $ANTLR start "rule__ListField__NameAssignment_2"
    // InternalSimpleObjectDsl.g:1272:1: rule__ListField__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__ListField__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1276:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1277:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1277:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1278:3: RULE_ID
            {
             before(grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__NameAssignment_2"


    // $ANTLR start "rule__ListField__SingularAssignment_4"
    // InternalSimpleObjectDsl.g:1287:1: rule__ListField__SingularAssignment_4 : ( RULE_ID ) ;
    public final void rule__ListField__SingularAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1291:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1292:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1292:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1293:3: RULE_ID
            {
             before(grammarAccess.getListFieldAccess().getSingularIDTerminalRuleCall_4_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getListFieldAccess().getSingularIDTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__SingularAssignment_4"


    // $ANTLR start "rule__EnumType__NameAssignment_1"
    // InternalSimpleObjectDsl.g:1302:1: rule__EnumType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__EnumType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1306:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1307:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1307:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1308:3: RULE_ID
            {
             before(grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__NameAssignment_1"


    // $ANTLR start "rule__EnumType__ValuesAssignment_3"
    // InternalSimpleObjectDsl.g:1317:1: rule__EnumType__ValuesAssignment_3 : ( ruleEnumValue ) ;
    public final void rule__EnumType__ValuesAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1321:1: ( ( ruleEnumValue ) )
            // InternalSimpleObjectDsl.g:1322:2: ( ruleEnumValue )
            {
            // InternalSimpleObjectDsl.g:1322:2: ( ruleEnumValue )
            // InternalSimpleObjectDsl.g:1323:3: ruleEnumValue
            {
             before(grammarAccess.getEnumTypeAccess().getValuesEnumValueParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEnumValue();

            state._fsp--;

             after(grammarAccess.getEnumTypeAccess().getValuesEnumValueParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__ValuesAssignment_3"


    // $ANTLR start "rule__EnumValue__NameAssignment_0"
    // InternalSimpleObjectDsl.g:1332:1: rule__EnumValue__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__EnumValue__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1336:1: ( ( RULE_ID ) )
            // InternalSimpleObjectDsl.g:1337:2: ( RULE_ID )
            {
            // InternalSimpleObjectDsl.g:1337:2: ( RULE_ID )
            // InternalSimpleObjectDsl.g:1338:3: RULE_ID
            {
             before(grammarAccess.getEnumValueAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumValueAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__NameAssignment_0"


    // $ANTLR start "rule__EnumValue__DisplayNameAssignment_1"
    // InternalSimpleObjectDsl.g:1347:1: rule__EnumValue__DisplayNameAssignment_1 : ( RULE_STRING ) ;
    public final void rule__EnumValue__DisplayNameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSimpleObjectDsl.g:1351:1: ( ( RULE_STRING ) )
            // InternalSimpleObjectDsl.g:1352:2: ( RULE_STRING )
            {
            // InternalSimpleObjectDsl.g:1352:2: ( RULE_STRING )
            // InternalSimpleObjectDsl.g:1353:3: RULE_STRING
            {
             before(grammarAccess.getEnumValueAccess().getDisplayNameSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEnumValueAccess().getDisplayNameSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumValue__DisplayNameAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000210000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000200002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000008002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x00000000000C3810L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000083812L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000020L});

}