package com.javadude.adventuredsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import com.javadude.adventuredsl.services.AdventureDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAdventureDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'start'", "'in'", "'carryable'", "'fixed'", "'item'", "'opens'", "'with'", "'locked'", "'unlocked'", "'open'", "'closed'", "'contains'", "','", "'room'", "'exit'", "'north'", "'south'", "'east'", "'west'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalAdventureDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalAdventureDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalAdventureDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalAdventureDsl.g"; }



     	private AdventureDslGrammarAccess grammarAccess;

        public InternalAdventureDslParser(TokenStream input, AdventureDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected AdventureDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalAdventureDsl.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalAdventureDsl.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalAdventureDsl.g:66:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalAdventureDsl.g:72:1: ruleModel returns [EObject current=null] : ( ( (lv_items_0_0= ruleItem ) )+ ( (lv_rooms_1_0= ruleRoom ) )+ otherlv_2= 'start' otherlv_3= 'in' ( (otherlv_4= RULE_ID ) ) ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        EObject lv_items_0_0 = null;

        EObject lv_rooms_1_0 = null;



        	enterRule();

        try {
            // InternalAdventureDsl.g:78:2: ( ( ( (lv_items_0_0= ruleItem ) )+ ( (lv_rooms_1_0= ruleRoom ) )+ otherlv_2= 'start' otherlv_3= 'in' ( (otherlv_4= RULE_ID ) ) ) )
            // InternalAdventureDsl.g:79:2: ( ( (lv_items_0_0= ruleItem ) )+ ( (lv_rooms_1_0= ruleRoom ) )+ otherlv_2= 'start' otherlv_3= 'in' ( (otherlv_4= RULE_ID ) ) )
            {
            // InternalAdventureDsl.g:79:2: ( ( (lv_items_0_0= ruleItem ) )+ ( (lv_rooms_1_0= ruleRoom ) )+ otherlv_2= 'start' otherlv_3= 'in' ( (otherlv_4= RULE_ID ) ) )
            // InternalAdventureDsl.g:80:3: ( (lv_items_0_0= ruleItem ) )+ ( (lv_rooms_1_0= ruleRoom ) )+ otherlv_2= 'start' otherlv_3= 'in' ( (otherlv_4= RULE_ID ) )
            {
            // InternalAdventureDsl.g:80:3: ( (lv_items_0_0= ruleItem ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=13 && LA1_0<=14)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalAdventureDsl.g:81:4: (lv_items_0_0= ruleItem )
            	    {
            	    // InternalAdventureDsl.g:81:4: (lv_items_0_0= ruleItem )
            	    // InternalAdventureDsl.g:82:5: lv_items_0_0= ruleItem
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getItemsItemParserRuleCall_0_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_items_0_0=ruleItem();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"items",
            	    						lv_items_0_0,
            	    						"com.javadude.adventuredsl.AdventureDsl.Item");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            // InternalAdventureDsl.g:99:3: ( (lv_rooms_1_0= ruleRoom ) )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==24) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // InternalAdventureDsl.g:100:4: (lv_rooms_1_0= ruleRoom )
            	    {
            	    // InternalAdventureDsl.g:100:4: (lv_rooms_1_0= ruleRoom )
            	    // InternalAdventureDsl.g:101:5: lv_rooms_1_0= ruleRoom
            	    {

            	    					newCompositeNode(grammarAccess.getModelAccess().getRoomsRoomParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_rooms_1_0=ruleRoom();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getModelRule());
            	    					}
            	    					add(
            	    						current,
            	    						"rooms",
            	    						lv_rooms_1_0,
            	    						"com.javadude.adventuredsl.AdventureDsl.Room");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            otherlv_2=(Token)match(input,11,FOLLOW_5); 

            			newLeafNode(otherlv_2, grammarAccess.getModelAccess().getStartKeyword_2());
            		
            otherlv_3=(Token)match(input,12,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getModelAccess().getInKeyword_3());
            		
            // InternalAdventureDsl.g:126:3: ( (otherlv_4= RULE_ID ) )
            // InternalAdventureDsl.g:127:4: (otherlv_4= RULE_ID )
            {
            // InternalAdventureDsl.g:127:4: (otherlv_4= RULE_ID )
            // InternalAdventureDsl.g:128:5: otherlv_4= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModelRule());
            					}
            				
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_4, grammarAccess.getModelAccess().getStartRoomRoomCrossReference_4_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleItem"
    // InternalAdventureDsl.g:143:1: entryRuleItem returns [EObject current=null] : iv_ruleItem= ruleItem EOF ;
    public final EObject entryRuleItem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleItem = null;


        try {
            // InternalAdventureDsl.g:143:45: (iv_ruleItem= ruleItem EOF )
            // InternalAdventureDsl.g:144:2: iv_ruleItem= ruleItem EOF
            {
             newCompositeNode(grammarAccess.getItemRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleItem=ruleItem();

            state._fsp--;

             current =iv_ruleItem; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleItem"


    // $ANTLR start "ruleItem"
    // InternalAdventureDsl.g:150:1: ruleItem returns [EObject current=null] : ( ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' ) otherlv_2= 'item' ( (lv_name_3_0= RULE_ID ) ) ( (lv_description_4_0= RULE_STRING ) ) (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )? ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )? ) ;
    public final EObject ruleItem() throws RecognitionException {
        EObject current = null;

        Token lv_carryable_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_name_3_0=null;
        Token lv_description_4_0=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token lv_locked_8_0=null;
        Token otherlv_9=null;
        Token lv_open_10_0=null;
        Token otherlv_11=null;
        Token lv_container_12_0=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_15=null;


        	enterRule();

        try {
            // InternalAdventureDsl.g:156:2: ( ( ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' ) otherlv_2= 'item' ( (lv_name_3_0= RULE_ID ) ) ( (lv_description_4_0= RULE_STRING ) ) (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )? ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )? ) )
            // InternalAdventureDsl.g:157:2: ( ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' ) otherlv_2= 'item' ( (lv_name_3_0= RULE_ID ) ) ( (lv_description_4_0= RULE_STRING ) ) (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )? ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )? )
            {
            // InternalAdventureDsl.g:157:2: ( ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' ) otherlv_2= 'item' ( (lv_name_3_0= RULE_ID ) ) ( (lv_description_4_0= RULE_STRING ) ) (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )? ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )? )
            // InternalAdventureDsl.g:158:3: ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' ) otherlv_2= 'item' ( (lv_name_3_0= RULE_ID ) ) ( (lv_description_4_0= RULE_STRING ) ) (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )? ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )?
            {
            // InternalAdventureDsl.g:158:3: ( ( (lv_carryable_0_0= 'carryable' ) ) | otherlv_1= 'fixed' )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==13) ) {
                alt3=1;
            }
            else if ( (LA3_0==14) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalAdventureDsl.g:159:4: ( (lv_carryable_0_0= 'carryable' ) )
                    {
                    // InternalAdventureDsl.g:159:4: ( (lv_carryable_0_0= 'carryable' ) )
                    // InternalAdventureDsl.g:160:5: (lv_carryable_0_0= 'carryable' )
                    {
                    // InternalAdventureDsl.g:160:5: (lv_carryable_0_0= 'carryable' )
                    // InternalAdventureDsl.g:161:6: lv_carryable_0_0= 'carryable'
                    {
                    lv_carryable_0_0=(Token)match(input,13,FOLLOW_7); 

                    						newLeafNode(lv_carryable_0_0, grammarAccess.getItemAccess().getCarryableCarryableKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getItemRule());
                    						}
                    						setWithLastConsumed(current, "carryable", true, "carryable");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:174:4: otherlv_1= 'fixed'
                    {
                    otherlv_1=(Token)match(input,14,FOLLOW_7); 

                    				newLeafNode(otherlv_1, grammarAccess.getItemAccess().getFixedKeyword_0_1());
                    			

                    }
                    break;

            }

            otherlv_2=(Token)match(input,15,FOLLOW_6); 

            			newLeafNode(otherlv_2, grammarAccess.getItemAccess().getItemKeyword_1());
            		
            // InternalAdventureDsl.g:183:3: ( (lv_name_3_0= RULE_ID ) )
            // InternalAdventureDsl.g:184:4: (lv_name_3_0= RULE_ID )
            {
            // InternalAdventureDsl.g:184:4: (lv_name_3_0= RULE_ID )
            // InternalAdventureDsl.g:185:5: lv_name_3_0= RULE_ID
            {
            lv_name_3_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_3_0, grammarAccess.getItemAccess().getNameIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getItemRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_3_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalAdventureDsl.g:201:3: ( (lv_description_4_0= RULE_STRING ) )
            // InternalAdventureDsl.g:202:4: (lv_description_4_0= RULE_STRING )
            {
            // InternalAdventureDsl.g:202:4: (lv_description_4_0= RULE_STRING )
            // InternalAdventureDsl.g:203:5: lv_description_4_0= RULE_STRING
            {
            lv_description_4_0=(Token)match(input,RULE_STRING,FOLLOW_9); 

            					newLeafNode(lv_description_4_0, grammarAccess.getItemAccess().getDescriptionSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getItemRule());
            					}
            					setWithLastConsumed(
            						current,
            						"description",
            						lv_description_4_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalAdventureDsl.g:219:3: (otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==16) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalAdventureDsl.g:220:4: otherlv_5= 'opens' otherlv_6= 'with' ( (otherlv_7= RULE_ID ) ) ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' ) ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' )
                    {
                    otherlv_5=(Token)match(input,16,FOLLOW_10); 

                    				newLeafNode(otherlv_5, grammarAccess.getItemAccess().getOpensKeyword_4_0());
                    			
                    otherlv_6=(Token)match(input,17,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getItemAccess().getWithKeyword_4_1());
                    			
                    // InternalAdventureDsl.g:228:4: ( (otherlv_7= RULE_ID ) )
                    // InternalAdventureDsl.g:229:5: (otherlv_7= RULE_ID )
                    {
                    // InternalAdventureDsl.g:229:5: (otherlv_7= RULE_ID )
                    // InternalAdventureDsl.g:230:6: otherlv_7= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getItemRule());
                    						}
                    					
                    otherlv_7=(Token)match(input,RULE_ID,FOLLOW_11); 

                    						newLeafNode(otherlv_7, grammarAccess.getItemAccess().getKeyItemCrossReference_4_2_0());
                    					

                    }


                    }

                    // InternalAdventureDsl.g:241:4: ( ( (lv_locked_8_0= 'locked' ) ) | otherlv_9= 'unlocked' )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==18) ) {
                        alt4=1;
                    }
                    else if ( (LA4_0==19) ) {
                        alt4=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // InternalAdventureDsl.g:242:5: ( (lv_locked_8_0= 'locked' ) )
                            {
                            // InternalAdventureDsl.g:242:5: ( (lv_locked_8_0= 'locked' ) )
                            // InternalAdventureDsl.g:243:6: (lv_locked_8_0= 'locked' )
                            {
                            // InternalAdventureDsl.g:243:6: (lv_locked_8_0= 'locked' )
                            // InternalAdventureDsl.g:244:7: lv_locked_8_0= 'locked'
                            {
                            lv_locked_8_0=(Token)match(input,18,FOLLOW_12); 

                            							newLeafNode(lv_locked_8_0, grammarAccess.getItemAccess().getLockedLockedKeyword_4_3_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getItemRule());
                            							}
                            							setWithLastConsumed(current, "locked", true, "locked");
                            						

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalAdventureDsl.g:257:5: otherlv_9= 'unlocked'
                            {
                            otherlv_9=(Token)match(input,19,FOLLOW_12); 

                            					newLeafNode(otherlv_9, grammarAccess.getItemAccess().getUnlockedKeyword_4_3_1());
                            				

                            }
                            break;

                    }

                    // InternalAdventureDsl.g:262:4: ( ( (lv_open_10_0= 'open' ) ) | otherlv_11= 'closed' )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==20) ) {
                        alt5=1;
                    }
                    else if ( (LA5_0==21) ) {
                        alt5=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalAdventureDsl.g:263:5: ( (lv_open_10_0= 'open' ) )
                            {
                            // InternalAdventureDsl.g:263:5: ( (lv_open_10_0= 'open' ) )
                            // InternalAdventureDsl.g:264:6: (lv_open_10_0= 'open' )
                            {
                            // InternalAdventureDsl.g:264:6: (lv_open_10_0= 'open' )
                            // InternalAdventureDsl.g:265:7: lv_open_10_0= 'open'
                            {
                            lv_open_10_0=(Token)match(input,20,FOLLOW_13); 

                            							newLeafNode(lv_open_10_0, grammarAccess.getItemAccess().getOpenOpenKeyword_4_4_0_0());
                            						

                            							if (current==null) {
                            								current = createModelElement(grammarAccess.getItemRule());
                            							}
                            							setWithLastConsumed(current, "open", true, "open");
                            						

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalAdventureDsl.g:278:5: otherlv_11= 'closed'
                            {
                            otherlv_11=(Token)match(input,21,FOLLOW_13); 

                            					newLeafNode(otherlv_11, grammarAccess.getItemAccess().getClosedKeyword_4_4_1());
                            				

                            }
                            break;

                    }


                    }
                    break;

            }

            // InternalAdventureDsl.g:284:3: ( ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )* )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==22) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalAdventureDsl.g:285:4: ( (lv_container_12_0= 'contains' ) ) ( (otherlv_13= RULE_ID ) ) (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )*
                    {
                    // InternalAdventureDsl.g:285:4: ( (lv_container_12_0= 'contains' ) )
                    // InternalAdventureDsl.g:286:5: (lv_container_12_0= 'contains' )
                    {
                    // InternalAdventureDsl.g:286:5: (lv_container_12_0= 'contains' )
                    // InternalAdventureDsl.g:287:6: lv_container_12_0= 'contains'
                    {
                    lv_container_12_0=(Token)match(input,22,FOLLOW_6); 

                    						newLeafNode(lv_container_12_0, grammarAccess.getItemAccess().getContainerContainsKeyword_5_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getItemRule());
                    						}
                    						setWithLastConsumed(current, "container", true, "contains");
                    					

                    }


                    }

                    // InternalAdventureDsl.g:299:4: ( (otherlv_13= RULE_ID ) )
                    // InternalAdventureDsl.g:300:5: (otherlv_13= RULE_ID )
                    {
                    // InternalAdventureDsl.g:300:5: (otherlv_13= RULE_ID )
                    // InternalAdventureDsl.g:301:6: otherlv_13= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getItemRule());
                    						}
                    					
                    otherlv_13=(Token)match(input,RULE_ID,FOLLOW_14); 

                    						newLeafNode(otherlv_13, grammarAccess.getItemAccess().getContentsItemCrossReference_5_1_0());
                    					

                    }


                    }

                    // InternalAdventureDsl.g:312:4: (otherlv_14= ',' ( (otherlv_15= RULE_ID ) ) )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( (LA7_0==23) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // InternalAdventureDsl.g:313:5: otherlv_14= ',' ( (otherlv_15= RULE_ID ) )
                    	    {
                    	    otherlv_14=(Token)match(input,23,FOLLOW_6); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getItemAccess().getCommaKeyword_5_2_0());
                    	    				
                    	    // InternalAdventureDsl.g:317:5: ( (otherlv_15= RULE_ID ) )
                    	    // InternalAdventureDsl.g:318:6: (otherlv_15= RULE_ID )
                    	    {
                    	    // InternalAdventureDsl.g:318:6: (otherlv_15= RULE_ID )
                    	    // InternalAdventureDsl.g:319:7: otherlv_15= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getItemRule());
                    	    							}
                    	    						
                    	    otherlv_15=(Token)match(input,RULE_ID,FOLLOW_14); 

                    	    							newLeafNode(otherlv_15, grammarAccess.getItemAccess().getContentsItemCrossReference_5_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleItem"


    // $ANTLR start "entryRuleRoom"
    // InternalAdventureDsl.g:336:1: entryRuleRoom returns [EObject current=null] : iv_ruleRoom= ruleRoom EOF ;
    public final EObject entryRuleRoom() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRoom = null;


        try {
            // InternalAdventureDsl.g:336:45: (iv_ruleRoom= ruleRoom EOF )
            // InternalAdventureDsl.g:337:2: iv_ruleRoom= ruleRoom EOF
            {
             newCompositeNode(grammarAccess.getRoomRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRoom=ruleRoom();

            state._fsp--;

             current =iv_ruleRoom; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRoom"


    // $ANTLR start "ruleRoom"
    // InternalAdventureDsl.g:343:1: ruleRoom returns [EObject current=null] : (otherlv_0= 'room' ( (lv_name_1_0= RULE_ID ) ) ( (lv_description_2_0= RULE_STRING ) ) (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )? ( (lv_exits_7_0= ruleExit ) )* ) ;
    public final EObject ruleRoom() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token lv_description_2_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        EObject lv_exits_7_0 = null;



        	enterRule();

        try {
            // InternalAdventureDsl.g:349:2: ( (otherlv_0= 'room' ( (lv_name_1_0= RULE_ID ) ) ( (lv_description_2_0= RULE_STRING ) ) (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )? ( (lv_exits_7_0= ruleExit ) )* ) )
            // InternalAdventureDsl.g:350:2: (otherlv_0= 'room' ( (lv_name_1_0= RULE_ID ) ) ( (lv_description_2_0= RULE_STRING ) ) (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )? ( (lv_exits_7_0= ruleExit ) )* )
            {
            // InternalAdventureDsl.g:350:2: (otherlv_0= 'room' ( (lv_name_1_0= RULE_ID ) ) ( (lv_description_2_0= RULE_STRING ) ) (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )? ( (lv_exits_7_0= ruleExit ) )* )
            // InternalAdventureDsl.g:351:3: otherlv_0= 'room' ( (lv_name_1_0= RULE_ID ) ) ( (lv_description_2_0= RULE_STRING ) ) (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )? ( (lv_exits_7_0= ruleExit ) )*
            {
            otherlv_0=(Token)match(input,24,FOLLOW_6); 

            			newLeafNode(otherlv_0, grammarAccess.getRoomAccess().getRoomKeyword_0());
            		
            // InternalAdventureDsl.g:355:3: ( (lv_name_1_0= RULE_ID ) )
            // InternalAdventureDsl.g:356:4: (lv_name_1_0= RULE_ID )
            {
            // InternalAdventureDsl.g:356:4: (lv_name_1_0= RULE_ID )
            // InternalAdventureDsl.g:357:5: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_name_1_0, grammarAccess.getRoomAccess().getNameIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRoomRule());
            					}
            					setWithLastConsumed(
            						current,
            						"name",
            						lv_name_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalAdventureDsl.g:373:3: ( (lv_description_2_0= RULE_STRING ) )
            // InternalAdventureDsl.g:374:4: (lv_description_2_0= RULE_STRING )
            {
            // InternalAdventureDsl.g:374:4: (lv_description_2_0= RULE_STRING )
            // InternalAdventureDsl.g:375:5: lv_description_2_0= RULE_STRING
            {
            lv_description_2_0=(Token)match(input,RULE_STRING,FOLLOW_15); 

            					newLeafNode(lv_description_2_0, grammarAccess.getRoomAccess().getDescriptionSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRoomRule());
            					}
            					setWithLastConsumed(
            						current,
            						"description",
            						lv_description_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalAdventureDsl.g:391:3: (otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )* )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==22) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalAdventureDsl.g:392:4: otherlv_3= 'contains' ( (otherlv_4= RULE_ID ) ) (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )*
                    {
                    otherlv_3=(Token)match(input,22,FOLLOW_6); 

                    				newLeafNode(otherlv_3, grammarAccess.getRoomAccess().getContainsKeyword_3_0());
                    			
                    // InternalAdventureDsl.g:396:4: ( (otherlv_4= RULE_ID ) )
                    // InternalAdventureDsl.g:397:5: (otherlv_4= RULE_ID )
                    {
                    // InternalAdventureDsl.g:397:5: (otherlv_4= RULE_ID )
                    // InternalAdventureDsl.g:398:6: otherlv_4= RULE_ID
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getRoomRule());
                    						}
                    					
                    otherlv_4=(Token)match(input,RULE_ID,FOLLOW_16); 

                    						newLeafNode(otherlv_4, grammarAccess.getRoomAccess().getContentsItemCrossReference_3_1_0());
                    					

                    }


                    }

                    // InternalAdventureDsl.g:409:4: (otherlv_5= ',' ( (otherlv_6= RULE_ID ) ) )*
                    loop9:
                    do {
                        int alt9=2;
                        int LA9_0 = input.LA(1);

                        if ( (LA9_0==23) ) {
                            alt9=1;
                        }


                        switch (alt9) {
                    	case 1 :
                    	    // InternalAdventureDsl.g:410:5: otherlv_5= ',' ( (otherlv_6= RULE_ID ) )
                    	    {
                    	    otherlv_5=(Token)match(input,23,FOLLOW_6); 

                    	    					newLeafNode(otherlv_5, grammarAccess.getRoomAccess().getCommaKeyword_3_2_0());
                    	    				
                    	    // InternalAdventureDsl.g:414:5: ( (otherlv_6= RULE_ID ) )
                    	    // InternalAdventureDsl.g:415:6: (otherlv_6= RULE_ID )
                    	    {
                    	    // InternalAdventureDsl.g:415:6: (otherlv_6= RULE_ID )
                    	    // InternalAdventureDsl.g:416:7: otherlv_6= RULE_ID
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getRoomRule());
                    	    							}
                    	    						
                    	    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_16); 

                    	    							newLeafNode(otherlv_6, grammarAccess.getRoomAccess().getContentsItemCrossReference_3_2_1_0());
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop9;
                        }
                    } while (true);


                    }
                    break;

            }

            // InternalAdventureDsl.g:429:3: ( (lv_exits_7_0= ruleExit ) )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==25) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalAdventureDsl.g:430:4: (lv_exits_7_0= ruleExit )
            	    {
            	    // InternalAdventureDsl.g:430:4: (lv_exits_7_0= ruleExit )
            	    // InternalAdventureDsl.g:431:5: lv_exits_7_0= ruleExit
            	    {

            	    					newCompositeNode(grammarAccess.getRoomAccess().getExitsExitParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_17);
            	    lv_exits_7_0=ruleExit();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getRoomRule());
            	    					}
            	    					add(
            	    						current,
            	    						"exits",
            	    						lv_exits_7_0,
            	    						"com.javadude.adventuredsl.AdventureDsl.Exit");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRoom"


    // $ANTLR start "entryRuleExit"
    // InternalAdventureDsl.g:452:1: entryRuleExit returns [EObject current=null] : iv_ruleExit= ruleExit EOF ;
    public final EObject entryRuleExit() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExit = null;


        try {
            // InternalAdventureDsl.g:452:45: (iv_ruleExit= ruleExit EOF )
            // InternalAdventureDsl.g:453:2: iv_ruleExit= ruleExit EOF
            {
             newCompositeNode(grammarAccess.getExitRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExit=ruleExit();

            state._fsp--;

             current =iv_ruleExit; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExit"


    // $ANTLR start "ruleExit"
    // InternalAdventureDsl.g:459:1: ruleExit returns [EObject current=null] : (otherlv_0= 'exit' ( (lv_direction_1_0= ruleDirection ) ) ( (otherlv_2= RULE_ID ) ) ) ;
    public final EObject ruleExit() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Enumerator lv_direction_1_0 = null;



        	enterRule();

        try {
            // InternalAdventureDsl.g:465:2: ( (otherlv_0= 'exit' ( (lv_direction_1_0= ruleDirection ) ) ( (otherlv_2= RULE_ID ) ) ) )
            // InternalAdventureDsl.g:466:2: (otherlv_0= 'exit' ( (lv_direction_1_0= ruleDirection ) ) ( (otherlv_2= RULE_ID ) ) )
            {
            // InternalAdventureDsl.g:466:2: (otherlv_0= 'exit' ( (lv_direction_1_0= ruleDirection ) ) ( (otherlv_2= RULE_ID ) ) )
            // InternalAdventureDsl.g:467:3: otherlv_0= 'exit' ( (lv_direction_1_0= ruleDirection ) ) ( (otherlv_2= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,25,FOLLOW_18); 

            			newLeafNode(otherlv_0, grammarAccess.getExitAccess().getExitKeyword_0());
            		
            // InternalAdventureDsl.g:471:3: ( (lv_direction_1_0= ruleDirection ) )
            // InternalAdventureDsl.g:472:4: (lv_direction_1_0= ruleDirection )
            {
            // InternalAdventureDsl.g:472:4: (lv_direction_1_0= ruleDirection )
            // InternalAdventureDsl.g:473:5: lv_direction_1_0= ruleDirection
            {

            					newCompositeNode(grammarAccess.getExitAccess().getDirectionDirectionEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_6);
            lv_direction_1_0=ruleDirection();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExitRule());
            					}
            					set(
            						current,
            						"direction",
            						lv_direction_1_0,
            						"com.javadude.adventuredsl.AdventureDsl.Direction");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAdventureDsl.g:490:3: ( (otherlv_2= RULE_ID ) )
            // InternalAdventureDsl.g:491:4: (otherlv_2= RULE_ID )
            {
            // InternalAdventureDsl.g:491:4: (otherlv_2= RULE_ID )
            // InternalAdventureDsl.g:492:5: otherlv_2= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getExitRule());
            					}
            				
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_2); 

            					newLeafNode(otherlv_2, grammarAccess.getExitAccess().getToRoomCrossReference_2_0());
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExit"


    // $ANTLR start "ruleDirection"
    // InternalAdventureDsl.g:507:1: ruleDirection returns [Enumerator current=null] : ( (enumLiteral_0= 'north' ) | (enumLiteral_1= 'south' ) | (enumLiteral_2= 'east' ) | (enumLiteral_3= 'west' ) ) ;
    public final Enumerator ruleDirection() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalAdventureDsl.g:513:2: ( ( (enumLiteral_0= 'north' ) | (enumLiteral_1= 'south' ) | (enumLiteral_2= 'east' ) | (enumLiteral_3= 'west' ) ) )
            // InternalAdventureDsl.g:514:2: ( (enumLiteral_0= 'north' ) | (enumLiteral_1= 'south' ) | (enumLiteral_2= 'east' ) | (enumLiteral_3= 'west' ) )
            {
            // InternalAdventureDsl.g:514:2: ( (enumLiteral_0= 'north' ) | (enumLiteral_1= 'south' ) | (enumLiteral_2= 'east' ) | (enumLiteral_3= 'west' ) )
            int alt12=4;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt12=1;
                }
                break;
            case 27:
                {
                alt12=2;
                }
                break;
            case 28:
                {
                alt12=3;
                }
                break;
            case 29:
                {
                alt12=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalAdventureDsl.g:515:3: (enumLiteral_0= 'north' )
                    {
                    // InternalAdventureDsl.g:515:3: (enumLiteral_0= 'north' )
                    // InternalAdventureDsl.g:516:4: enumLiteral_0= 'north'
                    {
                    enumLiteral_0=(Token)match(input,26,FOLLOW_2); 

                    				current = grammarAccess.getDirectionAccess().getNORTHEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getDirectionAccess().getNORTHEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:523:3: (enumLiteral_1= 'south' )
                    {
                    // InternalAdventureDsl.g:523:3: (enumLiteral_1= 'south' )
                    // InternalAdventureDsl.g:524:4: enumLiteral_1= 'south'
                    {
                    enumLiteral_1=(Token)match(input,27,FOLLOW_2); 

                    				current = grammarAccess.getDirectionAccess().getSOUTHEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getDirectionAccess().getSOUTHEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalAdventureDsl.g:531:3: (enumLiteral_2= 'east' )
                    {
                    // InternalAdventureDsl.g:531:3: (enumLiteral_2= 'east' )
                    // InternalAdventureDsl.g:532:4: enumLiteral_2= 'east'
                    {
                    enumLiteral_2=(Token)match(input,28,FOLLOW_2); 

                    				current = grammarAccess.getDirectionAccess().getEASTEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getDirectionAccess().getEASTEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalAdventureDsl.g:539:3: (enumLiteral_3= 'west' )
                    {
                    // InternalAdventureDsl.g:539:3: (enumLiteral_3= 'west' )
                    // InternalAdventureDsl.g:540:4: enumLiteral_3= 'west'
                    {
                    enumLiteral_3=(Token)match(input,29,FOLLOW_2); 

                    				current = grammarAccess.getDirectionAccess().getWESTEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getDirectionAccess().getWESTEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDirection"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000001006000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000001000800L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000410002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000400002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000002400002L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002800002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x000000003C000000L});

}