package com.javadude.sample.adventure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Game {
	public interface Reporter {
		void report(String message, String text);
	}
	private Room currentRoom;
	private final List<Item> inventory = new ArrayList<>();
	private final Reporter reporter;
	private final Map<String, Item> itemsByName = new HashMap<>();
	
	public Game(Reporter reporter) {
		this.reporter = reporter;

		// read the room description
		Model model = defineModel();

		// set up the item index
		for(Item item : model.getItems()) {
			itemsByName.put(item.getName(), item);
		}
		currentRoom = model.getStartRoom();

		look();
	}
	
	public boolean report(String command, String message) {
		reporter.report(message, "Command: " + command + "\n\n" + message);
		return false;
	}
	
	public boolean get(String itemName) {
		String command = "get " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null) {
			return report(command, "You don't see the " + itemName + " in the room");
		}
		
		if (inventory.contains(item))
			return report(command, "You already have the " + itemName);

		if (!currentRoom.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the room");
		}

		if (!item.isCarryable())
			return report(command, "You can't pick up the " + itemName);

		currentRoom.getContents().remove(item);
		inventory.add(item);
		return report(command, "You picked up the " + itemName);
	}
	
	public boolean drop(String itemName) {
		String command = "drop " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null || !inventory.contains(item)) {
			return report(command, "You don't have the " + itemName);
		}
		
		inventory.remove(item);
		currentRoom.getContents().add(item);
		
		return report(command, "You dropped the " + itemName);
	}

	public boolean getFrom(String itemName, String containerName) {
		String command = "get " + itemName + " from " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything");
		}

		if (!container.isOpen()) {
			return report(command, "The " + containerName + " is not open and you cannot see inside it");
		}

		Item item = itemsByName.get(itemName);
		if (item == null || !container.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the " + containerName);
		}
		
		container.getContents().remove(item);
		inventory.add(item);
		return report(command, "You got the " + itemName + " from the " + containerName);
	}
	
	public boolean open(String containerName) {
		String command = "open " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything so it cannot be opened");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " is already open");
		}
		if (container.isLocked()) {
			return report(command, "The " + containerName + " is locked");
		}

		container.open(true);
		return report(command, "You opened the " + containerName);
	}
	
	public boolean close(String containerName) {
		String command = "close " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything so it cannot be closed");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " is already closed");
		}

		container.open(false);
		return report(command, "You closed the " + containerName);
	}
	
	public boolean unlock(String containerName) {
		String command = "unlock " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (container.getKey() == null) {
			return report(command, "The " + containerName + " does not have a lock");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " must be closed to be unlocked");
		}
		if (!inventory.contains(container.getKey())) {
			return report(command, "You do not have the key for the " + containerName);
		}
		
		container.locked(false);
		return report(command, "You unlocked the " + containerName);
	}

	public boolean lock(String containerName) {
		String command = "lock " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (container.getKey() == null) {
			return report(command, "The " + containerName + " does not have a lock");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " must be closed to be locked");
		}
		if (!inventory.contains(container.getKey())) {
			return report(command, "You do not have the key for the " + containerName);
		}
		
		container.locked(true);
		return report(command, "You locked the " + containerName);
	}

	public boolean examine(String itemName) {
		String command = "examine " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null) {
			return report(command, "You don't see the " + itemName + " in the room");
		}
		
		if (!inventory.contains(item) && !currentRoom.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the room or your inventory");
		}

		return report(command, getDescription(item));
	}
	
	public boolean look() {
		return report("look", getDescription());
	}
	
	public boolean inventory() {
		return report("inventory", dumpContents("inventory", inventory));
	}
	
	public boolean go(Direction direction) {
		Room nextRoom = null;
		for(Exit exit : currentRoom.getExits()) {
			if (exit.getDirection() == direction) {
				nextRoom = exit.getTo();
			}
		}
		if (nextRoom == null) {
			String dir = direction.name().toLowerCase();
			return report("go " + dir, "You cannot go " + dir);
		}
		currentRoom = nextRoom;
		return look();
	}
	
	
	private String getDescription() {
		String result = currentRoom.getDescription();
		if (!currentRoom.getExits().isEmpty()) {
			result += "\n\n" + "You can go ";
			for(Exit exit : currentRoom.getExits()) {
				result += exit.getDirection().name() + ", ";
			}
			result = result.substring(0, result.length()-2);
		}
		if (!currentRoom.getContents().isEmpty()) {
			result += "\n\n" + "You see ";
			for (Item item : currentRoom.getContents()) {
				result += "a " + item.getName() + ", ";
			}
			result = result.substring(0, result.length()-2);
		}
		return result;
	}

	public Room move(Room room, Direction direction) {
		for(Exit exit : room.getExits()) {
			if (exit.getDirection() == direction) {
				return exit.getTo();
			}
		}
		return null;
	}	
	
	
	public String getDescription(Item item) {
		String result = item.getDescription();
		if (item.isContainer()) {
			if (item.isLocked()) {
				return result + "\n\n The " + item.getName() + " is locked";
			}
			if (!item.isOpen()) {
				return result + "\n\n The " + item.getName() + " is closed";
			}
			result += "\n\n" + dumpContents(item.getName(), item.getContents());
		}
		return result;
	}

	
	public String dumpContents(String containerName, List<Item> items) {
		String article = "The ";
		if ("inventory".equals(containerName))
			article = "Your ";
		if (items.isEmpty())
			return article + containerName + " is empty";
		String result = article + containerName + " contains ";
		for (Item item : items) {
			result += "a " + item.getName() + ", ";
		}
		result = result.substring(0, result.length()-2);
		return result;
	}

	private Model defineModel() {
		Item key, letter, safe;

		Room porch, hall, bedroom, study, kitchen;

		Model model = new Model()
				.add(key = new Item()
					.name("key")
					.description("It is a shiny brass key")
					.carryable(true))
				.add(letter = new Item()
					.name("letter")
					.description("It reads You win!")
					.carryable(true))
				.add(safe = new Item()
						.name("safe")
						.description("It is a very heavy locked box. There is a keyhole on it")
						.carryable(false)
						.key(key)
						.container(true)
						.locked(true)
						.open(false)
						.add(letter))
				.add(porch = new Room()
					.name("porch")
					.description("This is the front porch of your house"))
				.add(hall = new Room()
					.name("hall")
					.description("This is the main hall of your house"))
				.add(bedroom = new Room()
					.name("bedroom")
					.description("This is where you sleep")
					.add(key))
				.add(study = new Room()
					.name("study")
					.description("This is where you pretend to work")
					.add(safe))
				.add(kitchen = new Room()
					.name("kitchen")
					.description("This is a room you never use and aren't really certain why you even have it."))
				.startRoom(porch);
				
		porch.add(new Exit().direction(Direction.NORTH).to(hall));
		hall.add(new Exit().direction(Direction.SOUTH).to(porch));
		hall.add(new Exit().direction(Direction.NORTH).to(study));
		hall.add(new Exit().direction(Direction.EAST).to(bedroom));
		hall.add(new Exit().direction(Direction.WEST).to(kitchen));
		bedroom.add(new Exit().direction(Direction.WEST).to(hall));
		study.add(new Exit().direction(Direction.SOUTH).to(hall));
		kitchen.add(new Exit().direction(Direction.EAST).to(hall));
		
		return model;
	}
	
}
