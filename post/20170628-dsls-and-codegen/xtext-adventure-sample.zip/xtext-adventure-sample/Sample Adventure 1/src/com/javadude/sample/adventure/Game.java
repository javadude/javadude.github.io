package com.javadude.sample.adventure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Game {
	public interface Reporter {
		void report(String message, String text);
	}
	private Room currentRoom;
	private final List<Item> inventory = new ArrayList<>();
	private final Reporter reporter;
	private final Map<String, Item> itemsByName = new HashMap<>();
	
	public Game(Reporter reporter) {
		this.reporter = reporter;

		// read the room description
		Model model = defineModel();

		// set up the item index
		for(Item item : model.getItems()) {
			itemsByName.put(item.getName(), item);
		}
		currentRoom = model.getStartRoom();

		look();
	}
	
	public boolean report(String command, String message) {
		reporter.report(message, "Command: " + command + "\n\n" + message);
		return false;
	}
	
	public boolean get(String itemName) {
		String command = "get " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null) {
			return report(command, "You don't see the " + itemName + " in the room");
		}
		
		if (inventory.contains(item))
			return report(command, "You already have the " + itemName);

		if (!currentRoom.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the room");
		}

		if (!item.isCarryable())
			return report(command, "You can't pick up the " + itemName);

		currentRoom.getContents().remove(item);
		inventory.add(item);
		return report(command, "You picked up the " + itemName);
	}
	
	public boolean drop(String itemName) {
		String command = "drop " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null || !inventory.contains(item)) {
			return report(command, "You don't have the " + itemName);
		}
		
		inventory.remove(item);
		currentRoom.getContents().add(item);
		
		return report(command, "You dropped the " + itemName);
	}

	public boolean getFrom(String itemName, String containerName) {
		String command = "get " + itemName + " from " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything");
		}

		if (!container.isOpen()) {
			return report(command, "The " + containerName + " is not open and you cannot see inside it");
		}

		Item item = itemsByName.get(itemName);
		if (item == null || !container.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the " + containerName);
		}
		
		container.getContents().remove(item);
		inventory.add(item);
		return report(command, "You got the " + itemName + " from the " + containerName);
	}
	
	public boolean open(String containerName) {
		String command = "open " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything so it cannot be opened");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " is already open");
		}
		if (container.isLocked()) {
			return report(command, "The " + containerName + " is locked");
		}

		container.setOpen(true);
		return report(command, "You opened the " + containerName);
	}
	
	public boolean close(String containerName) {
		String command = "close " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (!container.isContainer()) {
			return report(command, "The " + containerName + " cannot contain anything so it cannot be closed");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " is already closed");
		}

		container.setOpen(false);
		return report(command, "You closed the " + containerName);
	}
	
	public boolean unlock(String containerName) {
		String command = "unlock " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (container.getKey() == null) {
			return report(command, "The " + containerName + " does not have a lock");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " must be closed to be unlocked");
		}
		if (!inventory.contains(container.getKey())) {
			return report(command, "You do not have the key for the " + containerName);
		}
		
		container.setLocked(false);
		return report(command, "You unlocked the " + containerName);
	}

	public boolean lock(String containerName) {
		String command = "lock " + containerName;
		Item container = itemsByName.get(containerName);
		if (container == null || (!currentRoom.getContents().contains(container) && !inventory.contains(container))) {
			return report(command, "You don't see the " + containerName + " in the room or your inventory");
		}
		if (container.getKey() == null) {
			return report(command, "The " + containerName + " does not have a lock");
		}
		
		if (container.isOpen()) {
			return report(command, "The " + containerName + " must be closed to be locked");
		}
		if (!inventory.contains(container.getKey())) {
			return report(command, "You do not have the key for the " + containerName);
		}
		
		container.setLocked(true);
		return report(command, "You locked the " + containerName);
	}

	public boolean examine(String itemName) {
		String command = "examine " + itemName;
		Item item = itemsByName.get(itemName);
		if (item == null) {
			return report(command, "You don't see the " + itemName + " in the room");
		}
		
		if (!inventory.contains(item) && !currentRoom.getContents().contains(item)) {
			return report(command, "You don't see the " + itemName + " in the room or your inventory");
		}

		return report(command, getDescription(item));
	}
	
	public boolean look() {
		return report("look", getDescription());
	}
	
	public boolean inventory() {
		return report("inventory", dumpContents("inventory", inventory));
	}
	
	public boolean go(Direction direction) {
		Room nextRoom = null;
		for(Exit exit : currentRoom.getExits()) {
			if (exit.getDirection() == direction) {
				nextRoom = exit.getTo();
			}
		}
		if (nextRoom == null) {
			String dir = direction.name().toLowerCase();
			return report("go " + dir, "You cannot go " + dir);
		}
		currentRoom = nextRoom;
		return look();
	}
	
	
	private String getDescription() {
		String result = currentRoom.getDescription();
		if (!currentRoom.getExits().isEmpty()) {
			result += "\n\n" + "You can go ";
			for(Exit exit : currentRoom.getExits()) {
				result += exit.getDirection().name() + ", ";
			}
			result = result.substring(0, result.length()-2);
		}
		if (!currentRoom.getContents().isEmpty()) {
			result += "\n\n" + "You see ";
			for (Item item : currentRoom.getContents()) {
				result += "a " + item.getName() + ", ";
			}
			result = result.substring(0, result.length()-2);
		}
		return result;
	}

	public Room move(Room room, Direction direction) {
		for(Exit exit : room.getExits()) {
			if (exit.getDirection() == direction) {
				return exit.getTo();
			}
		}
		return null;
	}	
	
	
	public String getDescription(Item item) {
		String result = item.getDescription();
		if (item.isContainer()) {
			if (item.isLocked()) {
				return result + "\n\n The " + item.getName() + " is locked";
			}
			if (!item.isOpen()) {
				return result + "\n\n The " + item.getName() + " is closed";
			}
			result += "\n\n" + dumpContents(item.getName(), item.getContents());
		}
		return result;
	}

	
	public String dumpContents(String containerName, List<Item> items) {
		String article = "The ";
		if ("inventory".equals(containerName))
			article = "Your ";
		if (items.isEmpty())
			return article + containerName + " is empty";
		String result = article + containerName + " contains ";
		for (Item item : items) {
			result += "a " + item.getName() + ", ";
		}
		result = result.substring(0, result.length()-2);
		return result;
	}

	private Model defineModel() {
		Item key = new Item("key", "It is a shiny brass key", true);
		Item letter = new Item("letter", "It reads You win!", true);
		Item safe = new Item("safe", "It is a very heavy locked box. There is a keyhole on it", false, key, true, false, letter);

		Room porch = new Room("porch", "This is the front porch of your house");
		Room hall = new Room("hall", "This is the main hall of your house");
		Room bedroom = new Room("bedroom", "This is where you sleep", key);
		Room study = new Room("study", "This is where you pretend to work", safe);
		Room kitchen = new Room("kitchen", "This is a room you never use and aren't really certain why you even have it.");

		porch.add(new Exit(Direction.NORTH, hall));
		hall.add(new Exit(Direction.SOUTH, porch));
		hall.add(new Exit(Direction.NORTH, study));
		hall.add(new Exit(Direction.EAST, bedroom));
		hall.add(new Exit(Direction.WEST, kitchen));
		bedroom.add(new Exit(Direction.WEST, hall));
		study.add(new Exit(Direction.SOUTH, hall));
		kitchen.add(new Exit(Direction.EAST, hall));

		return new Model(porch, porch, hall, bedroom, study, kitchen, key, letter, safe);
	}
	
}
