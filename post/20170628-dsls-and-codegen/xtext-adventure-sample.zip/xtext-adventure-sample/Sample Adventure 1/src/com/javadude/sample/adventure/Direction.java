package com.javadude.sample.adventure;

public enum Direction {
	NORTH,
	SOUTH,
	EAST,
	WEST
}