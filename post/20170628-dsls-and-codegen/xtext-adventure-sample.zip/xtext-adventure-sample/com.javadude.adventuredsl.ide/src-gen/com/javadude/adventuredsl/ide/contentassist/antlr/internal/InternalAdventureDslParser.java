package com.javadude.adventuredsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import com.javadude.adventuredsl.services.AdventureDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAdventureDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'fixed'", "'unlocked'", "'closed'", "'north'", "'south'", "'east'", "'west'", "'start'", "'in'", "'item'", "'opens'", "'with'", "','", "'room'", "'contains'", "'exit'", "'carryable'", "'locked'", "'open'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalAdventureDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalAdventureDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalAdventureDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalAdventureDsl.g"; }


    	private AdventureDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(AdventureDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleModel"
    // InternalAdventureDsl.g:53:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // InternalAdventureDsl.g:54:1: ( ruleModel EOF )
            // InternalAdventureDsl.g:55:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalAdventureDsl.g:62:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:66:2: ( ( ( rule__Model__Group__0 ) ) )
            // InternalAdventureDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            {
            // InternalAdventureDsl.g:67:2: ( ( rule__Model__Group__0 ) )
            // InternalAdventureDsl.g:68:3: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // InternalAdventureDsl.g:69:3: ( rule__Model__Group__0 )
            // InternalAdventureDsl.g:69:4: rule__Model__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleItem"
    // InternalAdventureDsl.g:78:1: entryRuleItem : ruleItem EOF ;
    public final void entryRuleItem() throws RecognitionException {
        try {
            // InternalAdventureDsl.g:79:1: ( ruleItem EOF )
            // InternalAdventureDsl.g:80:1: ruleItem EOF
            {
             before(grammarAccess.getItemRule()); 
            pushFollow(FOLLOW_1);
            ruleItem();

            state._fsp--;

             after(grammarAccess.getItemRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleItem"


    // $ANTLR start "ruleItem"
    // InternalAdventureDsl.g:87:1: ruleItem : ( ( rule__Item__Group__0 ) ) ;
    public final void ruleItem() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:91:2: ( ( ( rule__Item__Group__0 ) ) )
            // InternalAdventureDsl.g:92:2: ( ( rule__Item__Group__0 ) )
            {
            // InternalAdventureDsl.g:92:2: ( ( rule__Item__Group__0 ) )
            // InternalAdventureDsl.g:93:3: ( rule__Item__Group__0 )
            {
             before(grammarAccess.getItemAccess().getGroup()); 
            // InternalAdventureDsl.g:94:3: ( rule__Item__Group__0 )
            // InternalAdventureDsl.g:94:4: rule__Item__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Item__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleItem"


    // $ANTLR start "entryRuleRoom"
    // InternalAdventureDsl.g:103:1: entryRuleRoom : ruleRoom EOF ;
    public final void entryRuleRoom() throws RecognitionException {
        try {
            // InternalAdventureDsl.g:104:1: ( ruleRoom EOF )
            // InternalAdventureDsl.g:105:1: ruleRoom EOF
            {
             before(grammarAccess.getRoomRule()); 
            pushFollow(FOLLOW_1);
            ruleRoom();

            state._fsp--;

             after(grammarAccess.getRoomRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRoom"


    // $ANTLR start "ruleRoom"
    // InternalAdventureDsl.g:112:1: ruleRoom : ( ( rule__Room__Group__0 ) ) ;
    public final void ruleRoom() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:116:2: ( ( ( rule__Room__Group__0 ) ) )
            // InternalAdventureDsl.g:117:2: ( ( rule__Room__Group__0 ) )
            {
            // InternalAdventureDsl.g:117:2: ( ( rule__Room__Group__0 ) )
            // InternalAdventureDsl.g:118:3: ( rule__Room__Group__0 )
            {
             before(grammarAccess.getRoomAccess().getGroup()); 
            // InternalAdventureDsl.g:119:3: ( rule__Room__Group__0 )
            // InternalAdventureDsl.g:119:4: rule__Room__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Room__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRoomAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRoom"


    // $ANTLR start "entryRuleExit"
    // InternalAdventureDsl.g:128:1: entryRuleExit : ruleExit EOF ;
    public final void entryRuleExit() throws RecognitionException {
        try {
            // InternalAdventureDsl.g:129:1: ( ruleExit EOF )
            // InternalAdventureDsl.g:130:1: ruleExit EOF
            {
             before(grammarAccess.getExitRule()); 
            pushFollow(FOLLOW_1);
            ruleExit();

            state._fsp--;

             after(grammarAccess.getExitRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExit"


    // $ANTLR start "ruleExit"
    // InternalAdventureDsl.g:137:1: ruleExit : ( ( rule__Exit__Group__0 ) ) ;
    public final void ruleExit() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:141:2: ( ( ( rule__Exit__Group__0 ) ) )
            // InternalAdventureDsl.g:142:2: ( ( rule__Exit__Group__0 ) )
            {
            // InternalAdventureDsl.g:142:2: ( ( rule__Exit__Group__0 ) )
            // InternalAdventureDsl.g:143:3: ( rule__Exit__Group__0 )
            {
             before(grammarAccess.getExitAccess().getGroup()); 
            // InternalAdventureDsl.g:144:3: ( rule__Exit__Group__0 )
            // InternalAdventureDsl.g:144:4: rule__Exit__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Exit__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getExitAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExit"


    // $ANTLR start "ruleDirection"
    // InternalAdventureDsl.g:153:1: ruleDirection : ( ( rule__Direction__Alternatives ) ) ;
    public final void ruleDirection() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:157:1: ( ( ( rule__Direction__Alternatives ) ) )
            // InternalAdventureDsl.g:158:2: ( ( rule__Direction__Alternatives ) )
            {
            // InternalAdventureDsl.g:158:2: ( ( rule__Direction__Alternatives ) )
            // InternalAdventureDsl.g:159:3: ( rule__Direction__Alternatives )
            {
             before(grammarAccess.getDirectionAccess().getAlternatives()); 
            // InternalAdventureDsl.g:160:3: ( rule__Direction__Alternatives )
            // InternalAdventureDsl.g:160:4: rule__Direction__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Direction__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDirectionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDirection"


    // $ANTLR start "rule__Item__Alternatives_0"
    // InternalAdventureDsl.g:168:1: rule__Item__Alternatives_0 : ( ( ( rule__Item__CarryableAssignment_0_0 ) ) | ( 'fixed' ) );
    public final void rule__Item__Alternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:172:1: ( ( ( rule__Item__CarryableAssignment_0_0 ) ) | ( 'fixed' ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==27) ) {
                alt1=1;
            }
            else if ( (LA1_0==11) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalAdventureDsl.g:173:2: ( ( rule__Item__CarryableAssignment_0_0 ) )
                    {
                    // InternalAdventureDsl.g:173:2: ( ( rule__Item__CarryableAssignment_0_0 ) )
                    // InternalAdventureDsl.g:174:3: ( rule__Item__CarryableAssignment_0_0 )
                    {
                     before(grammarAccess.getItemAccess().getCarryableAssignment_0_0()); 
                    // InternalAdventureDsl.g:175:3: ( rule__Item__CarryableAssignment_0_0 )
                    // InternalAdventureDsl.g:175:4: rule__Item__CarryableAssignment_0_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Item__CarryableAssignment_0_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getItemAccess().getCarryableAssignment_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:179:2: ( 'fixed' )
                    {
                    // InternalAdventureDsl.g:179:2: ( 'fixed' )
                    // InternalAdventureDsl.g:180:3: 'fixed'
                    {
                     before(grammarAccess.getItemAccess().getFixedKeyword_0_1()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getItemAccess().getFixedKeyword_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Alternatives_0"


    // $ANTLR start "rule__Item__Alternatives_4_3"
    // InternalAdventureDsl.g:189:1: rule__Item__Alternatives_4_3 : ( ( ( rule__Item__LockedAssignment_4_3_0 ) ) | ( 'unlocked' ) );
    public final void rule__Item__Alternatives_4_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:193:1: ( ( ( rule__Item__LockedAssignment_4_3_0 ) ) | ( 'unlocked' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==28) ) {
                alt2=1;
            }
            else if ( (LA2_0==12) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalAdventureDsl.g:194:2: ( ( rule__Item__LockedAssignment_4_3_0 ) )
                    {
                    // InternalAdventureDsl.g:194:2: ( ( rule__Item__LockedAssignment_4_3_0 ) )
                    // InternalAdventureDsl.g:195:3: ( rule__Item__LockedAssignment_4_3_0 )
                    {
                     before(grammarAccess.getItemAccess().getLockedAssignment_4_3_0()); 
                    // InternalAdventureDsl.g:196:3: ( rule__Item__LockedAssignment_4_3_0 )
                    // InternalAdventureDsl.g:196:4: rule__Item__LockedAssignment_4_3_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Item__LockedAssignment_4_3_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getItemAccess().getLockedAssignment_4_3_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:200:2: ( 'unlocked' )
                    {
                    // InternalAdventureDsl.g:200:2: ( 'unlocked' )
                    // InternalAdventureDsl.g:201:3: 'unlocked'
                    {
                     before(grammarAccess.getItemAccess().getUnlockedKeyword_4_3_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getItemAccess().getUnlockedKeyword_4_3_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Alternatives_4_3"


    // $ANTLR start "rule__Item__Alternatives_4_4"
    // InternalAdventureDsl.g:210:1: rule__Item__Alternatives_4_4 : ( ( ( rule__Item__OpenAssignment_4_4_0 ) ) | ( 'closed' ) );
    public final void rule__Item__Alternatives_4_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:214:1: ( ( ( rule__Item__OpenAssignment_4_4_0 ) ) | ( 'closed' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==29) ) {
                alt3=1;
            }
            else if ( (LA3_0==13) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalAdventureDsl.g:215:2: ( ( rule__Item__OpenAssignment_4_4_0 ) )
                    {
                    // InternalAdventureDsl.g:215:2: ( ( rule__Item__OpenAssignment_4_4_0 ) )
                    // InternalAdventureDsl.g:216:3: ( rule__Item__OpenAssignment_4_4_0 )
                    {
                     before(grammarAccess.getItemAccess().getOpenAssignment_4_4_0()); 
                    // InternalAdventureDsl.g:217:3: ( rule__Item__OpenAssignment_4_4_0 )
                    // InternalAdventureDsl.g:217:4: rule__Item__OpenAssignment_4_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Item__OpenAssignment_4_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getItemAccess().getOpenAssignment_4_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:221:2: ( 'closed' )
                    {
                    // InternalAdventureDsl.g:221:2: ( 'closed' )
                    // InternalAdventureDsl.g:222:3: 'closed'
                    {
                     before(grammarAccess.getItemAccess().getClosedKeyword_4_4_1()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getItemAccess().getClosedKeyword_4_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Alternatives_4_4"


    // $ANTLR start "rule__Direction__Alternatives"
    // InternalAdventureDsl.g:231:1: rule__Direction__Alternatives : ( ( ( 'north' ) ) | ( ( 'south' ) ) | ( ( 'east' ) ) | ( ( 'west' ) ) );
    public final void rule__Direction__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:235:1: ( ( ( 'north' ) ) | ( ( 'south' ) ) | ( ( 'east' ) ) | ( ( 'west' ) ) )
            int alt4=4;
            switch ( input.LA(1) ) {
            case 14:
                {
                alt4=1;
                }
                break;
            case 15:
                {
                alt4=2;
                }
                break;
            case 16:
                {
                alt4=3;
                }
                break;
            case 17:
                {
                alt4=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // InternalAdventureDsl.g:236:2: ( ( 'north' ) )
                    {
                    // InternalAdventureDsl.g:236:2: ( ( 'north' ) )
                    // InternalAdventureDsl.g:237:3: ( 'north' )
                    {
                     before(grammarAccess.getDirectionAccess().getNORTHEnumLiteralDeclaration_0()); 
                    // InternalAdventureDsl.g:238:3: ( 'north' )
                    // InternalAdventureDsl.g:238:4: 'north'
                    {
                    match(input,14,FOLLOW_2); 

                    }

                     after(grammarAccess.getDirectionAccess().getNORTHEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalAdventureDsl.g:242:2: ( ( 'south' ) )
                    {
                    // InternalAdventureDsl.g:242:2: ( ( 'south' ) )
                    // InternalAdventureDsl.g:243:3: ( 'south' )
                    {
                     before(grammarAccess.getDirectionAccess().getSOUTHEnumLiteralDeclaration_1()); 
                    // InternalAdventureDsl.g:244:3: ( 'south' )
                    // InternalAdventureDsl.g:244:4: 'south'
                    {
                    match(input,15,FOLLOW_2); 

                    }

                     after(grammarAccess.getDirectionAccess().getSOUTHEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalAdventureDsl.g:248:2: ( ( 'east' ) )
                    {
                    // InternalAdventureDsl.g:248:2: ( ( 'east' ) )
                    // InternalAdventureDsl.g:249:3: ( 'east' )
                    {
                     before(grammarAccess.getDirectionAccess().getEASTEnumLiteralDeclaration_2()); 
                    // InternalAdventureDsl.g:250:3: ( 'east' )
                    // InternalAdventureDsl.g:250:4: 'east'
                    {
                    match(input,16,FOLLOW_2); 

                    }

                     after(grammarAccess.getDirectionAccess().getEASTEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalAdventureDsl.g:254:2: ( ( 'west' ) )
                    {
                    // InternalAdventureDsl.g:254:2: ( ( 'west' ) )
                    // InternalAdventureDsl.g:255:3: ( 'west' )
                    {
                     before(grammarAccess.getDirectionAccess().getWESTEnumLiteralDeclaration_3()); 
                    // InternalAdventureDsl.g:256:3: ( 'west' )
                    // InternalAdventureDsl.g:256:4: 'west'
                    {
                    match(input,17,FOLLOW_2); 

                    }

                     after(grammarAccess.getDirectionAccess().getWESTEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Direction__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // InternalAdventureDsl.g:264:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:268:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // InternalAdventureDsl.g:269:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // InternalAdventureDsl.g:276:1: rule__Model__Group__0__Impl : ( ( ( rule__Model__ItemsAssignment_0 ) ) ( ( rule__Model__ItemsAssignment_0 )* ) ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:280:1: ( ( ( ( rule__Model__ItemsAssignment_0 ) ) ( ( rule__Model__ItemsAssignment_0 )* ) ) )
            // InternalAdventureDsl.g:281:1: ( ( ( rule__Model__ItemsAssignment_0 ) ) ( ( rule__Model__ItemsAssignment_0 )* ) )
            {
            // InternalAdventureDsl.g:281:1: ( ( ( rule__Model__ItemsAssignment_0 ) ) ( ( rule__Model__ItemsAssignment_0 )* ) )
            // InternalAdventureDsl.g:282:2: ( ( rule__Model__ItemsAssignment_0 ) ) ( ( rule__Model__ItemsAssignment_0 )* )
            {
            // InternalAdventureDsl.g:282:2: ( ( rule__Model__ItemsAssignment_0 ) )
            // InternalAdventureDsl.g:283:3: ( rule__Model__ItemsAssignment_0 )
            {
             before(grammarAccess.getModelAccess().getItemsAssignment_0()); 
            // InternalAdventureDsl.g:284:3: ( rule__Model__ItemsAssignment_0 )
            // InternalAdventureDsl.g:284:4: rule__Model__ItemsAssignment_0
            {
            pushFollow(FOLLOW_4);
            rule__Model__ItemsAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getItemsAssignment_0()); 

            }

            // InternalAdventureDsl.g:287:2: ( ( rule__Model__ItemsAssignment_0 )* )
            // InternalAdventureDsl.g:288:3: ( rule__Model__ItemsAssignment_0 )*
            {
             before(grammarAccess.getModelAccess().getItemsAssignment_0()); 
            // InternalAdventureDsl.g:289:3: ( rule__Model__ItemsAssignment_0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==11||LA5_0==27) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalAdventureDsl.g:289:4: rule__Model__ItemsAssignment_0
            	    {
            	    pushFollow(FOLLOW_4);
            	    rule__Model__ItemsAssignment_0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getItemsAssignment_0()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // InternalAdventureDsl.g:298:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:302:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // InternalAdventureDsl.g:303:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // InternalAdventureDsl.g:310:1: rule__Model__Group__1__Impl : ( ( ( rule__Model__RoomsAssignment_1 ) ) ( ( rule__Model__RoomsAssignment_1 )* ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:314:1: ( ( ( ( rule__Model__RoomsAssignment_1 ) ) ( ( rule__Model__RoomsAssignment_1 )* ) ) )
            // InternalAdventureDsl.g:315:1: ( ( ( rule__Model__RoomsAssignment_1 ) ) ( ( rule__Model__RoomsAssignment_1 )* ) )
            {
            // InternalAdventureDsl.g:315:1: ( ( ( rule__Model__RoomsAssignment_1 ) ) ( ( rule__Model__RoomsAssignment_1 )* ) )
            // InternalAdventureDsl.g:316:2: ( ( rule__Model__RoomsAssignment_1 ) ) ( ( rule__Model__RoomsAssignment_1 )* )
            {
            // InternalAdventureDsl.g:316:2: ( ( rule__Model__RoomsAssignment_1 ) )
            // InternalAdventureDsl.g:317:3: ( rule__Model__RoomsAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getRoomsAssignment_1()); 
            // InternalAdventureDsl.g:318:3: ( rule__Model__RoomsAssignment_1 )
            // InternalAdventureDsl.g:318:4: rule__Model__RoomsAssignment_1
            {
            pushFollow(FOLLOW_6);
            rule__Model__RoomsAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getRoomsAssignment_1()); 

            }

            // InternalAdventureDsl.g:321:2: ( ( rule__Model__RoomsAssignment_1 )* )
            // InternalAdventureDsl.g:322:3: ( rule__Model__RoomsAssignment_1 )*
            {
             before(grammarAccess.getModelAccess().getRoomsAssignment_1()); 
            // InternalAdventureDsl.g:323:3: ( rule__Model__RoomsAssignment_1 )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==24) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalAdventureDsl.g:323:4: rule__Model__RoomsAssignment_1
            	    {
            	    pushFollow(FOLLOW_6);
            	    rule__Model__RoomsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getRoomsAssignment_1()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // InternalAdventureDsl.g:332:1: rule__Model__Group__2 : rule__Model__Group__2__Impl rule__Model__Group__3 ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:336:1: ( rule__Model__Group__2__Impl rule__Model__Group__3 )
            // InternalAdventureDsl.g:337:2: rule__Model__Group__2__Impl rule__Model__Group__3
            {
            pushFollow(FOLLOW_7);
            rule__Model__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // InternalAdventureDsl.g:344:1: rule__Model__Group__2__Impl : ( 'start' ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:348:1: ( ( 'start' ) )
            // InternalAdventureDsl.g:349:1: ( 'start' )
            {
            // InternalAdventureDsl.g:349:1: ( 'start' )
            // InternalAdventureDsl.g:350:2: 'start'
            {
             before(grammarAccess.getModelAccess().getStartKeyword_2()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getStartKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__Model__Group__3"
    // InternalAdventureDsl.g:359:1: rule__Model__Group__3 : rule__Model__Group__3__Impl rule__Model__Group__4 ;
    public final void rule__Model__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:363:1: ( rule__Model__Group__3__Impl rule__Model__Group__4 )
            // InternalAdventureDsl.g:364:2: rule__Model__Group__3__Impl rule__Model__Group__4
            {
            pushFollow(FOLLOW_8);
            rule__Model__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Model__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3"


    // $ANTLR start "rule__Model__Group__3__Impl"
    // InternalAdventureDsl.g:371:1: rule__Model__Group__3__Impl : ( 'in' ) ;
    public final void rule__Model__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:375:1: ( ( 'in' ) )
            // InternalAdventureDsl.g:376:1: ( 'in' )
            {
            // InternalAdventureDsl.g:376:1: ( 'in' )
            // InternalAdventureDsl.g:377:2: 'in'
            {
             before(grammarAccess.getModelAccess().getInKeyword_3()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getInKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__3__Impl"


    // $ANTLR start "rule__Model__Group__4"
    // InternalAdventureDsl.g:386:1: rule__Model__Group__4 : rule__Model__Group__4__Impl ;
    public final void rule__Model__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:390:1: ( rule__Model__Group__4__Impl )
            // InternalAdventureDsl.g:391:2: rule__Model__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Model__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4"


    // $ANTLR start "rule__Model__Group__4__Impl"
    // InternalAdventureDsl.g:397:1: rule__Model__Group__4__Impl : ( ( rule__Model__StartRoomAssignment_4 ) ) ;
    public final void rule__Model__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:401:1: ( ( ( rule__Model__StartRoomAssignment_4 ) ) )
            // InternalAdventureDsl.g:402:1: ( ( rule__Model__StartRoomAssignment_4 ) )
            {
            // InternalAdventureDsl.g:402:1: ( ( rule__Model__StartRoomAssignment_4 ) )
            // InternalAdventureDsl.g:403:2: ( rule__Model__StartRoomAssignment_4 )
            {
             before(grammarAccess.getModelAccess().getStartRoomAssignment_4()); 
            // InternalAdventureDsl.g:404:2: ( rule__Model__StartRoomAssignment_4 )
            // InternalAdventureDsl.g:404:3: rule__Model__StartRoomAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Model__StartRoomAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getStartRoomAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__4__Impl"


    // $ANTLR start "rule__Item__Group__0"
    // InternalAdventureDsl.g:413:1: rule__Item__Group__0 : rule__Item__Group__0__Impl rule__Item__Group__1 ;
    public final void rule__Item__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:417:1: ( rule__Item__Group__0__Impl rule__Item__Group__1 )
            // InternalAdventureDsl.g:418:2: rule__Item__Group__0__Impl rule__Item__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Item__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__0"


    // $ANTLR start "rule__Item__Group__0__Impl"
    // InternalAdventureDsl.g:425:1: rule__Item__Group__0__Impl : ( ( rule__Item__Alternatives_0 ) ) ;
    public final void rule__Item__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:429:1: ( ( ( rule__Item__Alternatives_0 ) ) )
            // InternalAdventureDsl.g:430:1: ( ( rule__Item__Alternatives_0 ) )
            {
            // InternalAdventureDsl.g:430:1: ( ( rule__Item__Alternatives_0 ) )
            // InternalAdventureDsl.g:431:2: ( rule__Item__Alternatives_0 )
            {
             before(grammarAccess.getItemAccess().getAlternatives_0()); 
            // InternalAdventureDsl.g:432:2: ( rule__Item__Alternatives_0 )
            // InternalAdventureDsl.g:432:3: rule__Item__Alternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Item__Alternatives_0();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getAlternatives_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__0__Impl"


    // $ANTLR start "rule__Item__Group__1"
    // InternalAdventureDsl.g:440:1: rule__Item__Group__1 : rule__Item__Group__1__Impl rule__Item__Group__2 ;
    public final void rule__Item__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:444:1: ( rule__Item__Group__1__Impl rule__Item__Group__2 )
            // InternalAdventureDsl.g:445:2: rule__Item__Group__1__Impl rule__Item__Group__2
            {
            pushFollow(FOLLOW_8);
            rule__Item__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__1"


    // $ANTLR start "rule__Item__Group__1__Impl"
    // InternalAdventureDsl.g:452:1: rule__Item__Group__1__Impl : ( 'item' ) ;
    public final void rule__Item__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:456:1: ( ( 'item' ) )
            // InternalAdventureDsl.g:457:1: ( 'item' )
            {
            // InternalAdventureDsl.g:457:1: ( 'item' )
            // InternalAdventureDsl.g:458:2: 'item'
            {
             before(grammarAccess.getItemAccess().getItemKeyword_1()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getItemKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__1__Impl"


    // $ANTLR start "rule__Item__Group__2"
    // InternalAdventureDsl.g:467:1: rule__Item__Group__2 : rule__Item__Group__2__Impl rule__Item__Group__3 ;
    public final void rule__Item__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:471:1: ( rule__Item__Group__2__Impl rule__Item__Group__3 )
            // InternalAdventureDsl.g:472:2: rule__Item__Group__2__Impl rule__Item__Group__3
            {
            pushFollow(FOLLOW_10);
            rule__Item__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__2"


    // $ANTLR start "rule__Item__Group__2__Impl"
    // InternalAdventureDsl.g:479:1: rule__Item__Group__2__Impl : ( ( rule__Item__NameAssignment_2 ) ) ;
    public final void rule__Item__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:483:1: ( ( ( rule__Item__NameAssignment_2 ) ) )
            // InternalAdventureDsl.g:484:1: ( ( rule__Item__NameAssignment_2 ) )
            {
            // InternalAdventureDsl.g:484:1: ( ( rule__Item__NameAssignment_2 ) )
            // InternalAdventureDsl.g:485:2: ( rule__Item__NameAssignment_2 )
            {
             before(grammarAccess.getItemAccess().getNameAssignment_2()); 
            // InternalAdventureDsl.g:486:2: ( rule__Item__NameAssignment_2 )
            // InternalAdventureDsl.g:486:3: rule__Item__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Item__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__2__Impl"


    // $ANTLR start "rule__Item__Group__3"
    // InternalAdventureDsl.g:494:1: rule__Item__Group__3 : rule__Item__Group__3__Impl rule__Item__Group__4 ;
    public final void rule__Item__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:498:1: ( rule__Item__Group__3__Impl rule__Item__Group__4 )
            // InternalAdventureDsl.g:499:2: rule__Item__Group__3__Impl rule__Item__Group__4
            {
            pushFollow(FOLLOW_11);
            rule__Item__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__3"


    // $ANTLR start "rule__Item__Group__3__Impl"
    // InternalAdventureDsl.g:506:1: rule__Item__Group__3__Impl : ( ( rule__Item__DescriptionAssignment_3 ) ) ;
    public final void rule__Item__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:510:1: ( ( ( rule__Item__DescriptionAssignment_3 ) ) )
            // InternalAdventureDsl.g:511:1: ( ( rule__Item__DescriptionAssignment_3 ) )
            {
            // InternalAdventureDsl.g:511:1: ( ( rule__Item__DescriptionAssignment_3 ) )
            // InternalAdventureDsl.g:512:2: ( rule__Item__DescriptionAssignment_3 )
            {
             before(grammarAccess.getItemAccess().getDescriptionAssignment_3()); 
            // InternalAdventureDsl.g:513:2: ( rule__Item__DescriptionAssignment_3 )
            // InternalAdventureDsl.g:513:3: rule__Item__DescriptionAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Item__DescriptionAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getDescriptionAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__3__Impl"


    // $ANTLR start "rule__Item__Group__4"
    // InternalAdventureDsl.g:521:1: rule__Item__Group__4 : rule__Item__Group__4__Impl rule__Item__Group__5 ;
    public final void rule__Item__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:525:1: ( rule__Item__Group__4__Impl rule__Item__Group__5 )
            // InternalAdventureDsl.g:526:2: rule__Item__Group__4__Impl rule__Item__Group__5
            {
            pushFollow(FOLLOW_11);
            rule__Item__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__4"


    // $ANTLR start "rule__Item__Group__4__Impl"
    // InternalAdventureDsl.g:533:1: rule__Item__Group__4__Impl : ( ( rule__Item__Group_4__0 )? ) ;
    public final void rule__Item__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:537:1: ( ( ( rule__Item__Group_4__0 )? ) )
            // InternalAdventureDsl.g:538:1: ( ( rule__Item__Group_4__0 )? )
            {
            // InternalAdventureDsl.g:538:1: ( ( rule__Item__Group_4__0 )? )
            // InternalAdventureDsl.g:539:2: ( rule__Item__Group_4__0 )?
            {
             before(grammarAccess.getItemAccess().getGroup_4()); 
            // InternalAdventureDsl.g:540:2: ( rule__Item__Group_4__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==21) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalAdventureDsl.g:540:3: rule__Item__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Item__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getItemAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__4__Impl"


    // $ANTLR start "rule__Item__Group__5"
    // InternalAdventureDsl.g:548:1: rule__Item__Group__5 : rule__Item__Group__5__Impl ;
    public final void rule__Item__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:552:1: ( rule__Item__Group__5__Impl )
            // InternalAdventureDsl.g:553:2: rule__Item__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Item__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__5"


    // $ANTLR start "rule__Item__Group__5__Impl"
    // InternalAdventureDsl.g:559:1: rule__Item__Group__5__Impl : ( ( rule__Item__Group_5__0 )? ) ;
    public final void rule__Item__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:563:1: ( ( ( rule__Item__Group_5__0 )? ) )
            // InternalAdventureDsl.g:564:1: ( ( rule__Item__Group_5__0 )? )
            {
            // InternalAdventureDsl.g:564:1: ( ( rule__Item__Group_5__0 )? )
            // InternalAdventureDsl.g:565:2: ( rule__Item__Group_5__0 )?
            {
             before(grammarAccess.getItemAccess().getGroup_5()); 
            // InternalAdventureDsl.g:566:2: ( rule__Item__Group_5__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==25) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalAdventureDsl.g:566:3: rule__Item__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Item__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getItemAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group__5__Impl"


    // $ANTLR start "rule__Item__Group_4__0"
    // InternalAdventureDsl.g:575:1: rule__Item__Group_4__0 : rule__Item__Group_4__0__Impl rule__Item__Group_4__1 ;
    public final void rule__Item__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:579:1: ( rule__Item__Group_4__0__Impl rule__Item__Group_4__1 )
            // InternalAdventureDsl.g:580:2: rule__Item__Group_4__0__Impl rule__Item__Group_4__1
            {
            pushFollow(FOLLOW_12);
            rule__Item__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__0"


    // $ANTLR start "rule__Item__Group_4__0__Impl"
    // InternalAdventureDsl.g:587:1: rule__Item__Group_4__0__Impl : ( 'opens' ) ;
    public final void rule__Item__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:591:1: ( ( 'opens' ) )
            // InternalAdventureDsl.g:592:1: ( 'opens' )
            {
            // InternalAdventureDsl.g:592:1: ( 'opens' )
            // InternalAdventureDsl.g:593:2: 'opens'
            {
             before(grammarAccess.getItemAccess().getOpensKeyword_4_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getOpensKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__0__Impl"


    // $ANTLR start "rule__Item__Group_4__1"
    // InternalAdventureDsl.g:602:1: rule__Item__Group_4__1 : rule__Item__Group_4__1__Impl rule__Item__Group_4__2 ;
    public final void rule__Item__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:606:1: ( rule__Item__Group_4__1__Impl rule__Item__Group_4__2 )
            // InternalAdventureDsl.g:607:2: rule__Item__Group_4__1__Impl rule__Item__Group_4__2
            {
            pushFollow(FOLLOW_8);
            rule__Item__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__1"


    // $ANTLR start "rule__Item__Group_4__1__Impl"
    // InternalAdventureDsl.g:614:1: rule__Item__Group_4__1__Impl : ( 'with' ) ;
    public final void rule__Item__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:618:1: ( ( 'with' ) )
            // InternalAdventureDsl.g:619:1: ( 'with' )
            {
            // InternalAdventureDsl.g:619:1: ( 'with' )
            // InternalAdventureDsl.g:620:2: 'with'
            {
             before(grammarAccess.getItemAccess().getWithKeyword_4_1()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getWithKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__1__Impl"


    // $ANTLR start "rule__Item__Group_4__2"
    // InternalAdventureDsl.g:629:1: rule__Item__Group_4__2 : rule__Item__Group_4__2__Impl rule__Item__Group_4__3 ;
    public final void rule__Item__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:633:1: ( rule__Item__Group_4__2__Impl rule__Item__Group_4__3 )
            // InternalAdventureDsl.g:634:2: rule__Item__Group_4__2__Impl rule__Item__Group_4__3
            {
            pushFollow(FOLLOW_13);
            rule__Item__Group_4__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_4__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__2"


    // $ANTLR start "rule__Item__Group_4__2__Impl"
    // InternalAdventureDsl.g:641:1: rule__Item__Group_4__2__Impl : ( ( rule__Item__KeyAssignment_4_2 ) ) ;
    public final void rule__Item__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:645:1: ( ( ( rule__Item__KeyAssignment_4_2 ) ) )
            // InternalAdventureDsl.g:646:1: ( ( rule__Item__KeyAssignment_4_2 ) )
            {
            // InternalAdventureDsl.g:646:1: ( ( rule__Item__KeyAssignment_4_2 ) )
            // InternalAdventureDsl.g:647:2: ( rule__Item__KeyAssignment_4_2 )
            {
             before(grammarAccess.getItemAccess().getKeyAssignment_4_2()); 
            // InternalAdventureDsl.g:648:2: ( rule__Item__KeyAssignment_4_2 )
            // InternalAdventureDsl.g:648:3: rule__Item__KeyAssignment_4_2
            {
            pushFollow(FOLLOW_2);
            rule__Item__KeyAssignment_4_2();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getKeyAssignment_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__2__Impl"


    // $ANTLR start "rule__Item__Group_4__3"
    // InternalAdventureDsl.g:656:1: rule__Item__Group_4__3 : rule__Item__Group_4__3__Impl rule__Item__Group_4__4 ;
    public final void rule__Item__Group_4__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:660:1: ( rule__Item__Group_4__3__Impl rule__Item__Group_4__4 )
            // InternalAdventureDsl.g:661:2: rule__Item__Group_4__3__Impl rule__Item__Group_4__4
            {
            pushFollow(FOLLOW_14);
            rule__Item__Group_4__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_4__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__3"


    // $ANTLR start "rule__Item__Group_4__3__Impl"
    // InternalAdventureDsl.g:668:1: rule__Item__Group_4__3__Impl : ( ( rule__Item__Alternatives_4_3 ) ) ;
    public final void rule__Item__Group_4__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:672:1: ( ( ( rule__Item__Alternatives_4_3 ) ) )
            // InternalAdventureDsl.g:673:1: ( ( rule__Item__Alternatives_4_3 ) )
            {
            // InternalAdventureDsl.g:673:1: ( ( rule__Item__Alternatives_4_3 ) )
            // InternalAdventureDsl.g:674:2: ( rule__Item__Alternatives_4_3 )
            {
             before(grammarAccess.getItemAccess().getAlternatives_4_3()); 
            // InternalAdventureDsl.g:675:2: ( rule__Item__Alternatives_4_3 )
            // InternalAdventureDsl.g:675:3: rule__Item__Alternatives_4_3
            {
            pushFollow(FOLLOW_2);
            rule__Item__Alternatives_4_3();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getAlternatives_4_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__3__Impl"


    // $ANTLR start "rule__Item__Group_4__4"
    // InternalAdventureDsl.g:683:1: rule__Item__Group_4__4 : rule__Item__Group_4__4__Impl ;
    public final void rule__Item__Group_4__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:687:1: ( rule__Item__Group_4__4__Impl )
            // InternalAdventureDsl.g:688:2: rule__Item__Group_4__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Item__Group_4__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__4"


    // $ANTLR start "rule__Item__Group_4__4__Impl"
    // InternalAdventureDsl.g:694:1: rule__Item__Group_4__4__Impl : ( ( rule__Item__Alternatives_4_4 ) ) ;
    public final void rule__Item__Group_4__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:698:1: ( ( ( rule__Item__Alternatives_4_4 ) ) )
            // InternalAdventureDsl.g:699:1: ( ( rule__Item__Alternatives_4_4 ) )
            {
            // InternalAdventureDsl.g:699:1: ( ( rule__Item__Alternatives_4_4 ) )
            // InternalAdventureDsl.g:700:2: ( rule__Item__Alternatives_4_4 )
            {
             before(grammarAccess.getItemAccess().getAlternatives_4_4()); 
            // InternalAdventureDsl.g:701:2: ( rule__Item__Alternatives_4_4 )
            // InternalAdventureDsl.g:701:3: rule__Item__Alternatives_4_4
            {
            pushFollow(FOLLOW_2);
            rule__Item__Alternatives_4_4();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getAlternatives_4_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_4__4__Impl"


    // $ANTLR start "rule__Item__Group_5__0"
    // InternalAdventureDsl.g:710:1: rule__Item__Group_5__0 : rule__Item__Group_5__0__Impl rule__Item__Group_5__1 ;
    public final void rule__Item__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:714:1: ( rule__Item__Group_5__0__Impl rule__Item__Group_5__1 )
            // InternalAdventureDsl.g:715:2: rule__Item__Group_5__0__Impl rule__Item__Group_5__1
            {
            pushFollow(FOLLOW_8);
            rule__Item__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__0"


    // $ANTLR start "rule__Item__Group_5__0__Impl"
    // InternalAdventureDsl.g:722:1: rule__Item__Group_5__0__Impl : ( ( rule__Item__ContainerAssignment_5_0 ) ) ;
    public final void rule__Item__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:726:1: ( ( ( rule__Item__ContainerAssignment_5_0 ) ) )
            // InternalAdventureDsl.g:727:1: ( ( rule__Item__ContainerAssignment_5_0 ) )
            {
            // InternalAdventureDsl.g:727:1: ( ( rule__Item__ContainerAssignment_5_0 ) )
            // InternalAdventureDsl.g:728:2: ( rule__Item__ContainerAssignment_5_0 )
            {
             before(grammarAccess.getItemAccess().getContainerAssignment_5_0()); 
            // InternalAdventureDsl.g:729:2: ( rule__Item__ContainerAssignment_5_0 )
            // InternalAdventureDsl.g:729:3: rule__Item__ContainerAssignment_5_0
            {
            pushFollow(FOLLOW_2);
            rule__Item__ContainerAssignment_5_0();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getContainerAssignment_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__0__Impl"


    // $ANTLR start "rule__Item__Group_5__1"
    // InternalAdventureDsl.g:737:1: rule__Item__Group_5__1 : rule__Item__Group_5__1__Impl rule__Item__Group_5__2 ;
    public final void rule__Item__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:741:1: ( rule__Item__Group_5__1__Impl rule__Item__Group_5__2 )
            // InternalAdventureDsl.g:742:2: rule__Item__Group_5__1__Impl rule__Item__Group_5__2
            {
            pushFollow(FOLLOW_15);
            rule__Item__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__1"


    // $ANTLR start "rule__Item__Group_5__1__Impl"
    // InternalAdventureDsl.g:749:1: rule__Item__Group_5__1__Impl : ( ( rule__Item__ContentsAssignment_5_1 ) ) ;
    public final void rule__Item__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:753:1: ( ( ( rule__Item__ContentsAssignment_5_1 ) ) )
            // InternalAdventureDsl.g:754:1: ( ( rule__Item__ContentsAssignment_5_1 ) )
            {
            // InternalAdventureDsl.g:754:1: ( ( rule__Item__ContentsAssignment_5_1 ) )
            // InternalAdventureDsl.g:755:2: ( rule__Item__ContentsAssignment_5_1 )
            {
             before(grammarAccess.getItemAccess().getContentsAssignment_5_1()); 
            // InternalAdventureDsl.g:756:2: ( rule__Item__ContentsAssignment_5_1 )
            // InternalAdventureDsl.g:756:3: rule__Item__ContentsAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Item__ContentsAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getContentsAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__1__Impl"


    // $ANTLR start "rule__Item__Group_5__2"
    // InternalAdventureDsl.g:764:1: rule__Item__Group_5__2 : rule__Item__Group_5__2__Impl ;
    public final void rule__Item__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:768:1: ( rule__Item__Group_5__2__Impl )
            // InternalAdventureDsl.g:769:2: rule__Item__Group_5__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Item__Group_5__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__2"


    // $ANTLR start "rule__Item__Group_5__2__Impl"
    // InternalAdventureDsl.g:775:1: rule__Item__Group_5__2__Impl : ( ( rule__Item__Group_5_2__0 )* ) ;
    public final void rule__Item__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:779:1: ( ( ( rule__Item__Group_5_2__0 )* ) )
            // InternalAdventureDsl.g:780:1: ( ( rule__Item__Group_5_2__0 )* )
            {
            // InternalAdventureDsl.g:780:1: ( ( rule__Item__Group_5_2__0 )* )
            // InternalAdventureDsl.g:781:2: ( rule__Item__Group_5_2__0 )*
            {
             before(grammarAccess.getItemAccess().getGroup_5_2()); 
            // InternalAdventureDsl.g:782:2: ( rule__Item__Group_5_2__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==23) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalAdventureDsl.g:782:3: rule__Item__Group_5_2__0
            	    {
            	    pushFollow(FOLLOW_16);
            	    rule__Item__Group_5_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getItemAccess().getGroup_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5__2__Impl"


    // $ANTLR start "rule__Item__Group_5_2__0"
    // InternalAdventureDsl.g:791:1: rule__Item__Group_5_2__0 : rule__Item__Group_5_2__0__Impl rule__Item__Group_5_2__1 ;
    public final void rule__Item__Group_5_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:795:1: ( rule__Item__Group_5_2__0__Impl rule__Item__Group_5_2__1 )
            // InternalAdventureDsl.g:796:2: rule__Item__Group_5_2__0__Impl rule__Item__Group_5_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Item__Group_5_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Item__Group_5_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5_2__0"


    // $ANTLR start "rule__Item__Group_5_2__0__Impl"
    // InternalAdventureDsl.g:803:1: rule__Item__Group_5_2__0__Impl : ( ',' ) ;
    public final void rule__Item__Group_5_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:807:1: ( ( ',' ) )
            // InternalAdventureDsl.g:808:1: ( ',' )
            {
            // InternalAdventureDsl.g:808:1: ( ',' )
            // InternalAdventureDsl.g:809:2: ','
            {
             before(grammarAccess.getItemAccess().getCommaKeyword_5_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getCommaKeyword_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5_2__0__Impl"


    // $ANTLR start "rule__Item__Group_5_2__1"
    // InternalAdventureDsl.g:818:1: rule__Item__Group_5_2__1 : rule__Item__Group_5_2__1__Impl ;
    public final void rule__Item__Group_5_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:822:1: ( rule__Item__Group_5_2__1__Impl )
            // InternalAdventureDsl.g:823:2: rule__Item__Group_5_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Item__Group_5_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5_2__1"


    // $ANTLR start "rule__Item__Group_5_2__1__Impl"
    // InternalAdventureDsl.g:829:1: rule__Item__Group_5_2__1__Impl : ( ( rule__Item__ContentsAssignment_5_2_1 ) ) ;
    public final void rule__Item__Group_5_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:833:1: ( ( ( rule__Item__ContentsAssignment_5_2_1 ) ) )
            // InternalAdventureDsl.g:834:1: ( ( rule__Item__ContentsAssignment_5_2_1 ) )
            {
            // InternalAdventureDsl.g:834:1: ( ( rule__Item__ContentsAssignment_5_2_1 ) )
            // InternalAdventureDsl.g:835:2: ( rule__Item__ContentsAssignment_5_2_1 )
            {
             before(grammarAccess.getItemAccess().getContentsAssignment_5_2_1()); 
            // InternalAdventureDsl.g:836:2: ( rule__Item__ContentsAssignment_5_2_1 )
            // InternalAdventureDsl.g:836:3: rule__Item__ContentsAssignment_5_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Item__ContentsAssignment_5_2_1();

            state._fsp--;


            }

             after(grammarAccess.getItemAccess().getContentsAssignment_5_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__Group_5_2__1__Impl"


    // $ANTLR start "rule__Room__Group__0"
    // InternalAdventureDsl.g:845:1: rule__Room__Group__0 : rule__Room__Group__0__Impl rule__Room__Group__1 ;
    public final void rule__Room__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:849:1: ( rule__Room__Group__0__Impl rule__Room__Group__1 )
            // InternalAdventureDsl.g:850:2: rule__Room__Group__0__Impl rule__Room__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Room__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__0"


    // $ANTLR start "rule__Room__Group__0__Impl"
    // InternalAdventureDsl.g:857:1: rule__Room__Group__0__Impl : ( 'room' ) ;
    public final void rule__Room__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:861:1: ( ( 'room' ) )
            // InternalAdventureDsl.g:862:1: ( 'room' )
            {
            // InternalAdventureDsl.g:862:1: ( 'room' )
            // InternalAdventureDsl.g:863:2: 'room'
            {
             before(grammarAccess.getRoomAccess().getRoomKeyword_0()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getRoomKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__0__Impl"


    // $ANTLR start "rule__Room__Group__1"
    // InternalAdventureDsl.g:872:1: rule__Room__Group__1 : rule__Room__Group__1__Impl rule__Room__Group__2 ;
    public final void rule__Room__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:876:1: ( rule__Room__Group__1__Impl rule__Room__Group__2 )
            // InternalAdventureDsl.g:877:2: rule__Room__Group__1__Impl rule__Room__Group__2
            {
            pushFollow(FOLLOW_10);
            rule__Room__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__1"


    // $ANTLR start "rule__Room__Group__1__Impl"
    // InternalAdventureDsl.g:884:1: rule__Room__Group__1__Impl : ( ( rule__Room__NameAssignment_1 ) ) ;
    public final void rule__Room__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:888:1: ( ( ( rule__Room__NameAssignment_1 ) ) )
            // InternalAdventureDsl.g:889:1: ( ( rule__Room__NameAssignment_1 ) )
            {
            // InternalAdventureDsl.g:889:1: ( ( rule__Room__NameAssignment_1 ) )
            // InternalAdventureDsl.g:890:2: ( rule__Room__NameAssignment_1 )
            {
             before(grammarAccess.getRoomAccess().getNameAssignment_1()); 
            // InternalAdventureDsl.g:891:2: ( rule__Room__NameAssignment_1 )
            // InternalAdventureDsl.g:891:3: rule__Room__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Room__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getRoomAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__1__Impl"


    // $ANTLR start "rule__Room__Group__2"
    // InternalAdventureDsl.g:899:1: rule__Room__Group__2 : rule__Room__Group__2__Impl rule__Room__Group__3 ;
    public final void rule__Room__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:903:1: ( rule__Room__Group__2__Impl rule__Room__Group__3 )
            // InternalAdventureDsl.g:904:2: rule__Room__Group__2__Impl rule__Room__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__Room__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__2"


    // $ANTLR start "rule__Room__Group__2__Impl"
    // InternalAdventureDsl.g:911:1: rule__Room__Group__2__Impl : ( ( rule__Room__DescriptionAssignment_2 ) ) ;
    public final void rule__Room__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:915:1: ( ( ( rule__Room__DescriptionAssignment_2 ) ) )
            // InternalAdventureDsl.g:916:1: ( ( rule__Room__DescriptionAssignment_2 ) )
            {
            // InternalAdventureDsl.g:916:1: ( ( rule__Room__DescriptionAssignment_2 ) )
            // InternalAdventureDsl.g:917:2: ( rule__Room__DescriptionAssignment_2 )
            {
             before(grammarAccess.getRoomAccess().getDescriptionAssignment_2()); 
            // InternalAdventureDsl.g:918:2: ( rule__Room__DescriptionAssignment_2 )
            // InternalAdventureDsl.g:918:3: rule__Room__DescriptionAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Room__DescriptionAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRoomAccess().getDescriptionAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__2__Impl"


    // $ANTLR start "rule__Room__Group__3"
    // InternalAdventureDsl.g:926:1: rule__Room__Group__3 : rule__Room__Group__3__Impl rule__Room__Group__4 ;
    public final void rule__Room__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:930:1: ( rule__Room__Group__3__Impl rule__Room__Group__4 )
            // InternalAdventureDsl.g:931:2: rule__Room__Group__3__Impl rule__Room__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__Room__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__3"


    // $ANTLR start "rule__Room__Group__3__Impl"
    // InternalAdventureDsl.g:938:1: rule__Room__Group__3__Impl : ( ( rule__Room__Group_3__0 )? ) ;
    public final void rule__Room__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:942:1: ( ( ( rule__Room__Group_3__0 )? ) )
            // InternalAdventureDsl.g:943:1: ( ( rule__Room__Group_3__0 )? )
            {
            // InternalAdventureDsl.g:943:1: ( ( rule__Room__Group_3__0 )? )
            // InternalAdventureDsl.g:944:2: ( rule__Room__Group_3__0 )?
            {
             before(grammarAccess.getRoomAccess().getGroup_3()); 
            // InternalAdventureDsl.g:945:2: ( rule__Room__Group_3__0 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==25) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalAdventureDsl.g:945:3: rule__Room__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Room__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getRoomAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__3__Impl"


    // $ANTLR start "rule__Room__Group__4"
    // InternalAdventureDsl.g:953:1: rule__Room__Group__4 : rule__Room__Group__4__Impl ;
    public final void rule__Room__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:957:1: ( rule__Room__Group__4__Impl )
            // InternalAdventureDsl.g:958:2: rule__Room__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Room__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__4"


    // $ANTLR start "rule__Room__Group__4__Impl"
    // InternalAdventureDsl.g:964:1: rule__Room__Group__4__Impl : ( ( rule__Room__ExitsAssignment_4 )* ) ;
    public final void rule__Room__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:968:1: ( ( ( rule__Room__ExitsAssignment_4 )* ) )
            // InternalAdventureDsl.g:969:1: ( ( rule__Room__ExitsAssignment_4 )* )
            {
            // InternalAdventureDsl.g:969:1: ( ( rule__Room__ExitsAssignment_4 )* )
            // InternalAdventureDsl.g:970:2: ( rule__Room__ExitsAssignment_4 )*
            {
             before(grammarAccess.getRoomAccess().getExitsAssignment_4()); 
            // InternalAdventureDsl.g:971:2: ( rule__Room__ExitsAssignment_4 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==26) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalAdventureDsl.g:971:3: rule__Room__ExitsAssignment_4
            	    {
            	    pushFollow(FOLLOW_18);
            	    rule__Room__ExitsAssignment_4();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getRoomAccess().getExitsAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group__4__Impl"


    // $ANTLR start "rule__Room__Group_3__0"
    // InternalAdventureDsl.g:980:1: rule__Room__Group_3__0 : rule__Room__Group_3__0__Impl rule__Room__Group_3__1 ;
    public final void rule__Room__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:984:1: ( rule__Room__Group_3__0__Impl rule__Room__Group_3__1 )
            // InternalAdventureDsl.g:985:2: rule__Room__Group_3__0__Impl rule__Room__Group_3__1
            {
            pushFollow(FOLLOW_8);
            rule__Room__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__0"


    // $ANTLR start "rule__Room__Group_3__0__Impl"
    // InternalAdventureDsl.g:992:1: rule__Room__Group_3__0__Impl : ( 'contains' ) ;
    public final void rule__Room__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:996:1: ( ( 'contains' ) )
            // InternalAdventureDsl.g:997:1: ( 'contains' )
            {
            // InternalAdventureDsl.g:997:1: ( 'contains' )
            // InternalAdventureDsl.g:998:2: 'contains'
            {
             before(grammarAccess.getRoomAccess().getContainsKeyword_3_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getContainsKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__0__Impl"


    // $ANTLR start "rule__Room__Group_3__1"
    // InternalAdventureDsl.g:1007:1: rule__Room__Group_3__1 : rule__Room__Group_3__1__Impl rule__Room__Group_3__2 ;
    public final void rule__Room__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1011:1: ( rule__Room__Group_3__1__Impl rule__Room__Group_3__2 )
            // InternalAdventureDsl.g:1012:2: rule__Room__Group_3__1__Impl rule__Room__Group_3__2
            {
            pushFollow(FOLLOW_15);
            rule__Room__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__1"


    // $ANTLR start "rule__Room__Group_3__1__Impl"
    // InternalAdventureDsl.g:1019:1: rule__Room__Group_3__1__Impl : ( ( rule__Room__ContentsAssignment_3_1 ) ) ;
    public final void rule__Room__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1023:1: ( ( ( rule__Room__ContentsAssignment_3_1 ) ) )
            // InternalAdventureDsl.g:1024:1: ( ( rule__Room__ContentsAssignment_3_1 ) )
            {
            // InternalAdventureDsl.g:1024:1: ( ( rule__Room__ContentsAssignment_3_1 ) )
            // InternalAdventureDsl.g:1025:2: ( rule__Room__ContentsAssignment_3_1 )
            {
             before(grammarAccess.getRoomAccess().getContentsAssignment_3_1()); 
            // InternalAdventureDsl.g:1026:2: ( rule__Room__ContentsAssignment_3_1 )
            // InternalAdventureDsl.g:1026:3: rule__Room__ContentsAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Room__ContentsAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getRoomAccess().getContentsAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__1__Impl"


    // $ANTLR start "rule__Room__Group_3__2"
    // InternalAdventureDsl.g:1034:1: rule__Room__Group_3__2 : rule__Room__Group_3__2__Impl ;
    public final void rule__Room__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1038:1: ( rule__Room__Group_3__2__Impl )
            // InternalAdventureDsl.g:1039:2: rule__Room__Group_3__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Room__Group_3__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__2"


    // $ANTLR start "rule__Room__Group_3__2__Impl"
    // InternalAdventureDsl.g:1045:1: rule__Room__Group_3__2__Impl : ( ( rule__Room__Group_3_2__0 )* ) ;
    public final void rule__Room__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1049:1: ( ( ( rule__Room__Group_3_2__0 )* ) )
            // InternalAdventureDsl.g:1050:1: ( ( rule__Room__Group_3_2__0 )* )
            {
            // InternalAdventureDsl.g:1050:1: ( ( rule__Room__Group_3_2__0 )* )
            // InternalAdventureDsl.g:1051:2: ( rule__Room__Group_3_2__0 )*
            {
             before(grammarAccess.getRoomAccess().getGroup_3_2()); 
            // InternalAdventureDsl.g:1052:2: ( rule__Room__Group_3_2__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==23) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalAdventureDsl.g:1052:3: rule__Room__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_16);
            	    rule__Room__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getRoomAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3__2__Impl"


    // $ANTLR start "rule__Room__Group_3_2__0"
    // InternalAdventureDsl.g:1061:1: rule__Room__Group_3_2__0 : rule__Room__Group_3_2__0__Impl rule__Room__Group_3_2__1 ;
    public final void rule__Room__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1065:1: ( rule__Room__Group_3_2__0__Impl rule__Room__Group_3_2__1 )
            // InternalAdventureDsl.g:1066:2: rule__Room__Group_3_2__0__Impl rule__Room__Group_3_2__1
            {
            pushFollow(FOLLOW_8);
            rule__Room__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Room__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3_2__0"


    // $ANTLR start "rule__Room__Group_3_2__0__Impl"
    // InternalAdventureDsl.g:1073:1: rule__Room__Group_3_2__0__Impl : ( ',' ) ;
    public final void rule__Room__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1077:1: ( ( ',' ) )
            // InternalAdventureDsl.g:1078:1: ( ',' )
            {
            // InternalAdventureDsl.g:1078:1: ( ',' )
            // InternalAdventureDsl.g:1079:2: ','
            {
             before(grammarAccess.getRoomAccess().getCommaKeyword_3_2_0()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3_2__0__Impl"


    // $ANTLR start "rule__Room__Group_3_2__1"
    // InternalAdventureDsl.g:1088:1: rule__Room__Group_3_2__1 : rule__Room__Group_3_2__1__Impl ;
    public final void rule__Room__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1092:1: ( rule__Room__Group_3_2__1__Impl )
            // InternalAdventureDsl.g:1093:2: rule__Room__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Room__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3_2__1"


    // $ANTLR start "rule__Room__Group_3_2__1__Impl"
    // InternalAdventureDsl.g:1099:1: rule__Room__Group_3_2__1__Impl : ( ( rule__Room__ContentsAssignment_3_2_1 ) ) ;
    public final void rule__Room__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1103:1: ( ( ( rule__Room__ContentsAssignment_3_2_1 ) ) )
            // InternalAdventureDsl.g:1104:1: ( ( rule__Room__ContentsAssignment_3_2_1 ) )
            {
            // InternalAdventureDsl.g:1104:1: ( ( rule__Room__ContentsAssignment_3_2_1 ) )
            // InternalAdventureDsl.g:1105:2: ( rule__Room__ContentsAssignment_3_2_1 )
            {
             before(grammarAccess.getRoomAccess().getContentsAssignment_3_2_1()); 
            // InternalAdventureDsl.g:1106:2: ( rule__Room__ContentsAssignment_3_2_1 )
            // InternalAdventureDsl.g:1106:3: rule__Room__ContentsAssignment_3_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Room__ContentsAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getRoomAccess().getContentsAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__Group_3_2__1__Impl"


    // $ANTLR start "rule__Exit__Group__0"
    // InternalAdventureDsl.g:1115:1: rule__Exit__Group__0 : rule__Exit__Group__0__Impl rule__Exit__Group__1 ;
    public final void rule__Exit__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1119:1: ( rule__Exit__Group__0__Impl rule__Exit__Group__1 )
            // InternalAdventureDsl.g:1120:2: rule__Exit__Group__0__Impl rule__Exit__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__Exit__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Exit__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__0"


    // $ANTLR start "rule__Exit__Group__0__Impl"
    // InternalAdventureDsl.g:1127:1: rule__Exit__Group__0__Impl : ( 'exit' ) ;
    public final void rule__Exit__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1131:1: ( ( 'exit' ) )
            // InternalAdventureDsl.g:1132:1: ( 'exit' )
            {
            // InternalAdventureDsl.g:1132:1: ( 'exit' )
            // InternalAdventureDsl.g:1133:2: 'exit'
            {
             before(grammarAccess.getExitAccess().getExitKeyword_0()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getExitAccess().getExitKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__0__Impl"


    // $ANTLR start "rule__Exit__Group__1"
    // InternalAdventureDsl.g:1142:1: rule__Exit__Group__1 : rule__Exit__Group__1__Impl rule__Exit__Group__2 ;
    public final void rule__Exit__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1146:1: ( rule__Exit__Group__1__Impl rule__Exit__Group__2 )
            // InternalAdventureDsl.g:1147:2: rule__Exit__Group__1__Impl rule__Exit__Group__2
            {
            pushFollow(FOLLOW_8);
            rule__Exit__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Exit__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__1"


    // $ANTLR start "rule__Exit__Group__1__Impl"
    // InternalAdventureDsl.g:1154:1: rule__Exit__Group__1__Impl : ( ( rule__Exit__DirectionAssignment_1 ) ) ;
    public final void rule__Exit__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1158:1: ( ( ( rule__Exit__DirectionAssignment_1 ) ) )
            // InternalAdventureDsl.g:1159:1: ( ( rule__Exit__DirectionAssignment_1 ) )
            {
            // InternalAdventureDsl.g:1159:1: ( ( rule__Exit__DirectionAssignment_1 ) )
            // InternalAdventureDsl.g:1160:2: ( rule__Exit__DirectionAssignment_1 )
            {
             before(grammarAccess.getExitAccess().getDirectionAssignment_1()); 
            // InternalAdventureDsl.g:1161:2: ( rule__Exit__DirectionAssignment_1 )
            // InternalAdventureDsl.g:1161:3: rule__Exit__DirectionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Exit__DirectionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getExitAccess().getDirectionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__1__Impl"


    // $ANTLR start "rule__Exit__Group__2"
    // InternalAdventureDsl.g:1169:1: rule__Exit__Group__2 : rule__Exit__Group__2__Impl ;
    public final void rule__Exit__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1173:1: ( rule__Exit__Group__2__Impl )
            // InternalAdventureDsl.g:1174:2: rule__Exit__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Exit__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__2"


    // $ANTLR start "rule__Exit__Group__2__Impl"
    // InternalAdventureDsl.g:1180:1: rule__Exit__Group__2__Impl : ( ( rule__Exit__ToAssignment_2 ) ) ;
    public final void rule__Exit__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1184:1: ( ( ( rule__Exit__ToAssignment_2 ) ) )
            // InternalAdventureDsl.g:1185:1: ( ( rule__Exit__ToAssignment_2 ) )
            {
            // InternalAdventureDsl.g:1185:1: ( ( rule__Exit__ToAssignment_2 ) )
            // InternalAdventureDsl.g:1186:2: ( rule__Exit__ToAssignment_2 )
            {
             before(grammarAccess.getExitAccess().getToAssignment_2()); 
            // InternalAdventureDsl.g:1187:2: ( rule__Exit__ToAssignment_2 )
            // InternalAdventureDsl.g:1187:3: rule__Exit__ToAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Exit__ToAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getExitAccess().getToAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__Group__2__Impl"


    // $ANTLR start "rule__Model__ItemsAssignment_0"
    // InternalAdventureDsl.g:1196:1: rule__Model__ItemsAssignment_0 : ( ruleItem ) ;
    public final void rule__Model__ItemsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1200:1: ( ( ruleItem ) )
            // InternalAdventureDsl.g:1201:2: ( ruleItem )
            {
            // InternalAdventureDsl.g:1201:2: ( ruleItem )
            // InternalAdventureDsl.g:1202:3: ruleItem
            {
             before(grammarAccess.getModelAccess().getItemsItemParserRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleItem();

            state._fsp--;

             after(grammarAccess.getModelAccess().getItemsItemParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__ItemsAssignment_0"


    // $ANTLR start "rule__Model__RoomsAssignment_1"
    // InternalAdventureDsl.g:1211:1: rule__Model__RoomsAssignment_1 : ( ruleRoom ) ;
    public final void rule__Model__RoomsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1215:1: ( ( ruleRoom ) )
            // InternalAdventureDsl.g:1216:2: ( ruleRoom )
            {
            // InternalAdventureDsl.g:1216:2: ( ruleRoom )
            // InternalAdventureDsl.g:1217:3: ruleRoom
            {
             before(grammarAccess.getModelAccess().getRoomsRoomParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleRoom();

            state._fsp--;

             after(grammarAccess.getModelAccess().getRoomsRoomParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__RoomsAssignment_1"


    // $ANTLR start "rule__Model__StartRoomAssignment_4"
    // InternalAdventureDsl.g:1226:1: rule__Model__StartRoomAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__Model__StartRoomAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1230:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1231:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1231:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1232:3: ( RULE_ID )
            {
             before(grammarAccess.getModelAccess().getStartRoomRoomCrossReference_4_0()); 
            // InternalAdventureDsl.g:1233:3: ( RULE_ID )
            // InternalAdventureDsl.g:1234:4: RULE_ID
            {
             before(grammarAccess.getModelAccess().getStartRoomRoomIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModelAccess().getStartRoomRoomIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getModelAccess().getStartRoomRoomCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__StartRoomAssignment_4"


    // $ANTLR start "rule__Item__CarryableAssignment_0_0"
    // InternalAdventureDsl.g:1245:1: rule__Item__CarryableAssignment_0_0 : ( ( 'carryable' ) ) ;
    public final void rule__Item__CarryableAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1249:1: ( ( ( 'carryable' ) ) )
            // InternalAdventureDsl.g:1250:2: ( ( 'carryable' ) )
            {
            // InternalAdventureDsl.g:1250:2: ( ( 'carryable' ) )
            // InternalAdventureDsl.g:1251:3: ( 'carryable' )
            {
             before(grammarAccess.getItemAccess().getCarryableCarryableKeyword_0_0_0()); 
            // InternalAdventureDsl.g:1252:3: ( 'carryable' )
            // InternalAdventureDsl.g:1253:4: 'carryable'
            {
             before(grammarAccess.getItemAccess().getCarryableCarryableKeyword_0_0_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getCarryableCarryableKeyword_0_0_0()); 

            }

             after(grammarAccess.getItemAccess().getCarryableCarryableKeyword_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__CarryableAssignment_0_0"


    // $ANTLR start "rule__Item__NameAssignment_2"
    // InternalAdventureDsl.g:1264:1: rule__Item__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Item__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1268:1: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1269:2: ( RULE_ID )
            {
            // InternalAdventureDsl.g:1269:2: ( RULE_ID )
            // InternalAdventureDsl.g:1270:3: RULE_ID
            {
             before(grammarAccess.getItemAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__NameAssignment_2"


    // $ANTLR start "rule__Item__DescriptionAssignment_3"
    // InternalAdventureDsl.g:1279:1: rule__Item__DescriptionAssignment_3 : ( RULE_STRING ) ;
    public final void rule__Item__DescriptionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1283:1: ( ( RULE_STRING ) )
            // InternalAdventureDsl.g:1284:2: ( RULE_STRING )
            {
            // InternalAdventureDsl.g:1284:2: ( RULE_STRING )
            // InternalAdventureDsl.g:1285:3: RULE_STRING
            {
             before(grammarAccess.getItemAccess().getDescriptionSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getDescriptionSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__DescriptionAssignment_3"


    // $ANTLR start "rule__Item__KeyAssignment_4_2"
    // InternalAdventureDsl.g:1294:1: rule__Item__KeyAssignment_4_2 : ( ( RULE_ID ) ) ;
    public final void rule__Item__KeyAssignment_4_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1298:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1299:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1299:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1300:3: ( RULE_ID )
            {
             before(grammarAccess.getItemAccess().getKeyItemCrossReference_4_2_0()); 
            // InternalAdventureDsl.g:1301:3: ( RULE_ID )
            // InternalAdventureDsl.g:1302:4: RULE_ID
            {
             before(grammarAccess.getItemAccess().getKeyItemIDTerminalRuleCall_4_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getKeyItemIDTerminalRuleCall_4_2_0_1()); 

            }

             after(grammarAccess.getItemAccess().getKeyItemCrossReference_4_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__KeyAssignment_4_2"


    // $ANTLR start "rule__Item__LockedAssignment_4_3_0"
    // InternalAdventureDsl.g:1313:1: rule__Item__LockedAssignment_4_3_0 : ( ( 'locked' ) ) ;
    public final void rule__Item__LockedAssignment_4_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1317:1: ( ( ( 'locked' ) ) )
            // InternalAdventureDsl.g:1318:2: ( ( 'locked' ) )
            {
            // InternalAdventureDsl.g:1318:2: ( ( 'locked' ) )
            // InternalAdventureDsl.g:1319:3: ( 'locked' )
            {
             before(grammarAccess.getItemAccess().getLockedLockedKeyword_4_3_0_0()); 
            // InternalAdventureDsl.g:1320:3: ( 'locked' )
            // InternalAdventureDsl.g:1321:4: 'locked'
            {
             before(grammarAccess.getItemAccess().getLockedLockedKeyword_4_3_0_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getLockedLockedKeyword_4_3_0_0()); 

            }

             after(grammarAccess.getItemAccess().getLockedLockedKeyword_4_3_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__LockedAssignment_4_3_0"


    // $ANTLR start "rule__Item__OpenAssignment_4_4_0"
    // InternalAdventureDsl.g:1332:1: rule__Item__OpenAssignment_4_4_0 : ( ( 'open' ) ) ;
    public final void rule__Item__OpenAssignment_4_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1336:1: ( ( ( 'open' ) ) )
            // InternalAdventureDsl.g:1337:2: ( ( 'open' ) )
            {
            // InternalAdventureDsl.g:1337:2: ( ( 'open' ) )
            // InternalAdventureDsl.g:1338:3: ( 'open' )
            {
             before(grammarAccess.getItemAccess().getOpenOpenKeyword_4_4_0_0()); 
            // InternalAdventureDsl.g:1339:3: ( 'open' )
            // InternalAdventureDsl.g:1340:4: 'open'
            {
             before(grammarAccess.getItemAccess().getOpenOpenKeyword_4_4_0_0()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getOpenOpenKeyword_4_4_0_0()); 

            }

             after(grammarAccess.getItemAccess().getOpenOpenKeyword_4_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__OpenAssignment_4_4_0"


    // $ANTLR start "rule__Item__ContainerAssignment_5_0"
    // InternalAdventureDsl.g:1351:1: rule__Item__ContainerAssignment_5_0 : ( ( 'contains' ) ) ;
    public final void rule__Item__ContainerAssignment_5_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1355:1: ( ( ( 'contains' ) ) )
            // InternalAdventureDsl.g:1356:2: ( ( 'contains' ) )
            {
            // InternalAdventureDsl.g:1356:2: ( ( 'contains' ) )
            // InternalAdventureDsl.g:1357:3: ( 'contains' )
            {
             before(grammarAccess.getItemAccess().getContainerContainsKeyword_5_0_0()); 
            // InternalAdventureDsl.g:1358:3: ( 'contains' )
            // InternalAdventureDsl.g:1359:4: 'contains'
            {
             before(grammarAccess.getItemAccess().getContainerContainsKeyword_5_0_0()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getContainerContainsKeyword_5_0_0()); 

            }

             after(grammarAccess.getItemAccess().getContainerContainsKeyword_5_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__ContainerAssignment_5_0"


    // $ANTLR start "rule__Item__ContentsAssignment_5_1"
    // InternalAdventureDsl.g:1370:1: rule__Item__ContentsAssignment_5_1 : ( ( RULE_ID ) ) ;
    public final void rule__Item__ContentsAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1374:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1375:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1375:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1376:3: ( RULE_ID )
            {
             before(grammarAccess.getItemAccess().getContentsItemCrossReference_5_1_0()); 
            // InternalAdventureDsl.g:1377:3: ( RULE_ID )
            // InternalAdventureDsl.g:1378:4: RULE_ID
            {
             before(grammarAccess.getItemAccess().getContentsItemIDTerminalRuleCall_5_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getContentsItemIDTerminalRuleCall_5_1_0_1()); 

            }

             after(grammarAccess.getItemAccess().getContentsItemCrossReference_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__ContentsAssignment_5_1"


    // $ANTLR start "rule__Item__ContentsAssignment_5_2_1"
    // InternalAdventureDsl.g:1389:1: rule__Item__ContentsAssignment_5_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__Item__ContentsAssignment_5_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1393:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1394:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1394:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1395:3: ( RULE_ID )
            {
             before(grammarAccess.getItemAccess().getContentsItemCrossReference_5_2_1_0()); 
            // InternalAdventureDsl.g:1396:3: ( RULE_ID )
            // InternalAdventureDsl.g:1397:4: RULE_ID
            {
             before(grammarAccess.getItemAccess().getContentsItemIDTerminalRuleCall_5_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getItemAccess().getContentsItemIDTerminalRuleCall_5_2_1_0_1()); 

            }

             after(grammarAccess.getItemAccess().getContentsItemCrossReference_5_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Item__ContentsAssignment_5_2_1"


    // $ANTLR start "rule__Room__NameAssignment_1"
    // InternalAdventureDsl.g:1408:1: rule__Room__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__Room__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1412:1: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1413:2: ( RULE_ID )
            {
            // InternalAdventureDsl.g:1413:2: ( RULE_ID )
            // InternalAdventureDsl.g:1414:3: RULE_ID
            {
             before(grammarAccess.getRoomAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__NameAssignment_1"


    // $ANTLR start "rule__Room__DescriptionAssignment_2"
    // InternalAdventureDsl.g:1423:1: rule__Room__DescriptionAssignment_2 : ( RULE_STRING ) ;
    public final void rule__Room__DescriptionAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1427:1: ( ( RULE_STRING ) )
            // InternalAdventureDsl.g:1428:2: ( RULE_STRING )
            {
            // InternalAdventureDsl.g:1428:2: ( RULE_STRING )
            // InternalAdventureDsl.g:1429:3: RULE_STRING
            {
             before(grammarAccess.getRoomAccess().getDescriptionSTRINGTerminalRuleCall_2_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getDescriptionSTRINGTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__DescriptionAssignment_2"


    // $ANTLR start "rule__Room__ContentsAssignment_3_1"
    // InternalAdventureDsl.g:1438:1: rule__Room__ContentsAssignment_3_1 : ( ( RULE_ID ) ) ;
    public final void rule__Room__ContentsAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1442:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1443:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1443:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1444:3: ( RULE_ID )
            {
             before(grammarAccess.getRoomAccess().getContentsItemCrossReference_3_1_0()); 
            // InternalAdventureDsl.g:1445:3: ( RULE_ID )
            // InternalAdventureDsl.g:1446:4: RULE_ID
            {
             before(grammarAccess.getRoomAccess().getContentsItemIDTerminalRuleCall_3_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getContentsItemIDTerminalRuleCall_3_1_0_1()); 

            }

             after(grammarAccess.getRoomAccess().getContentsItemCrossReference_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__ContentsAssignment_3_1"


    // $ANTLR start "rule__Room__ContentsAssignment_3_2_1"
    // InternalAdventureDsl.g:1457:1: rule__Room__ContentsAssignment_3_2_1 : ( ( RULE_ID ) ) ;
    public final void rule__Room__ContentsAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1461:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1462:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1462:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1463:3: ( RULE_ID )
            {
             before(grammarAccess.getRoomAccess().getContentsItemCrossReference_3_2_1_0()); 
            // InternalAdventureDsl.g:1464:3: ( RULE_ID )
            // InternalAdventureDsl.g:1465:4: RULE_ID
            {
             before(grammarAccess.getRoomAccess().getContentsItemIDTerminalRuleCall_3_2_1_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getRoomAccess().getContentsItemIDTerminalRuleCall_3_2_1_0_1()); 

            }

             after(grammarAccess.getRoomAccess().getContentsItemCrossReference_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__ContentsAssignment_3_2_1"


    // $ANTLR start "rule__Room__ExitsAssignment_4"
    // InternalAdventureDsl.g:1476:1: rule__Room__ExitsAssignment_4 : ( ruleExit ) ;
    public final void rule__Room__ExitsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1480:1: ( ( ruleExit ) )
            // InternalAdventureDsl.g:1481:2: ( ruleExit )
            {
            // InternalAdventureDsl.g:1481:2: ( ruleExit )
            // InternalAdventureDsl.g:1482:3: ruleExit
            {
             before(grammarAccess.getRoomAccess().getExitsExitParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleExit();

            state._fsp--;

             after(grammarAccess.getRoomAccess().getExitsExitParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Room__ExitsAssignment_4"


    // $ANTLR start "rule__Exit__DirectionAssignment_1"
    // InternalAdventureDsl.g:1491:1: rule__Exit__DirectionAssignment_1 : ( ruleDirection ) ;
    public final void rule__Exit__DirectionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1495:1: ( ( ruleDirection ) )
            // InternalAdventureDsl.g:1496:2: ( ruleDirection )
            {
            // InternalAdventureDsl.g:1496:2: ( ruleDirection )
            // InternalAdventureDsl.g:1497:3: ruleDirection
            {
             before(grammarAccess.getExitAccess().getDirectionDirectionEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleDirection();

            state._fsp--;

             after(grammarAccess.getExitAccess().getDirectionDirectionEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__DirectionAssignment_1"


    // $ANTLR start "rule__Exit__ToAssignment_2"
    // InternalAdventureDsl.g:1506:1: rule__Exit__ToAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__Exit__ToAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalAdventureDsl.g:1510:1: ( ( ( RULE_ID ) ) )
            // InternalAdventureDsl.g:1511:2: ( ( RULE_ID ) )
            {
            // InternalAdventureDsl.g:1511:2: ( ( RULE_ID ) )
            // InternalAdventureDsl.g:1512:3: ( RULE_ID )
            {
             before(grammarAccess.getExitAccess().getToRoomCrossReference_2_0()); 
            // InternalAdventureDsl.g:1513:3: ( RULE_ID )
            // InternalAdventureDsl.g:1514:4: RULE_ID
            {
             before(grammarAccess.getExitAccess().getToRoomIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getExitAccess().getToRoomIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getExitAccess().getToRoomCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Exit__ToAssignment_2"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000008000802L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000002200000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000010001000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000020002000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000006000000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000004000002L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x000000000003C000L});

}