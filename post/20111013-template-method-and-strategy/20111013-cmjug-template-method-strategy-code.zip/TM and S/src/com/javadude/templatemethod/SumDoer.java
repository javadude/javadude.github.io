package com.javadude.templatemethod;

public class SumDoer implements SomethingDoer {
	private int sum = 0;
	@Override
	public void doSomething(BinaryTreeNode node) {
		sum += node.getData();
	}
	public int getSum() {
		return sum;
	}
}
