package com.javadude.templatemethod;

public class NullDoer implements SomethingDoer {
	@Override
	public void doSomething(BinaryTreeNode node) {
	}
}
