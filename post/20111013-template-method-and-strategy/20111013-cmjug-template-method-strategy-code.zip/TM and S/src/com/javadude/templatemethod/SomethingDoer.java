package com.javadude.templatemethod;

// STRATEGY
public interface SomethingDoer {
	// HOOK METHOD
	void doSomething(BinaryTreeNode node);
}
