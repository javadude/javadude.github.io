package com.javadude.templatemethod;

import java.io.FileWriter;
import java.io.PrintWriter;

public class FileApp {
	public static void main(String[] args) {
		new AutoFileCloser() {
			@Override protected void doWork() throws Throwable {
				FileWriter fw = autoClose(new FileWriter("somefile.txt"));
				PrintWriter pw = autoClose(new PrintWriter(fw));
				pw.println("Hello");
			}};
	}
}
