package com.javadude.templatemethod;

// COMMUNICATION OF INTENT
public abstract class Walker {
	
	// TEMPLATE METHOD: ALGORITHM WITH REPLACEABLE STEPS
	public void inorder(BinaryTreeNode node) {
		if (node.getLeft() != null)
			inorder(node.getLeft());
		doSomething(node);
		if (node.getRight() != null)
			inorder(node.getRight());
	}
	// HOOK METHOD
	protected abstract void doSomething(BinaryTreeNode node);
}
