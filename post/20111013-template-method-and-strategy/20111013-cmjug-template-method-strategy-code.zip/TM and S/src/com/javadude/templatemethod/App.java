package com.javadude.templatemethod;

public class App {
	public static void main(String[] args) {
		BinaryTreeNode root = new BinaryTreeNode(42);
		root.insert(10);
		root.insert(100);
		root.insert(23);
		root.insert(60);
		root.insert(44);
		root.insert(8);
		
//		AverageWalker walker = new AverageWalker();
//		walker.inorder(root);
//		System.out.println(walker.getAverage());
//		SumWalker sumWalker = new SumWalker();
//		sumWalker.inorder(root);
//		System.out.println(sumWalker.getSum());
		
		Walker2 walker2 = new Walker2();
		AverageDoer averageDoer = new AverageDoer();
		walker2.setSomethingDoer(averageDoer);
		walker2.inorder(root);
		System.out.println(averageDoer.getAverage());
	}
}
