package com.javadude.templatemethod;

// COMMUNICATION OF INTENT
public class Walker2 {
	private SomethingDoer somethingDoer;
	public void setSomethingDoer(SomethingDoer somethingDoer) {
		this.somethingDoer = somethingDoer;
	}

	// TEMPLATE METHOD: ALGORITHM WITH REPLACEABLE STEPS
	public void inorder(BinaryTreeNode node) {
		if (node.getLeft() != null)
			inorder(node.getLeft());
		somethingDoer.doSomething(node);
		if (node.getRight() != null)
			inorder(node.getRight());
	}
}
