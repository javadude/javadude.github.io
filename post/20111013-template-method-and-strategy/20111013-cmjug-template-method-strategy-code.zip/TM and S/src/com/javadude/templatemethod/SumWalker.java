package com.javadude.templatemethod;

public class SumWalker extends Walker {
	private int sum = 0;
	@Override
	protected void doSomething(BinaryTreeNode node) {
		sum += node.getData();
	}
	public int getSum() {
		return sum;
	}
}
