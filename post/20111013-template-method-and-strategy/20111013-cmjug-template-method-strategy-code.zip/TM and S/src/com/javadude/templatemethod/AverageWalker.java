package com.javadude.templatemethod;

public class AverageWalker extends Walker {
	private int sum = 0;
	private int count = 0;
	@Override
	protected void doSomething(BinaryTreeNode node) {
		sum += node.getData();
		count++;
	}
	public int getAverage() {
		return sum/count;
	}
}
