package com.javadude.templatemethod;

public class AverageDoer implements SomethingDoer {
	private int sum = 0;
	private int count = 0;
	@Override
	public void doSomething(BinaryTreeNode node) {
		sum += node.getData();
		count++;
	}
	public int getAverage() {
		return sum/count;
	}
}
