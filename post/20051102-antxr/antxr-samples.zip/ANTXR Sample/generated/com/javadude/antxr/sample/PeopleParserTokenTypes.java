// $ANTXR : "people.antxr" -> "PeopleParser.java"$
// GENERATED CODE - DO NOT EDIT!

package com.javadude.antxr.sample;

import java.util.List;
import java.util.ArrayList;

public interface PeopleParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<people>" = 4
	int XML_END_TAG = 5;
	// "<person>" = 6
	// "<first-name>" = 7
	int PCDATA = 8;
	// "<last-name>" = 9
	int OTHER_TAG = 10;
}
