// $ANTXR : "NoteParser1.antxr" -> "NoteParser1.java"$
// GENERATED CODE - DO NOT EDIT!

package com.javadude.antxr.sample;
import java.util.Hashtable;
import java.io.PrintWriter;
import java.io.FileWriter;

public interface NoteParser1TokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<note>" = 4
	int XML_END_TAG = 5;
	// "<to>" = 6
	// "<from>" = 7
	// "<heading>" = 8
	int PCDATA = 9;
	// "<body>" = 10
}
