// $ANTXR : "NoteParser3.antxr" -> "NoteParser3.java"$
// GENERATED CODE - DO NOT EDIT!

package com.javadude.antxr.sample;

public interface NoteParser3TokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<note>" = 4
	int XML_END_TAG = 5;
	// "<to>" = 6
	// "<from>" = 7
	// "<heading>" = 8
	int PCDATA = 9;
	// "<body>" = 10
}
