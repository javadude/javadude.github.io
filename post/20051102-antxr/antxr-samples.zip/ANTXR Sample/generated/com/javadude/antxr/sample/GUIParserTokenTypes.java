// $ANTXR : "GUIParser.antxr" -> "GUIParser.java"$
// GENERATED CODE - DO NOT EDIT!

package com.javadude.antxr.sample;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public interface GUIParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<frame>" = 4
	int XML_END_TAG = 5;
	// "<panel>" = 6
	// "<borderLayout>" = 7
	// "<north>" = 8
	// "<south>" = 9
	// "<east>" = 10
	// "<west>" = 11
	// "<center>" = 12
	// "<flowLayout>" = 13
	// "<gridLayout>" = 14
	// "<button>" = 15
	// "<label>" = 16
	// "<textField>" = 17
	// "<printAction>" = 18
	int PCDATA = 19;
}
