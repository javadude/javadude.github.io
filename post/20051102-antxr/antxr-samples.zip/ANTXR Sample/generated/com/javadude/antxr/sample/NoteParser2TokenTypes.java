// $ANTXR : "NoteParser2.antxr" -> "NoteParser2.java"$
// GENERATED CODE - DO NOT EDIT!

package com.javadude.antxr.sample;

public interface NoteParser2TokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	// "<http://www.w3schools.com:note>" = 4
	int XML_END_TAG = 5;
	// "<http://www.w3schools.com:to>" = 6
	// "<http://www.w3schools.com:from>" = 7
	// "<http://www.w3schools.com:heading>" = 8
	int PCDATA = 9;
	// "<http://www.w3schools.com:body>" = 10
}
