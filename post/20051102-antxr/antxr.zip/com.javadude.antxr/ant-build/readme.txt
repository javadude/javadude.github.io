If you're running in eclipse, build this project as a normal eclipse plugin.
   DO NOT USE THIS ANT BUILD SCRIPT TO BUILD A PLUGIN