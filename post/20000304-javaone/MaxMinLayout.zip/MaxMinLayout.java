package effectivevaj.vce.layouts;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * <p>Effective VisualAge for Java<br>&nbsp;&nbsp;&nbsp;
 *   by Isabelle Mauny and Scott Stanchfield
 *   
 * <p><b>Chapter 11</b>: Layout Management
 * <p><b>Package</b>: effectivevaj.vce.layouts
 * 
 * <p><b>Class</b>: MaxMinLayout
 *   <p>This is a simple layout manager that respects the
 *   maximumSize of the first component and the minimumSize
 *   of the second component. The first component will never
 *   be sized wider than its preferred width, and the second
 *   component will never be size smaller than its preferred
 *   width (unless the container is too small). Thus, when
 *   there is more room than both component's preferred
 *   widths, the "min" component will grow. When there is
 *   less room than their preferred widths, the "max"
 *   component will shrink.
 *
 *   <p><i>NOTE: This layout manager really needs more checks to be
 *         robust enough for production use. It is provided
 *         here only as an example of how to use a custom
 *         layout manager in VisualAge for Java.</i>
 *  
 * <p><b>DISCLAIMER:</b>
 * <p>This Java code sample is provided to you on an 'as-is' basis 
 *    without warranty or condition of any kind, either express or 
 *    implied, including, but not limited to, warranty or condition of 
 *    merchantable quality or fitness for a particular purpose.
 *  
 * <p>This sample code is not part of any standard IBM product and is 
 *    provided to you solely for the purpose of assisting you in the
 *    development of your applications. Neither IBM nor the authors shall 
 *    be liable for any damages arising out of your use of this sample 
 *    code, even if they have been advised of the possibility of 
 *    such damages.
 *   
 *   <p><i>Copyright (c) 2000, IBM Corporation, All Rights Reserved</i>
 */
 
public class MaxMinLayout implements LayoutManager2 
	// implement LayoutManager2 to allow constraints to be passed
{
	// keep track of which component is max, and which is min
	private Component minComp, maxComp;

	// keep track of the horizontal space between components
	private int hgap;


	/** The default MaxMinLayout has a gap of 5 pixels between components */
	public MaxMinLayout() {
		this(5);
	}


	/** Allow the creating class to specify the space between components */
	public MaxMinLayout(int hgap) {
		this.hgap = hgap;
	}


	/** The owning container uses this method to tell us when a component
	 *    has been added, and passes the constraint object to us
	 *  <p>For this version of addLayoutComponent, we'll just ensure it's
	 *    a String, then pass it to the String version of the method
	 */
	public void addLayoutComponent(Component comp, Object constraints) {
		if (constraints instanceof String)
			addLayoutComponent((String)constraints, comp);
	}


	/** The owning container uses this method to tell us when a component
	 *    has been added, and passes the constraint object to us
	 */
	public void addLayoutComponent(String name, Component comp) {
		// note this is oversimplified for this example
		// we should also check if there are only two components
		//   and if the same position was specified for > 1
		if (name != null)
			if (name.startsWith("min")) {
				minComp = comp;
				return;
			}
			else if (name.startsWith("max")) {
				maxComp = comp;
				return;
			}
	}


	/** A helper method (<i>not</i> required by the LayoutManager2 interface)
	 *    that we use to compute the sizes of the components. This method
	 *    is used for computing the preferred, maximum, and minimum sizes,
	 *    by passing in the preferred, maximum, or minimum sizes of each
	 *    component.
	 */
	public Dimension computeSize(Container parent, Dimension d1, Dimension d2) {
		Insets insets = parent.getInsets();
		d1.width += d2.width + hgap + insets.left + insets.right;
		d1.height = Math.max(d1.height, d2.height) + insets.top + insets.bottom;
		// handle overflow...
		if (d1.width < 0)
			d1.width = Integer.MAX_VALUE;
		if (d1.height < 0)
			d1.height = Integer.MAX_VALUE;
		return d1;
	}


	/** Allow the user to see what the spacing value is */
	public int getHgap() {
		return hgap;
	}


	/** Always provide mid-alignment */
	public float getLayoutAlignmentX(Container target) {return 0.5f;}
	public float getLayoutAlignmentY(Container target) {return 0.5f;}


	/** We have no cached calculations, so don't do anything here */
	public void invalidateLayout(Container target) {}


	/** Perform the layout -- in this method we only
	 *    determine *where* the components go and what size
	 *    they should be, then set the sizes of the components
	 *  <p>We do not change the visibility of the components
	 */
	public void layoutContainer(Container parent) {
		// figure out where to put the components
		// we assume only two components exist for simplicity
		// the addLayoutComponent method should really watch for
		//   > 2 components or bad constraints
		//   (we assume exactly one MIN and one MAX component)

		// this should also check for things like both components
		//   being visible and such... again, we're trying to keep
		//   this somewhat simple for the example...

		Insets insets = parent.getInsets();
		Dimension size = parent.getSize();

		int x = insets.left;
		int y = insets.top;
		int h = size.height - insets.top - insets.bottom;
		int w = size.width - insets.left - insets.right;

		Dimension minSize=null, maxSize=null;

		int maxw=0, minw=0;
		
		if (minComp != null) {
			minSize = minComp.getPreferredSize();
			minw = Math.min(minSize.width, w);
		}
		if (maxComp != null) {
			maxSize = maxComp.getPreferredSize();
			maxw = Math.min(w-minw-hgap, maxSize.width);
			if (maxw < 0) 
				maxw = 0;
			minw = Math.max(minw, w-maxw-(maxw==0?0:hgap));
			maxComp.setBounds(x, y, maxw, h);
			if (maxw > 0)
				x += maxw + hgap;
		}

		if (minComp != null)
			minComp.setBounds(x, y, minw, h);
	}


	/**
 	* A simple test that displays a label and a text field
 	*/
	public static void main(String[] args) {
		Frame f = new Frame();
		f.setLayout(new MaxMinLayout(1));
		f.add(new Label("Enter your name in this field"), "max");
		f.add(new TextField(20), "min");
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}});
		f.pack();
		f.setVisible(true);
	}


	/** Tell whomever asks the biggest size we'd prefer */
	public Dimension maximumLayoutSize(Container parent) {
		return computeSize(parent, 
		                   maxComp.getMaximumSize(),
		                   minComp.getMaximumSize());
	}


	/** Tell whomever asks the smallest size we'd prefer */
	public Dimension minimumLayoutSize(Container parent) {
		return computeSize(parent, 
		                   maxComp.getMinimumSize(),
		                   minComp.getMinimumSize());
	}


	/** Tell whomever asks the size we'd prefer <i>if we had an
	 *    infinite amount of screen space</i>
	 */
	public Dimension preferredLayoutSize(Container parent) {
		return computeSize(parent,
		                   maxComp.getPreferredSize(),
		                   minComp.getPreferredSize());
	}


	/** Remove a component from the container. If the component
	 *    was the max or min component, remove it from the instance
	 *    variables that kept track of which is which.
	 */
	public void removeLayoutComponent(Component comp) {
		if (maxComp == comp)
			maxComp = null;
		else if (minComp == comp)
			minComp = null;
	}


	/** Allow the user to set the spacing between components */
	public void setHgap(int hgap) {
		this.hgap = hgap;
	}
}
