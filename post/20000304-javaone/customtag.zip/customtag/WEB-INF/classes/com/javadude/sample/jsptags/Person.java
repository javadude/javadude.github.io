package com.javadude.sample.jsptags;

/**
 * Simple person class for tag library example
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class Person {
	// PROPERTY DATA
	private String _name;
	private String _phone;
	private String _fax;
	
	public Person(String name, String phone, String fax) {
		setName(name);
		setPhone(phone);
		setFax(fax);
	}
	
	// PROPERTY ACCESSORS
	public String getName() {
		return _name;
	}
	public void setName(String name) {
		_name = name;
	}
	public String getPhone() {
		return _phone;
	}
	public void setPhone(String phone) {
		_phone = phone;
	}
	public String getFax() {
		return _fax;
	}
	public void setFax(String fax) {
		_fax = fax;
	}
}
