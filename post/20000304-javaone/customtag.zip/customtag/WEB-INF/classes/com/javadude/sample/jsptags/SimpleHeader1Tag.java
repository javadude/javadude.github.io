package com.javadude.sample.jsptags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

/**
 * A sample header tag.
 * 
 * <p>This class implements the Tag interface, creating a very basic custom
 * tag handler. Note that we could have extended TagSupport instead, which
 * would take care of the parent and page context for us. For this example,
 * I implement Tag directly to make the handling a bit more transparent.
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *          <a href="http://javadude.com">http://javadude.com</a>
 */
public class SimpleHeader1Tag implements Tag {
	// NOTE: we could have extended TagSupport; parent and page context
	//       are defined in there just as we define the here.
	private Tag         _parent;
	private PageContext _pageContext;
	
	/**
	 * Because there is no body content for this tag (that we need to do
	 * anything special for), we can perform its processing when the start
	 * tag is seen.
	 */
	public int doStartTag() throws JspException {
		try {
			// spit out some HTML to the output writer
			getPageContext().getOut().println("<h1>A Sample Header</h1>");
		}
		catch (Exception e) {
			throw new JspException(e);
		}
		
		// tell the JSP that it should include body content, if any
		return EVAL_BODY_INCLUDE;
	}

	/**
	 * After the end tag has been seen, tell the JSP processor to
	 * continue including JSP content after this tag
	 */
	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}

	/**
	 * Nothing special to do when the tag is freed
	 */
	public void release() {}
	
	public void setPageContext(PageContext pageContext) {
		_pageContext = pageContext;
	}
	public void setParent(Tag parent) {
		_parent = parent;
	}
	public Tag getParent() {
		return _parent;
	}
	public PageContext getPageContext() {
		return _pageContext;
	}
}
