package com.javadude.jsp.layout;

import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class LayoutTagBase extends BodyTagSupport {
	// TAG ATTRIBUTES
	private String _hgap="5";
	private String _vgap="5";
	private String _width="100%";
	private String _height="1";
	private String _border="0";
	private String _style="";

	public int getHgapAsInt() {
		int hgap = 0;
		if (getHgap() != null)
			hgap = Integer.parseInt(getHgap());
		return hgap;
	}

	public int getVgapAsInt() {
		int vgap = 0;
		if (getVgap() != null)
			vgap = Integer.parseInt(getVgap());
		return vgap;
	}

	// TAG ATTRIBUTE ACCESSORS
	public String getHgap() {
		return _hgap;
	}
	public void setHgap(String hgap) {
		_hgap = hgap;
	}
	public String getVgap() {
		return _vgap;
	}
	public void setVgap(String vgap) {
		_vgap = vgap;
	}
	public String getWidth() {
		return _width;
	}
	public void setWidth(String width) {
		_width = width;
	}
	public String getHeight() {
		return _height;
	}
	public void setHeight(String height) {
		_height = height;
	}
	public String getBorder() {
		return _border;
	}
	public void setBorder(String border) {
		_border = border;
	}
	public String getStyle() {
		return _style;
	}
	public void setStyle(String style) {
		if (style == null)
			_style = "";
		else
			_style = "class='"+style+"'";
	}
}
