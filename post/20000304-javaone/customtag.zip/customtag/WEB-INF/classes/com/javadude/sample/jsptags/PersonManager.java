package com.javadude.sample.jsptags;

import java.util.ArrayList;
import java.util.List;

/**
 * A dummy person manager for use in the tag library examples.
 * 
 * <p>In real life, the person manager would be responsible for obtaining
 * data from a data store (database, EJB, files...). To keep installation
 * of this example simple, this person manager hardcodes the list of Person
 * objects to return. Note that if you want to use a database, the change is
 * kept completely internal to this class.
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class PersonManager {
	public List list() {
		ArrayList list = new ArrayList();
		list.add(new Person("Scott","111-1111","222-2222"));
		list.add(new Person("Steve","333-3333","444-4444"));
		list.add(new Person("Mike","555-5555","777-7777"));
		list.add(new Person("John","888-8888","999-9999"));
		return list;
	}		
}
