package com.javadude.jsp.layout;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;

/**
 * AWT-like BorderLayout tag for use in JSPs.
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class BorderLayoutTag extends LayoutTagBase {
	// Constants for directional positions
	public static final String NORTH  = "north";
	public static final String SOUTH  = "south";
	public static final String EAST   = "east";
	public static final String WEST   = "west";
	public static final String CENTER = "center";
	
	// Holders of subtag contents and options
	private HashMap _contents;
	private HashMap _contentOptions;
	
	// TAG ATTRIBUTES
	private String  _bgcolor;
	private String  _padding="5";

	/**
	 * Create HTML for layout and its content
	 */
	public int doEndTag() throws JspException {
		try {
			int hgap = getHgapAsInt();
			int vgap = getVgapAsInt();
					
			JspWriter pw = pageContext.getOut();
		
			// start the table for the layout
			pw.println("<table cellspacing='0' cellpadding='"+getPadding()+
			             "' border='"+getBorder()+
			             "' width='"+getWidth()+"' height='"+getHeight()+"'"+
			    		getStyle()+"> <!-- <layout:borderLayout hgap='"+
			    		getHgap()+"' vgap='"+getVgap()+"'> -->");
	
			// grab the content of the nested tags
			String north  = (String)getContents().get(NORTH);
			String south  = (String)getContents().get(SOUTH);
			String east   = (String)getContents().get(EAST);
			String west   = (String)getContents().get(WEST);
			String center = (String)getContents().get(CENTER);
			
			// grab the options for the nested tags (style, bgcolor...)
			String optionsNorth  = (String)getContentOptions().get(NORTH);
			String optionsSouth  = (String)getContentOptions().get(SOUTH);
			String optionsEast   = (String)getContentOptions().get(EAST);
			String optionsWest   = (String)getContentOptions().get(WEST);
			String optionsCenter = (String)getContentOptions().get(CENTER);
	
			// determine how many columns we need based on presense of 
			//   east, west, and center content
			int cols = 0;
			if (east   != null) cols++;
			if (west   != null) cols++;
			if (center != null) cols++;
			
			// add extra columns for hgap between west, center and east
			if (cols >= 3 && hgap > 0)
				cols = 5;
			else if (cols == 2 && hgap > 0)
				cols = 4;
				
			String colSpan = "";
			if (cols > 1) 
				colSpan = " colspan='"+cols+"'";
		
			// add in the north content as the first row
			if (north != null) {
				pw.println("<tr><td"+colSpan+optionsNorth+
				           " width='100%'> <!-- <layout:north> -->");
				pw.println(north);
				pw.println("</td></tr> <!-- </layout:north> -->");
				
				// add vgap row if there are more rows
				if ((cols > 0 || south != null) && vgap > 0) {
					pw.println("<tr><td "+colSpan+" height='"+vgap+
					  "'>&nbsp;</td></tr> <!-- <layout:borderLayout> vgap -->");
				 }
			}
		
			// add in the next row for west, center, and east
			if (cols > 0) {
				pw.println("<tr> <!-- <layout:west,center,east> -->");
			}
		
			// add the west content
			if (west != null) {
				pw.println("<td"+optionsWest+"> <!-- <layout:west> -->");
				pw.println(west);
				pw.println("</td> <!-- </layout:west> -->");
				// add hgap cell if there's content to our right
				if (cols > 3) {
					pw.println("<td width='"+hgap+
					     "'>&nbsp;</td> <!-- <layout:borderLayout> hgap -->");
				}
			}
		
			// add center content
			if (center != null) {
				pw.println("<td"+optionsCenter+
				              " width='100%'> <!-- <layout:center> -->");
				pw.println(center);
				pw.println("</td> <!-- </layout:center> -->");
			}
		
			// add east content
			if (east != null) {
				// add hgap cell if there's content to our left
				if (cols > 4)
					pw.println("<td width='"+hgap+
					       "'>&nbsp;</td> <!-- <layout:borderLayout> hgap -->");
				pw.println("<td"+optionsEast+"> <!-- <layout:east> -->");
				pw.println(east);
				pw.println("</td> <!-- </layout:east> -->");
			}
			
			// end the center row
			if (cols > 0) {
				pw.println("</tr> <!-- </layout:west,center,east> -->");
			}
		
			// add the south content
			if (south != null) {
				// add a vgap row if there's content above us
				if ((cols > 0 || north != null) && vgap > 0) {
					pw.println("<tr><td "+colSpan+" height='"+vgap+
					  "'>&nbsp;</td></tr> <!-- <layout:borderLayout> vgap -->");
				 }
				pw.println("<tr><td "+optionsSouth+"colspan='"+cols+
				                     "' width='100%'> <!-- <layout:south> -->");
				pw.println(south);
				pw.println("</td></tr> <!-- </layout:south> -->");
			}
		
			// end the borderlayout table
			pw.println("</table> <!-- <borderLayout hgap='"+hgap+
			                                     "' vgap='"+vgap+"'> -->");
		}
		catch(IOException e) {
			throw new JspTagException("IO Error: "+e.getMessage());
		}
		return EVAL_PAGE;
	}

	// METHODS FOR COMMUNICATION WITH SUB TAGS
	public void setContent(String position, String content) throws JspException {
		if (getContents().get(position) != null)
			throw new JspException(position + 
			                      " exists more than once in BorderLayout tag");
		getContents().put(position, content);
	}
	public void setContentOptions(String position, String options) {
		getContentOptions().put(position, options);
	}
	
	// INTERNAL ACCESSORS FOR INSTANCE VARIABLES
	protected HashMap getContents() {
		if (_contents == null)
			_contents = new HashMap();
		return _contents;
	}
	protected HashMap getContentOptions() {
		if (_contentOptions == null)
			_contentOptions = new HashMap();
		return _contentOptions;
	}
	
	// TAG ATTRIBUTE ACCESSORS
	public String getBgcolor() {
		return _bgcolor;
	}
	public void setBgcolor(String bgcolor) {
		_bgcolor = bgcolor;
	}
	public String getPadding() {
		return _padding;
	}
	public void setPadding(String padding) {
		_padding = padding;
	}
}
