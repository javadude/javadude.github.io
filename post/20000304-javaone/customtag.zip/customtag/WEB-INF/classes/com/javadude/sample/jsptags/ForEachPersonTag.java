package com.javadude.sample.jsptags;

import java.util.Iterator;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

/**
 * Sample looping tag
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, <a href="http://javadude.com">http://javadude.com</a>
 */
public class ForEachPersonTag extends BodyTagSupport {
	// TAG ATTRIBUTES
	private String        _id;

	// the data manager that retrives Person objects for us
	private PersonManager _personManager;	
	
	// an iterator to use to loop through the results returned by the
	//   person manager
	private Iterator      _people;

	/**
	 * At the start of the tag, ask the person manager for a list of
	 *   Person objects, and determine if it is empty or not
	 */	
	public int doStartTag() throws JspException {
		try {
			// get all person objects
			setPeople(getPersonManager().list().iterator());
		}
		catch (Exception e) {
			throw new JspException(e.toString());
		}

		// If there are any people in the list,
		//   set the current person object and tell the JSP processor
		//   to include the body
		// Note that getId() is used to determine the name of the attribute
		//   to be placed in the page content. This allows the user to define
		//   the variable and reference it later, as though they had entered
		//   something like
		//      for each p in getAllPeople()
		if (getPeople().hasNext()) {
			pageContext.setAttribute(getId(), getPeople().next());
			return EVAL_BODY_INCLUDE;
		}
		// if there are no person objects, tell the JSP processor to
		//   skip the body
		else
			return SKIP_BODY;
	}

	/**
	 * At the end of the loop, we need to check to see if we should
	 *   evaluate the body of the loop again for another Person object.
	 */
	public int doAfterBody() throws JspException {
		// if there are no more person objects,
		//   clear the iterator for GC, and tell the JSP processor to skip
		if (!getPeople().hasNext()) {
			setPeople(null);
			return SKIP_BODY;
		}
		
		// otherwise, set the next Person object as the user-named
		//   attribute in the page context
		else {
			pageContext.setAttribute(getId(), getPeople().next());
			return EVAL_BODY_AGAIN;
		}
	}

	// INTERNAL ACCESSORS
	protected PersonManager getPersonManager() {
		if (_personManager == null)
			_personManager = new PersonManager();
		return _personManager;
	}
	protected Iterator getPeople() {
		return _people;
	}
	protected void setPeople(Iterator people) {
		_people = people;
	}

	// TAG ATTRIBUTE ACCESSORS		
	public String getId() {
		return _id;
	}
	public void setId(String id) {
		_id = id;
	}
}
