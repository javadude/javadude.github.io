package com.javadude.sample.jsptags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

/**
 * A simple header tag handler that accepts an attribute
 * 
 * <p>See SimpleHeader1Tag for basic details on this class
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield, 
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class SimpleHeader2Tag implements Tag {
	private Tag         _parent;
	private PageContext _pageContext;

	// TAG ATTRIBUTES
	// Here we add storage for any tag attributes that are set in the JSP
	//   when the JSP includes 
	//      <namedHeader name="some text"/>
	// the processor will call setName() in this tag handler
	private String      _name;
	
	public int doStartTag() throws JspException {
		try {
			getPageContext().getOut().println("<h1>"+getName()+"'s Home Page</h1>");
		}
		catch (Exception e) {
			throw new JspException(e);
		}
		return EVAL_BODY_INCLUDE;
	}

	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}

	public void release() {}
	public void setPageContext(PageContext pageContext) {
		_pageContext = pageContext;
	}
	public void setParent(Tag parent) {
		_parent = parent;
	}
	public Tag getParent() {
		return _parent;
	}
	public String getName() {
		return _name;
	}
	public void setName(String name) {
		_name = name;
	}
	public PageContext getPageContext() {
		return _pageContext;
	}
}
