package com.javadude.jsp.layout;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.Tag;

/**
 * Basic support for a direction tag (north, south, east, west, center),
 * used in a borderlayout tag.
 * 
 * <p>Use this code at your own risk!  Scott Stanchfield is not
 * responsible for any damage caused directly or indirectly through
 * use of this code.
 * <p><p>
 * <b>SOFTWARE RIGHTS</b>
 * <p>
 * I reserve no legal rights to this code--it is fully in the
 * public domain. An individual or company may do whatever
 * they wish with source code distributed with it, including
 * including the incorporation of it into commerical software.
 *
 * <p>However, this code cannot be sold as a standalone product.
 * <p>
 * I encourage users to develop software with this code. However,
 * I do ask that credit is given to me for developing it
 * By "credit", I mean that if you use these components or
 * incorporate any source code into one of your programs
 * (commercial product, research project, or otherwise) that
 * you acknowledge this fact somewhere in the documentation,
 * research report, etc... If you like these components and have
 * developed a nice tool with the output, please mention that
 * you developed it using these components. In addition, I ask that
 * the headers remain intact in the source code. As long as these
 * guidelines are kept, I expect to continue enhancing this
 * system and expect to make other tools available as they are
 * completed.
 * <p>
 * @author Scott Stanchfield,
 *         <a href="http://javadude.com">http://javadude.com</a>
 */
public class DirectionTag extends BodyTagSupport {
	// TAG ATTRIBUTES
	private String _bgcolor="";   // desired color of this section
	private String _direction=""; // north, south, east, west, center
	private String _style="";     // CSS style used for this section

	public DirectionTag(String direction) {
		setDirection(direction);
	}

	/**
	 * Process the content of the tag when we see its end tag
	 */
	public int doEndTag() throws JspException {
		Tag layout = getParent(); // grab the borderlayout tag
		
		// simple verification to ensure it's borderlayout
		if (layout == null)
			throw new JspException(getDirection() + 
			                       " tag found outside borderLayout tag");
		else if (!(layout instanceof BorderLayoutTag))
			throw new JspException(getDirection() + 
			                    " tag not *directly inside* borderLayout tag");
	
		// if we make it here, it's a border layout
		// pass the content and style to to the borderlayout tag for later
		//   processing
		((BorderLayoutTag)layout).setContent(getDirection(), 
		                                     bodyContent.getString());
		((BorderLayoutTag)layout).setContentOptions(getDirection(), 
		                                            getBgcolor() + getStyle());
		
		// tell the JSP processor to continue processing the page
		return EVAL_PAGE;
	}

	// TAG ATTRIBUTE ACCESSORS
	public String getDirection() {
		return _direction;
	}
	public void setDirection(String direction) {
		_direction = direction;
	}
	public String getBgcolor() {
		return _bgcolor;
	}
	public void setBgcolor(String bgcolor) {
		if (bgcolor == null)
			_bgcolor = "";
		else
			_bgcolor = " bgcolor='" + bgcolor + "'";
	}
	public String getStyle() {
		return _style;
	}
	public void setStyle(String style) {
		_style = style;
	}
}
