package antlr.parseview;

class TokenNode extends IntTreeNode {


	public TokenNode(int tokenNum, int guessing) {
		super(tokenNum, guessing);
	}
}