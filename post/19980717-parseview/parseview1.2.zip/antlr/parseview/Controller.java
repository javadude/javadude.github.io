package antlr.parseview;

import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import antlr.debug.LLkDebuggingParser;
import antlr.debug.ParserController;
import antlr.debug.ParserEventSupport;
import antlr.debug.TraceEvent;
import antlr.debug.ParserTokenEvent;
import antlr.debug.ParserMatchEvent;
import antlr.debug.MessageEvent;
import antlr.debug.SemanticPredicateEvent;
import antlr.debug.SyntacticPredicateEvent;

import java.lang.reflect.Method;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Controller extends JPanel implements ParserController,												  
												  ActionListener {
	protected final static int NONE         = 0;
	protected final static int ANY          = 1;
	protected final static int RULE         = 2;
	protected final static int TOKEN        = 3;
	protected final static int BREAKPOINT   = 4;
	protected final static int FINISH       = 5;
	protected final static int SEMPRED      = 7;
	protected final static int GUESS        = 8;

	private   int nextStopType = ANY;
	private InputBufferWatcher inputWatcher;
	private   JButton     anyButton           = new JButton("Any");
	private   JButton     semPredButton       = new JButton("Parser Sem Pred");
	private   JButton     guessButton         = new JButton("Parser Guess");
	private   JButton     endRuleButton       = new JButton("Parser End Rule");
	private   JButton     continueButton      = new JButton("Continue");
	private   JButton     findButton          = new JButton("Find");
	private   JButton     finishButton        = new JButton("Finish");
	private   JButton     inspectParserButton = new JButton("Inspect");
	private   JLabel      statusLabel         = new JLabel("<status>", SwingConstants.CENTER);
	private   GridLayout  ivjParseViewControllerGridLayout;
	private   JButton     ruleButton          = new JButton("Parser Rule");
	private   JButton     tokenButton         = new JButton("Token");
	private   JButton     vajDebugButton      = new JButton("VAJ Debug");
	private   JButton     exitButton          = new JButton("System.exit()");
	private   LLkDebuggingParser parser;
	private   ParserEventSupport parserEventSupport;
//	private   CharBufferEventSupport charBufferEventSupport;
	private   int ruleDepth = 0;
	private   int stopDepth = -1;
	private   boolean stop = false;
	private   boolean vajDebug = false;
	private   boolean finalContinue = false;
	private   ParserWatcher parserWatcher;
	private   ScannerWatcher scannerWatcher;
	private   JButton findStartButton  = new JButton("Start");
	private   JButton findNextButton   = new JButton("Next");
	private   JButton findCloseButton  = new JButton("Close");
	private   JTextField findTextField = new JTextField();
	private   Dialog findDialog;


	public Controller(LLkDebuggingParser parser) {
		super();
		this.parser = parser;
		JPanel p = new JPanel();
		setLayout(new BorderLayout());
		add(p, BorderLayout.NORTH);
		p.setLayout(new GridLayout(0, 1));
		p.add(ruleButton);
		p.add(endRuleButton);
		p.add(tokenButton);
		p.add(semPredButton);
		p.add(guessButton);

		p.add(finishButton);
		p.add(anyButton);
		p.add(continueButton);
		p.add(findButton);
	
		try {
			Class.forName("com.ibm.uvm.tools.DebugSupport");
			p.add(vajDebugButton);
			p.add(inspectParserButton);
		}
		catch (ClassNotFoundException e) {}	

		p.add(exitButton);
		add(statusLabel, BorderLayout.SOUTH);

		ruleButton.addActionListener(this);
		tokenButton.addActionListener(this);
		finishButton.addActionListener(this);
		continueButton.addActionListener(this);
		vajDebugButton.addActionListener(this);
		inspectParserButton.addActionListener(this);
		anyButton.addActionListener(this);
		semPredButton.addActionListener(this);
		guessButton.addActionListener(this);
		endRuleButton.addActionListener(this);
		findButton.addActionListener(this);
		findStartButton.addActionListener(this);
		findNextButton.addActionListener(this);
		findCloseButton.addActionListener(this);
		exitButton.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ruleButton)
			nextRule();
		else if (e.getSource() == tokenButton)
			nextToken();
		else if (e.getSource() == finishButton)
			nextBreakpoint();
		else if (e.getSource() == continueButton)
			continueNoBP();
		else if (e.getSource() == findButton)
			getFindDialog().setVisible(true);
		else if (e.getSource() == vajDebugButton)
			setVAJDebug(true);
		else if (e.getSource() == inspectParserButton)
			inspectParser();
		else if (e.getSource() == anyButton)
			nextAny();
		else if (e.getSource() == semPredButton)
			nextSemPred();
		else if (e.getSource() == guessButton)
			nextGuess();
		else if (e.getSource() == endRuleButton)
			endRule();
		else if (e.getSource() == findStartButton)
			startFind();
		else if (e.getSource() == findNextButton)
			nextFind();
		else if (e.getSource() == findCloseButton)
			closeFind();
		else if (e.getSource() == exitButton)
			System.exit(0);
		}
	public void checkBreak() {
		if (stop && parser != null)
			synchronized (parser) {
				parserEventSupport.refreshListeners();
				scannerWatcher.refresh();
				inputWatcher.refresh();
				statusLabel.setText("<<< Paused >>>");
				parser.goToSleep();

				// after woken up, check to see if we want to VAJ debug
				if (vajDebug)
					startVAJDebugger();
			}
		stop = false;
	}
	protected void closeFind() {
		getFindDialog().setVisible(false);
	}
	public void continueNoBP( ) {
		nextStopType = NONE;
		continueParse();
	}
	protected void continueParse() {
		if (finalContinue) {
			Component c = this;
			while(! (c instanceof Frame))
				c = c.getParent();
			c.setVisible(false);
			((Frame)c).dispose();
		}
		else
			statusLabel.setText("...Parsing...");
			
		if (parser != null)
			synchronized(parser) {
				parser.wakeUp();
			}	
	}
	public void doneParsing(TraceEvent e) {
		semPredButton.setEnabled(false);
		guessButton.setEnabled(false);
		endRuleButton.setEnabled(false);
		anyButton.setEnabled(false);
		finishButton.setEnabled(false);
		inspectParserButton.setEnabled(false);
		ruleButton.setEnabled(false);
		tokenButton.setEnabled(false);
		vajDebugButton.setEnabled(false);
		stop = true;
		finalContinue = true;
		checkBreak();
	}
	public void endRule( ) {
		stopDepth = ruleDepth;
		nextStopType = NONE;
		continueParse();
	}
	public void enterRule(TraceEvent e) {
		ruleDepth++;
		stop = (nextStopType == RULE || nextStopType == ANY);
	}
	public void exitRule(TraceEvent e) {
		stop = (stopDepth == ruleDepth);
		if (stop) stopDepth = -1;
		ruleDepth--;
	}
	public Dialog getFindDialog() {
		if (findDialog == null) {
			Container c = this;
			while(c.getParent() != null)
				c = c.getParent();
			findDialog = new Dialog((Frame)c, "Find", false);
		
			findDialog.setLayout(new BorderLayout());
			JPanel p1 = new JPanel(new BorderLayout());
			p1.add(new JLabel("Text to find:"), BorderLayout.WEST);
			p1.add(findTextField, BorderLayout.CENTER);
		
			findDialog.add(p1, BorderLayout.NORTH);
		
			JPanel p2 = new JPanel(new FlowLayout());
			p2.add(findStartButton);
			p2.add(findNextButton);
			p2.add(findCloseButton);
		
			findDialog.add(p2, BorderLayout.SOUTH);
			findDialog.pack();
		}	
		
		return findDialog;
	}
	public void inspectParser( ) {
		try {
			Class c = Class.forName("com.ibm.uvm.tools.DebugSupport");
			Method m = c.getMethod("inspect", new Class[] {Object.class});
			m.invoke(null, new Object[] {parser});
//			uvm.tools.DebugSupport.inspect(parser);
		}
		catch (Exception e) {/* message? */}	
	}
	public void nextAny( ) {
		nextStopType = ANY;
		continueParse();
	}
	public void nextBreakpoint( ) {
		nextStopType = BREAKPOINT;
		continueParse();
	}
	protected void nextFind() {
		parserWatcher.nextFind(findTextField.getText());
	}
	public void nextGuess( ) {
		nextStopType = GUESS;
		continueParse();
	}
	public void nextRule ( ) {
		nextStopType = RULE;
		continueParse();
	}
	public void nextSemPred( ) {
		nextStopType = SEMPRED;
		continueParse();
	}
	public void nextToken( ) {
		nextStopType = TOKEN;
		continueParse();
	}
	public void parserConsume(ParserTokenEvent e) {}
	public void parserLA(ParserTokenEvent e) {}
	public void parserMatch(ParserMatchEvent e) {
		stop = (nextStopType == TOKEN || nextStopType == ANY);
	}
	public void parserMatchNot(ParserMatchEvent e) {
		stop = (nextStopType == TOKEN || nextStopType == ANY);
	}
	public void parserMismatch(ParserMatchEvent e) {}
	public void parserMismatchNot(ParserMatchEvent e) {}
	public void refresh() {}
	public void reportError(MessageEvent e) {}
	public void reportWarning(MessageEvent e) {}
	public void semanticPredicateEvaluated(SemanticPredicateEvent e) {
		stop = (nextStopType == SEMPRED || nextStopType == ANY);
	}
	public void setInputBufferWatcher(InputBufferWatcher w) {
		inputWatcher = w;
	}
	public void setParser(LLkDebuggingParser parser) {
		this.parser = parser;
	}
	public void setParserEventSupport(ParserEventSupport p) {
		parserEventSupport = p;
	}
	public void setParserWatcher(ParserWatcher w) {
		parserWatcher = w;
	}
	public void setScannerWatcher(ScannerWatcher scannerWatcher) {
		this.scannerWatcher = scannerWatcher;
	}
	public void setVAJDebug(boolean value) {
		vajDebug = value;
		continueParse();
	}
	protected void startFind() {
		parserWatcher.startFind(findTextField.getText());
	}
	public void startVAJDebugger( ) {
		nextStopType = BREAKPOINT;
		continueParse();
		try {
			setVAJDebug(false);
			Class c = Class.forName("com.ibm.uvm.tools.DebugSupport");
			Method m = c.getMethod("halt", null);
			m.invoke(null,null);
//			uvm.tools.DebugSupport.halt();
		}
		catch (Exception e) {/* message? */}	
	}
	public void syntacticPredicateFailed(SyntacticPredicateEvent e) {
		stop = (nextStopType == GUESS);
	}
	public void syntacticPredicateStarted(SyntacticPredicateEvent e) {
		stop = (nextStopType == GUESS);
	}
	public void syntacticPredicateSucceeded(SyntacticPredicateEvent e) {
		stop = (nextStopType == GUESS);
	}
}