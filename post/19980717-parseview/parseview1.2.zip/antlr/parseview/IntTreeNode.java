package antlr.parseview;

public class IntTreeNode extends GuessingTreeNode {
	private int num;


	public IntTreeNode(int num, int guessing) {
		super(guessing);
		setNum(num);
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}