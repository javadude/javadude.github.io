package antlr.parseview;

class RuleNode extends IntTreeNode {
	private int data;


	public RuleNode(int ruleNum, int guessing, int data) {
		super(ruleNum, guessing);
		setData(data);
	}
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
}