package antlr.parseview;

/** Set up ParseView debugging */
import antlr.CharScanner;
import antlr.CharBuffer;
import antlr.TokenBuffer;
import antlr.TokenStream;
import antlr.InputBuffer;
import antlr.debug.DebuggingCharScanner;
import antlr.debug.DebuggingInputBuffer;
import antlr.debug.LLkDebuggingParser;

import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JSplitPane;
import javax.swing.JPanel;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.BorderLayout;
//import com.magelang.tabsplitter.TabSplitter;

public class ParseView {


	public ParseView(LLkDebuggingParser parser, TokenStream lexer, TokenBuffer buffer) {
		ParserWatcher parserWatcher = new ParserWatcher();
		ScannerWatcher scannerWatcher = new ScannerWatcher(parser);
		Controller controller = new Controller(parser);
	
		parserWatcher.setParser(parser);
		parserWatcher.setParserForTokenNames(parser);
		controller.setParserWatcher(parserWatcher);
	
		parser.addTraceListener(parserWatcher);
		parser.addParserMatchListener(parserWatcher);
		parser.addSemanticPredicateListener(parserWatcher);
		parser.addSyntacticPredicateListener(parserWatcher);
		parser.addParserListener(controller);
	
		JFrame frame = new JFrame("ParseView");
		Container contents = frame.getContentPane();
		JTabbedPane tabbedPane = new JTabbedPane();
		// add other watchers to the tab splitter

		contents.setLayout(new BorderLayout());
		contents.add(tabbedPane, BorderLayout.CENTER);
		contents.add(controller, BorderLayout.EAST);

        if (lexer == null && buffer != null)
            lexer = buffer.getInput();
		if (lexer instanceof DebuggingCharScanner) {
			JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			DebuggingCharScanner scanner = (DebuggingCharScanner)lexer;
			scannerWatcher.setParser(scanner);
			scannerWatcher.setParserForTokenNames(parser);
			controller.setScannerWatcher(scannerWatcher);
	
			scanner.addTraceListener(scannerWatcher);
			scanner.addParserMatchListener(scannerWatcher);
			scanner.addSemanticPredicateListener(scannerWatcher);
			scanner.addSyntacticPredicateListener(scannerWatcher);
//			scanner.addParserListener(controller);
			scanner.addNewLineListener(scannerWatcher);
			splitPane.add(parserWatcher, JSplitPane.LEFT);
			splitPane.add(scannerWatcher, JSplitPane.RIGHT);
			tabbedPane.add("Parse/Scan Tree", splitPane);

			InputBufferWatcher inputWatcher = new InputBufferWatcher();
			DebuggingInputBuffer inputBuffer = (DebuggingInputBuffer)((CharScanner)lexer).getInputBuffer();

			JPanel buffers = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			inputBuffer.addInputBufferListener(inputWatcher);
			buffers.add(inputWatcher);
			contents.add(buffers, BorderLayout.NORTH);
			controller.setInputBufferWatcher(inputWatcher);
			
		}
		else
			tabbedPane.add("Parse Tree", parserWatcher);
			
		frame.pack();
		frame.setVisible(true);
	}
}