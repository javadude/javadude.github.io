package antlr.parseview;

class NotCharacterNode extends StringTreeNode {


	public NotCharacterNode(String text, int guessing) {
		super(text, guessing);
	}
}