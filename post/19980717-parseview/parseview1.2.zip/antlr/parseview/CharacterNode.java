package antlr.parseview;

class CharacterNode extends IntTreeNode {


	public CharacterNode(int tokenNum, int guessing) {
		super(tokenNum, guessing);
	}
}