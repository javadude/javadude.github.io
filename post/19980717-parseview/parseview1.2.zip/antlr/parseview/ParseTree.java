package antlr.parseview;

import antlr.Token;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.DefaultTreeModel;

import java.util.Enumeration;

class ParseTree extends DefaultTreeModel {
	private GuessingTreeNode current;
	private GuessingTreeNode lastNonParent;
	private int n=-1;
	private TreeNode highestChangedNode = null;
	private int highestChangedNodeDepth = 0;


	public ParseTree(GuessingTreeNode root) {
		super(root);
		current = root;
	}
	public void enterRule(int ruleNum, int guessing, int data) {
		GuessingTreeNode node = new RuleNode(ruleNum, guessing, data);
		current.add(node);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
		n=-1;
		current = node;
		highestChangedNodeDepth++;
		lastNonParent = null;
	}
	public void evalSemPred(boolean result, int condition, int guessing) {
		lastNonParent = new SemPredNode(condition, guessing, result);
		current.add(lastNonParent);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
	}
	public void exitRule(int data) {
		((RuleNode)current).setData(data);
		current = (GuessingTreeNode)current.getParent();
		highestChangedNodeDepth--;
		if (highestChangedNodeDepth <= 0) {
			highestChangedNode = current;
			highestChangedNodeDepth = 0;
		}
		lastNonParent = null;
		n = current.getChildCount()-1;
	}
	protected TreePath findFrom(GuessingTreeNode node, String text, ParseTreeCellRenderer r) {
		while(node != null) {
			if (r.textContains(node, text))
				return new TreePath(getPathToRoot(node));
			node = node.getNext(true);
		}	
			
		return null;
	}
	public TreePath findNode(String text, ParseTreeCellRenderer r) {
		return findFrom((GuessingTreeNode)getRoot(), text, r);
	}
	public void forceRefresh() {
		highestChangedNode = (TreeNode)getRoot();
		highestChangedNodeDepth = 0;
	}
	public TreePath getCurrent() {
		Object path[];
		if (lastNonParent != null)
			path = getPathToRoot(lastNonParent);
		else
			path = getPathToRoot(current);
		return new TreePath(path);
	}
	public TreePath getParent() {
		return new TreePath(getPathToRoot(current));
	}
	public void matchCharacter(char c, int guessing) {
		lastNonParent = new CharacterNode(c, guessing);
		current.add(lastNonParent);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
	}
	public void matchNotCharacter(char name, int guessing) {
		lastNonParent = new NotCharacterNode(""+name, guessing);
		current.add(lastNonParent);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
	}
	public void matchNotToken(String name, String text, int guessing) {
		lastNonParent = new NotTokenNodeWithText(name, guessing, text);
		current.add(lastNonParent);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
	}
	public void matchToken(int tokenNum, String text, int guessing) {
		lastNonParent = new TokenNodeWithText(tokenNum, guessing, text);
		current.add(lastNonParent);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
//		nodesWereInserted(current, new int[] {++n});
	}
	public void refresh() {
		if (highestChangedNode != null) {
			nodeStructureChanged(highestChangedNode);
		}
		highestChangedNode = null;
		highestChangedNodeDepth = 0;
//		nodesWereInserted(lastInsertedParent, new int
	}
	public void removeNextToken() {
		GuessingTreeNode root = (GuessingTreeNode)getRoot();
		if (root != null) {
			RuleNode node = (RuleNode)root.getChildAt(0);
			while(node != null) {
				root.remove(node);
				if (node.getData() == Token.SKIP)
					node = (RuleNode)root.getChildAt(0);
				else
					node = null;
			}
			highestChangedNode = root;
			highestChangedNodeDepth = 0;
		}
	}
	public void setData(int data) {
		((RuleNode)current).setData(data);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
	}
	public void synPredFailed(int guessing) {
//		GuessingTreeNode node = new GuessFailedNode(guessing);
//		current.add(node);

		((SynPredNode)current).setDone(true);
		((SynPredNode)current).setSuccess(false);
		lastNonParent = null;
		current = (GuessingTreeNode)current.getParent();
		highestChangedNodeDepth--;
		if (highestChangedNodeDepth <= 0) {
			highestChangedNode = current;
			highestChangedNodeDepth = 0;
		}
		
		n = current.getChildCount()-1;
		nodesChanged(current, new int[] {n});
	}
	public void synPredStarted(int guessing) {
		GuessingTreeNode node = new SynPredNode(guessing);
		current.add(node);
		if (highestChangedNodeDepth == 0)
			highestChangedNode = current;
		nodesWereInserted(current, new int[] {++n});
		n=-1;
		current = node;
		highestChangedNodeDepth++;
		lastNonParent = null;
	}
	public void synPredSucceeded(int guessing) {
//		GuessingTreeNode node = new GuessSucceededNode(guessing);
//		current.add(node);

		((SynPredNode)current).setDone(true);
		((SynPredNode)current).setSuccess(true);
		lastNonParent = null;
		current = (GuessingTreeNode)current.getParent();
		highestChangedNodeDepth--;
		if (highestChangedNodeDepth <= 0) {
			highestChangedNode = current;
			highestChangedNodeDepth = 0;
		}
		n = current.getChildCount()-1;
		nodesChanged(current, new int[] {n});
	}
}