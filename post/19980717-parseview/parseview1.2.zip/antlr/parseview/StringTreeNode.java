package antlr.parseview;

abstract class StringTreeNode extends GuessingTreeNode {
	private String text;


	public StringTreeNode(String text, int guessing) {
		super(guessing);
		this.text = text;
	}
	public String getText() {
		return text;
	}
}