package antlr.parseview;

public class SemPredNode extends IntTreeNode {
	private boolean result;


	public SemPredNode(int condition, int guessing, boolean result) {
		super(condition, guessing);
		setResult(result);
	}
	public boolean getResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
}