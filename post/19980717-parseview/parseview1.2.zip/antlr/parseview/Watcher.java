package antlr.parseview;

import antlr.debug.DebuggingParser;
import antlr.debug.LLkDebuggingParser;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.SystemColor;
import java.awt.Dimension;
import java.awt.Color;
import antlr.debug.ParserMatchListener;
import antlr.debug.ParserMatchEvent;
import antlr.debug.TraceListener;
import antlr.debug.TraceEvent;
import antlr.debug.SemanticPredicateListener;
import antlr.debug.SemanticPredicateEvent;
import antlr.debug.SyntacticPredicateListener;
import antlr.debug.SyntacticPredicateEvent;

import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.SwingUtilities;
import javax.swing.JTree;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public abstract class Watcher extends JPanel implements ParserMatchListener,
													 TraceListener,
													 SemanticPredicateListener,
													 SyntacticPredicateListener {
	protected ParseTree tree;
	private JTree treeView;
	protected JLabel status;
	private String tempStatus;
	private boolean doneParsingFlagged=false;
	private ParseTreeCellRenderer renderer;
	private GuessingTreeNode lastFound;
	protected DebuggingParser parser;


	public Watcher() {
		super();

		setLayout(new BorderLayout());

		IntTreeNode root = new IntTreeNode(-1,-1);
		tree = new ParseTree(root);
		treeView = new JTree(tree);
		treeView.setShowsRootHandles(true);
		treeView.setRootVisible(false);
		treeView.setCellRenderer(renderer = new ParseTreeCellRenderer(this instanceof ScannerWatcher));
		treeView.putClientProperty("JTree.lineStyle", "Angled");
		treeView.setBackground(Color.white);
		JScrollPane p = new JScrollPane(treeView,ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		p.setBackground(Color.white);
		add(p, BorderLayout.CENTER);
		add(status = new JLabel("<status>"), BorderLayout.SOUTH);
	}
	public void doneParsing(TraceEvent e) {
		if (!doneParsingFlagged) {
			doneParsingFlagged = true;
			setStatus("Done parsing!");
			refresh();
		}	
	}
	public void enterRule(TraceEvent e) {
		tree.enterRule(e.getRuleNum(), e.getGuessing(), e.getData());
		setStatus("Entered rule "+parser.getRuleName(e.getRuleNum()));
	}
	public void exitRule(TraceEvent e) {
//		SwingUtilities.invokeLater(new TreeNodeCollapser(treeView, tree.getParent()));
//		treeView.collapsePath(tree.getParent());
		tree.exitRule(e.getData());
		setStatus("Exited rule "+parser.getRuleName(e.getRuleNum()));
	}
	public String getName() {return "ParserWatcher";}
	public Dimension getPreferredSize() {return new Dimension(300,300);}
	public synchronized void goToSleep() {
		try {wait();}
		catch (InterruptedException e) {}	
	}
	public void nextFind(String text) {
		if (lastFound == null)
			startFind(text);
		else {
			TreePath path = tree.findFrom(lastFound.getNext(true), text, renderer);
			if (path != null) {
				lastFound = (GuessingTreeNode)path.getLastPathComponent();
				treeView.setSelectionPath(path);
				treeView.scrollPathToVisible(path);
				setStatus("Found");
			}	
			else
				setStatus("Not Found");
		}	
		status.setText(tempStatus);
	}
	public abstract void parserMatch(ParserMatchEvent e);
	public abstract void parserMatchNot(ParserMatchEvent e);
	public abstract void parserMismatch(ParserMatchEvent e);
	public abstract void parserMismatchNot(ParserMatchEvent e);
	public void refresh() {
		tree.refresh();
		treeView.setSelectionPath(tree.getCurrent());
		treeView.scrollPathToVisible(tree.getCurrent());
//		treeView.repaint();
		status.setText(tempStatus);
//		status.invalidate();
//		status.getParent().validate();
//		SwingUtilities.invokeLater(new TreeNodeSelector(treeView, tree.getCurrent()));
//		SwingUtilities.invokeLater(new LabelSetter(status, tempStatus));
	}
	public void semanticPredicateEvaluated(SemanticPredicateEvent e) {
		tree.evalSemPred(e.getResult(), e.getCondition(), e.getGuessing());
		setStatus("Evaluated SemPred {"+ parser.getSemPredName(e.getCondition())+"}? == "+e.getResult());
	}
	public void setParser(DebuggingParser parser) {
		renderer.setParser(parser);
		this.parser = parser;
	}
	public void setParserForTokenNames(LLkDebuggingParser parser) {
		renderer.setParserForTokenNames(parser);
	}
	public void setStatus(String text) {
		tempStatus = text;
	}
	public void startFind(String text) {
		TreePath path = tree.findNode(text, renderer);
		if (path != null) {
			lastFound = (GuessingTreeNode)path.getLastPathComponent();
			treeView.setSelectionPath(path);
			treeView.scrollPathToVisible(path);
			setStatus("Found");
		}	
		else
			setStatus("Not Found");
		status.setText(tempStatus);
	}
	public void syntacticPredicateFailed(SyntacticPredicateEvent e) {
//		SwingUtilities.invokeLater(new TreeNodeCollapser(treeView, tree.getParent()));
//		treeView.collapsePath(tree.getParent());
		tree.synPredFailed(e.getGuessing());
		setStatus("Syntactic predicate failed");
	}
	public void syntacticPredicateStarted(SyntacticPredicateEvent e) {
		tree.synPredStarted(e.getGuessing());
		setStatus("Syntactic predicate started");
	}
	public void syntacticPredicateSucceeded(SyntacticPredicateEvent e) {
//		SwingUtilities.invokeLater(new TreeNodeCollapser(treeView, tree.getParent()));
//		treeView.collapsePath(tree.getParent());
		tree.synPredSucceeded(e.getGuessing());
		setStatus("Syntactic predicate succeeded");
	}
	public synchronized void wakeUp() {
		notify();
		refresh();
	}
}