package antlr.parseview;

public class TokenNodeWithText extends TokenNode {
	private String tokenText;


	public TokenNodeWithText(int tokenNum, int guessing, String text) {
		super(tokenNum, guessing);
		setText(text);
	}
	public String getText() {
		return tokenText;
	}
	public void setText(String text) {
		tokenText = text;
	}
}