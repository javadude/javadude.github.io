package antlr.parseview;

public class SynPredNode extends GuessingTreeNode {
	private boolean success=false;
	private boolean done=false;


	public SynPredNode(int guessing) {
		super(guessing);
	}
	public boolean isDone() {
		return done;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setDone(boolean value) {
		done=value;
	}
	public void setSuccess(boolean value) {
		success=value;
	}
}