package antlr.parseview;

import antlr.debug.TraceEvent;
import antlr.debug.SyntacticPredicateEvent;
import antlr.debug.SyntacticPredicateAdapter;
import antlr.debug.ParserMatchEvent;
import antlr.debug.ParserTokenAdapter;
import antlr.debug.ParserTokenEvent;
import antlr.debug.NewLineListener;
import antlr.debug.NewLineEvent;
import antlr.debug.LLkDebuggingParser;

public class ScannerWatcher extends Watcher implements NewLineListener {


	public ScannerWatcher(LLkDebuggingParser parser) {
		parser.addParserTokenListener(new ParserTokenAdapter() {
			public void parserConsume(ParserTokenEvent e) {
				// remove the topmost token (and all SKIPs) from this tree
				if (!((LLkDebuggingParser)e.getSource()).isGuessing())
					tree.removeNextToken();
			}});
		parser.addSyntacticPredicateListener(new SyntacticPredicateAdapter() {
			public void syntacticPredicateStarted(SyntacticPredicateEvent e) {
				ScannerWatcher.this.forceRefresh();
			}
			public void syntacticPredicateSucceeded(SyntacticPredicateEvent e) {
				ScannerWatcher.this.forceRefresh();
			}
			public void syntacticPredicateFailed(SyntacticPredicateEvent e) {
				ScannerWatcher.this.forceRefresh();
			}
		});

		// eventually I want this to watch the token buffer as well so we can
		// label which tokens are LA(1) and so on...
	}
	public void forceRefresh() {
		tree.forceRefresh();
		refresh();
	}
	public void hitNewLine(NewLineEvent e) {
		status.setText("<line " + e.getLine() + ">");
	}
	public void parserMatch(ParserMatchEvent e) {
		tree.matchCharacter((char)e.getValue(), e.getGuessing());
		setStatus("Matched character '"+ (char)e.getValue() + "'");
	}
	public void parserMatchNot(ParserMatchEvent e) {
		tree.matchNotCharacter((char)e.getValue(), e.getGuessing());
		setStatus("Matched NOT character '" + (char)e.getValue() + "'");
	}
	public void parserMismatch(ParserMatchEvent e) {
		System.err.println("DEBUGGER: Mismatched character " + e);
		setStatus("Mismatched character '" + (char)e.getValue() + "'");
	}
	public void parserMismatchNot(ParserMatchEvent e) {
		System.err.println("DEBUGGER: Mismatched NOT character " + e);
		setStatus("Mismatched NOT character '" + (char)e.getValue() + "'");
	}
}