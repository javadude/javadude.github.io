package antlr.parseview;

import antlr.debug.LLkDebuggingParser;
import antlr.debug.ParserMatchEvent;

public class ParserWatcher extends Watcher {


	public void parserMatch(ParserMatchEvent e) {
		tree.matchToken(e.getValue(), e.getText(), e.getGuessing());
		setStatus("Matched token "+((LLkDebuggingParser)parser).getTokenName(e.getValue()));
	}
	public void parserMatchNot(ParserMatchEvent e) {
		tree.matchNotToken(Integer.toString(e.getValue()), e.getText(), e.getGuessing());
		setStatus("Matched NOT token "+((LLkDebuggingParser)parser).getTokenName(e.getValue()));
	}
	public void parserMismatch(ParserMatchEvent e) {
		System.err.println("DEBUGGER: Mismatched token " + e);
		setStatus("Mismatched token " + ((LLkDebuggingParser)parser).getTokenName(e.getValue()));
	}
	public void parserMismatchNot(ParserMatchEvent e) {
		System.err.println("DEBUGGER: Mismatched NOT token " + e);
		setStatus("Mismatched NOT token "+((LLkDebuggingParser)parser).getTokenName(e.getValue()));
	}
}