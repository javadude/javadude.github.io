package antlr.parseview;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import antlr.debug.InputBufferListener;
import antlr.debug.InputBufferEvent;
import antlr.debug.TraceEvent;
import antlr.InputBuffer;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentAdapter;

public class InputBufferWatcher extends JPanel implements InputBufferListener {
	private JLabel markedDisplay = new JLabel("..........",SwingConstants.RIGHT);
	private JLabel laDisplay = new JLabel("..........",SwingConstants.LEFT);
	private JLabel consumedDisplay = new JLabel("..........",SwingConstants.LEFT);
	private int lastLA = -1;
	private Font f;
	private int numChars = 200;
	private String markedString = "";
	private String laString = "";
	private String consumedString = "";


	public InputBufferWatcher() {
		f = Font.getFont("Monospaced");

		setLayout(new BorderLayout());
		markedDisplay.setFont(f);
		markedDisplay.setOpaque(true);
		consumedDisplay.setFont(f);
		consumedDisplay.setOpaque(true);
		consumedDisplay.setForeground(Color.gray);
		laDisplay.setFont(f);
		laDisplay.setForeground(Color.green);
		laDisplay.setOpaque(true);
		markedDisplay.setForeground(Color.blue);
		add("West",consumedDisplay);
		add("Center",markedDisplay);
		add("East",laDisplay);
	}
/**
 * doneParsing method comment.
 */
public void doneParsing(TraceEvent e) {
	System.out.println(e);
}
	/** Given a character value, return a string representing the character
	 * that can be embedded inside a string literal or character literal
	 * This works for Java/C/C++ code-generation and languages with compatible
	 * special-character-escapment.
	 * Code-generators for languages should override this method.
	 * @param c   The character of interest.
	 * @param forCharLiteral  true to escape for char literal, false for string literal
	 */
	public String escapeChar(int c) {
		switch (c) {
//		case GrammarAnalyzer.EPSILON_TYPE : return "<end-of-token>";
		case '\n' : return "\\n";
		case '\t' : return "\\t";
		case '\r' : return "\\r";
		default :
			if ( c<' '||c>126 ) {
				if (c > 255) {
					return "\\u" + Integer.toString(c,16);
				}
				else {
					return "\\" + Integer.toString(c,8);
				}
			}
			else {
				return String.valueOf((char)c);
			}
		}
	}
	/** Converts a String into a representation that can be use as a literal
	 * when surrounded by double-quotes.
	 * @param s The String to be changed into a literal
	 */
	public String escapeString(String s)
	{
		String retval = new String();
		for (int i = 0; i < s.length(); i++)
			retval += escapeChar(s.charAt(i));
		return retval;
	}
	public void inputBufferConsume(InputBufferEvent e) {
		if (!((InputBuffer)e.getSource()).isMarked()) {
//			String consumedChars = consumedDisplay.getText();
			String s = escapeChar(e.getChar());
			int len = s.length();
			if (consumedString.length() > numChars - len)
				consumedString = consumedString.substring(len);
			consumedString += s;
//			consumedDisplay.setText(consumedChars+s);
//			consumedDisplay.invalidate();
		}
		setDisplays(e);
		lastLA = -1;
	}
	public void inputBufferLA(InputBufferEvent e) {
		if (e.getLookaheadAmount() > lastLA) {
			lastLA = e.getLookaheadAmount();
			setDisplays(e);
		}
	}
	public void inputBufferMark(InputBufferEvent e) {
	}
	public void inputBufferRewind(InputBufferEvent e) {
		setDisplays(e);
		lastLA = -1;
	}
	public void refresh() {
		consumedDisplay.setText(consumedString);
		laDisplay.setText(laString);
		markedDisplay.setText(markedString);
		invalidate();
		getParent().validate();
	}
	private void setDisplays(InputBufferEvent e) {
//		markedDisplay.setText(escapeString(((InputBuffer)e.getSource()).getMarkedChars()));
//		laDisplay.setText(escapeString(((InputBuffer)e.getSource()).getLAChars()));
		markedString = escapeString(((InputBuffer)e.getSource()).getMarkedChars());
		laString     = escapeString(((InputBuffer)e.getSource()).getLAChars());
//		markedDisplay.invalidate();
//		laDisplay.invalidate();
	}
}