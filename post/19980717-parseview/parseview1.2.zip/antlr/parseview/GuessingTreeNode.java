package antlr.parseview;

import java.util.Vector;
import java.util.Enumeration;
import javax.swing.tree.TreeNode;

public class GuessingTreeNode implements TreeNode {
	private GuessingTreeNode parent;
	private Vector children;
	private int guessing;


	public GuessingTreeNode(int guessing) {
		setGuessing(guessing);
	}
	public void add(GuessingTreeNode node) {
		if (children == null)
			children = new Vector();
		children.addElement(node);
		node.setParent(this);
	}
	public Enumeration children() {
		return (children != null)?children.elements():null;
	}
	public boolean getAllowsChildren() {
		return true;
	}
	public TreeNode getChildAt(int n) {
		return (children!=null)?(TreeNode)children.elementAt(n):null;
	}
	public int getChildCount() {
		return (children!=null)?children.size():0;
	}
	protected int getChildNum() {
		// find what kid number of the parent we are...
		if (getParent() != null) {
			Enumeration e = ((GuessingTreeNode)getParent()).children();
			for(int i=0; e.hasMoreElements(); i++)
				if (e.nextElement() == this)
					return i;
		}	

		return -1;
	}
	public int getGuessing() {
		return guessing;
	}
	public int getIndex(TreeNode node) {
		Enumeration e = children();
		for(int i=0; e.hasMoreElements(); i++)
			if (e.nextElement() == node)
				return i;
		return -1;
	}
	protected GuessingTreeNode getNext(boolean childOk) {
		// if we have any kids, the first kid is next
		if (childOk && getChildCount() > 0)
			return (GuessingTreeNode)getChildAt(0);
		
		// otherwise, if we have a next sibling, return it...
		
		// find what kid number of the parent we are...
		int i = getChildNum();
		
		if (i > -1 && i < getParent().getChildCount()-1)
			return (GuessingTreeNode)getParent().getChildAt(i+1);

		// otherwise, walk up to parents until they have a sibling			
		if (getParent() != null)
			return ((GuessingTreeNode)getParent()).getNext(false);
			
		return null;
	}
	public TreeNode getParent() {
		return parent;
	}
	public boolean isLeaf() {
		return (getChildCount() == 0);
	}
	public void remove(GuessingTreeNode node) {
		children.removeElement(node);
		node.setParent(null);
	}
	public void setGuessing(int guessing) {
		this.guessing = guessing;
	}
	protected void setParent(GuessingTreeNode node) {
		parent = node;
	}
}