package antlr.parseview;

class NotTokenNode extends StringTreeNode {


	public NotTokenNode(String text, int guessing) {
		super(text, guessing);
	}
}