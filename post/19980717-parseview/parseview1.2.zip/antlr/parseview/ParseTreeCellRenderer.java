package antlr.parseview;

import antlr.Token;

import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.border.Border;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.BorderFactory;
import javax.swing.UIManager;
import java.awt.Component;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Graphics;
import java.awt.Dimension;
import antlr.debug.DebuggingParser;
import antlr.debug.LLkDebuggingParser;
import antlr.debug.DebuggingCharScanner;

public class ParseTreeCellRenderer extends JLabel implements TreeCellRenderer {
	private DebuggingParser parser;
	private LLkDebuggingParser parserForTokenNames;
	private static Border empty  = new EmptyBorder(4,4,4,4);
	private static Border raised = new CompoundBorder(BorderFactory.createRaisedBevelBorder(), new EmptyBorder(2,2,2,2));
	private static Border focus  = UIManager.getBorder("List.focusCellHighlightBorder");
	private static Border raisedFocus = new CompoundBorder(new CompoundBorder(BorderFactory.createRaisedBevelBorder(), new EmptyBorder(1,1,1,1)), focus);
	private boolean forScanner;


	public ParseTreeCellRenderer(boolean forScanner) {
		super();
		this.forScanner = forScanner;
//		setBackground(SystemColor.control);
//		setBackground(javax.swing.plaf.metal.MetalLookAndFeel.getSystemTextColor());
	}
	public String getNodeText(Object value) {
		if (value instanceof IntTreeNode) {
			String text;
			int num = ((IntTreeNode)value).getNum();
			if ((parser != null) && (num != -1))
				if ((value instanceof CharacterNode) ||
			         (value instanceof NotCharacterNode))
					text = "'" + (char)num + "'";
				else if (value instanceof TokenNode) {
					text = parserForTokenNames.getTokenName(num);
					if ((!text.substring(0,1).equals("\"")) &&
						(value instanceof TokenNodeWithText))
						text = "\"" + ((TokenNodeWithText)value).getText() + "\"  [" + text + "]";
				}
				else if (value instanceof RuleNode) {
					if (forScanner) {
						int type = ((RuleNode)value).getData();
						if (type == Token.SKIP) {
							setForeground(Color.gray);
							text = "Token.SKIP  [rule " + parser.getRuleName(num)  + "]";							
						}
						else
							text = parserForTokenNames.getTokenName(((RuleNode)value).getData()) + "  [rule " + parser.getRuleName(num)  + "]";
						if (parserForTokenNames.isGuessing()) {
							setOpaque(true);
							setBackground(Color.yellow);
						}
					}
					else
						text = parser.getRuleName(num);
				}
				else if (value instanceof SemPredNode)
					text = "SemPred {"+parser.getSemPredName(num) + "} "+ ((SemPredNode)value).getResult();
				else
					text = value.toString();
			else
				text = value.toString();
			return text;
		}
		else if (value instanceof SynPredNode) {
			SynPredNode n = (SynPredNode)value;
			return ("Guess "+(n.isDone()?(n.isSuccess()?"succeeded":"failed"):"in progress..."));
		}
//		else if (value instanceof GuessFailedNode)
//			return "Guess failed here";
//		else if (value instanceof GuessSucceededNode)
//			return "Guess succeeded here";
		else
			return value.toString();	
	}
	public Component getTreeCellRendererComponent(JTree tree,
	                                              Object value,
	                                              boolean selected,
	                                              boolean expended,
	                                              boolean leaf,
	                                              int row,
	                                              boolean hasFocus) {
	                                              
		boolean isGuessing = ((GuessingTreeNode)value).getGuessing() > 0;;
		boolean isToken = (value instanceof TokenNode);

		setBorder(selected?(tree.hasFocus()?raisedFocus:raised):empty);
			
		setOpaque(selected || isGuessing);
		if (isGuessing)
			setBackground(Color.yellow);
		else
			setBackground(SystemColor.control);
		
		if (value instanceof CharacterNode)	
			setForeground(Color.red);
		else if (value instanceof TokenNode)	
			setForeground(Color.red);
//			setForeground(selected?Color.red.darker():Color.red);
		else if (value instanceof RuleNode)
			setForeground(Color.black);
//			setForeground(selected?Color.blue:Color.black);
		else if (value instanceof SemPredNode)
			setForeground(((SemPredNode)value).getResult()?Color.green:Color.red);
		else if (value instanceof SynPredNode) {
			SynPredNode n = (SynPredNode)value;
			setForeground(n.isDone()?(n.isSuccess()?Color.green:Color.red):Color.blue);
		}
		else
			setForeground(Color.black);

		setText(getNodeText(value));

		return this;
	}
	public void setParser(DebuggingParser parser) {
		this.parser = parser;
	}
	public void setParserForTokenNames(LLkDebuggingParser parserForTokenNames) {
		this.parserForTokenNames = parserForTokenNames;
	}
	public boolean textContains(Object value, String text) {
		return (getNodeText(value).indexOf(text) > -1);
	}
}