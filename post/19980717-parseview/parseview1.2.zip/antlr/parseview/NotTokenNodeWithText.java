package antlr.parseview;

public class NotTokenNodeWithText extends NotTokenNode {
		private String tokenText;



	public NotTokenNodeWithText(String text, int guessing, String text2) {
		super(text, guessing);
		setTokenText(text2);
	}
	public String getTokenText() {
		return tokenText;
	}
	public void setTokenText(String text) {
		this.tokenText = text;
	}
}