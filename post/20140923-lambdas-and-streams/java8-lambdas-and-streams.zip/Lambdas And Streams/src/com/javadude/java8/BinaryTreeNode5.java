package com.javadude.java8;

import java.util.function.Consumer;
import java.util.function.Predicate;


public final class BinaryTreeNode5<T extends Comparable<T>> {
	private final T data;
	private BinaryTreeNode5<T> left;
	private BinaryTreeNode5<T> right;
	public BinaryTreeNode5(T data) {
		this.data = data;
	}
	public final void add(T data) {
		if (data.compareTo(this.data) < 0) {
			if (left == null)
				left = new BinaryTreeNode5<T>(data);
			else
				left.add(data);
		} else {
			if (right == null)
				right = new BinaryTreeNode5<T>(data);
			else
				right.add(data);
		}
	}
	public T getData() {
		return data;
	}
	public BinaryTreeNode5<T> getLeft() {
		return left;
	}
	public BinaryTreeNode5<T> getRight() {
		return right;
	}
	public void inorder(Predicate<T> predicate, Consumer<T> consumer) {
		if (left != null)
			left.inorder(predicate, consumer);
		
		// do something
		if (predicate.test(data))
			consumer.accept(data);
		
		if (right != null)
			right.inorder(predicate, consumer);
	}
	@Override
	public String toString() {
		return "BinaryTreeNode [data=" + data + "]";
	}
}
