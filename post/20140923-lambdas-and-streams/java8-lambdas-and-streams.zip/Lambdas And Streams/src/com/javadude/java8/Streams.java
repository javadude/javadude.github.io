package com.javadude.java8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.javadude.java8.Person3.Sex;

public class Streams {

	public static void main(String[] args) {
		List<Person> people = new ArrayList<Person>();
		Person scott = new Person("Scott", 47);
		Person steve = new Person("Steve", 46);
		Person claire = new Person("Claire", 17);
		Person kai = new Person("Kai", 7);
		people.add(scott);
		people.add(steve);
		people.add(claire);
		people.add(kai);
		
		people.stream().limit(2).forEach(System.out::println);
		System.out.println("========");
		people.stream().filter(p -> p.getAge() < 40).forEach(System.out::println);
		
		Stream.of(scott, steve, claire).forEach(p -> System.out.println(p.getName()));
		
		if (people.stream().anyMatch(p->p.getAge()<40))
			System.out.println("someone is less than 40");
		System.out.println(people.stream().filter(p -> p.getAge() < 40).count());

		List<Person2> people2 = new ArrayList<Person2>();
		Person2 oliver = new Person2("Oliver", 70, null);
		Person2 scott2 = new Person2("Scott", 47, oliver);
		Person2 steve2 = new Person2("Steve", 46, oliver);
		Person2 claire2 = new Person2("Claire", 17, scott2);
		Person2 kai2 = new Person2("Kai", 7, steve2);
		people2.add(oliver);
		people2.add(scott2);
		people2.add(steve2);
		people2.add(claire2);
		people2.add(kai2);

		int[] sum = {0};
		people2.stream().filter(p->p.getFather() != null).forEach(p->System.out.println(p.getName() + " is the child of " + p.getFather().getName()));
		Consumer<Person2> printIt = p->System.out.println(p);
		Consumer<Person2> printItAgain = p->System.out.println(p);
		people2.stream().map(p->p.getFather()).distinct().forEach(printIt.andThen(printItAgain));
		people2.stream().map(p->p.getAge()).forEach(age->sum[0]+=age);

		people2.stream().sorted().forEach(System.out::println);
		
		System.out.println(sum[0]);
		System.out.println(people2.stream().mapToInt(p->p.getAge()).sum());
		System.out.println(people2.stream().mapToInt(p->p.getAge()).average());
		System.out.println(people2.stream().mapToInt(p->p.getAge()).max());
		System.out.println(people2.stream().mapToInt(p->p.getAge()).min());
		IntSummaryStatistics summaryStatistics = people2.stream().mapToInt(p->p.getAge()).summaryStatistics();
		System.out.println(people2.stream().mapToInt(p->p.getAge()).reduce((acc,item)->acc+item));
		System.out.println(people2.stream().map(Person2::getName).reduce((acc,item)->acc + ", " + item));
		
		Map<String, Optional<String>> nicknames = new HashMap<>();
		nicknames.put("Scott", Optional.of("JavaDude"));
		nicknames.put("Steve", Optional.of("Thunderbean"));
		nicknames.put("Claire", Optional.empty());
		
		Optional<String> claireNickname = nicknames.get("Claire");
		Optional<String> kaiNickname = nicknames.get("Kai");
		
		if (claireNickname.isPresent())
			System.out.println(claireNickname.get());
		if (kaiNickname == null)
			System.out.println("not found");
		
		for(Map.Entry<String, Optional<String>> entry : nicknames.entrySet()) {
			entry.getValue().ifPresent(System.out::println);
			System.out.println(entry.getKey() + ": " + entry.getValue().orElse("no nickname"));
			entry.getValue().map(s->s+" foo").ifPresent(System.out::println);
//			System.out.println(entry.getKey() + ": " + entry.getValue().orElseThrow(() -> new RuntimeException("GAG!")));
		}
		
		nicknames.values().stream().filter(Optional::isPresent).map(Optional::get).forEach(System.out::println);
		
//		long start = System.currentTimeMillis();
//		people2.stream().mapToInt(p->{sleep(); return p.getAge();}).average().ifPresent(System.out::println);;
//		long end = System.currentTimeMillis();
//		System.out.println("sequential: " + (end-start) + "ms");
//		start = System.currentTimeMillis();
//		people2.parallelStream().mapToInt(p->{sleep(); return p.getAge();}).average().ifPresent(System.out::println);;
//		end = System.currentTimeMillis();
//		System.out.println("parallel: " + (end-start) + "ms");
		
		System.out.println(people2.parallelStream().unordered().map(p->{sleep(); return p.getName();}).reduce((acc,item)->acc + ", " + item));
		
		List<Person2> list = people2.stream().filter(p->p.getAge()<40).collect(Collectors.toList());
		Map<String, Integer> collect = people2.stream().filter(p->p.getAge()<40).collect(Collectors.toMap(Person2::getName, Person2::getAge));
		Map<String, Person2> personByName = people2.stream().filter(p->p.getAge()<40).collect(Collectors.toMap(Person2::getName, p->p));
		
		List<Person3> people3 = new ArrayList<Person3>();
		Person3 oliver3 = new Person3("Oliver", 70, null, Sex.Male);
		Person3 scott3 = new Person3("Scott", 47, oliver3, Sex.Male);
		Person3 steve3 = new Person3("Steve", 46, oliver3, Sex.Male);
		Person3 claire3 = new Person3("Claire", 17, scott3, Sex.Female);
		Person3 kai3 = new Person3("Kai", 7, steve3, Sex.Male);
		people3.add(oliver3);
		people3.add(scott3);
		people3.add(steve3);
		people3.add(claire3);
		people3.add(kai3);
		
		Map<Sex, List<Person3>> collect2 = people3.stream().collect(Collectors.groupingBy(Person3::getSex));
		
		
//		int[] num = {0};
//		Stream.generate(() -> new Person("Person " + num[0]++, 42))
//									.limit(20)
//									.forEach(System.out::println);
	}
	
	private static Random random = new Random();
	private static void sleep() {
		try {
			Thread.sleep(random.nextInt(500));
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

}
