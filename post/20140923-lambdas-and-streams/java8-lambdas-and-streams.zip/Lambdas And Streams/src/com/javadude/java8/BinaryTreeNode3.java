package com.javadude.java8;


public final class BinaryTreeNode3<T extends Comparable<T>> {
	private final T data;
	private BinaryTreeNode3<T> left;
	private BinaryTreeNode3<T> right;
	public BinaryTreeNode3(T data) {
		this.data = data;
	}
	public final void add(T data) {
		if (data.compareTo(this.data) < 0) {
			if (left == null)
				left = new BinaryTreeNode3<T>(data);
			else
				left.add(data);
		} else {
			if (right == null)
				right = new BinaryTreeNode3<T>(data);
			else
				right.add(data);
		}
	}
	public T getData() {
		return data;
	}
	public BinaryTreeNode3<T> getLeft() {
		return left;
	}
	public BinaryTreeNode3<T> getRight() {
		return right;
	}
	public void inorder(NodeHandler<T> nodeHandler) {
		if (left != null)
			left.inorder(nodeHandler);
		
		// do something
		nodeHandler.handle(data);
		
		if (right != null)
			right.inorder(nodeHandler);
	}
	@Override
	public String toString() {
		return "BinaryTreeNode [data=" + data + "]";
	}
}
