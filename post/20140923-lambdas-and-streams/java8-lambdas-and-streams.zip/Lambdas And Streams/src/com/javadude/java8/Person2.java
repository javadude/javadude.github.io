package com.javadude.java8;

public class Person2 implements Comparable<Person2> {
	private String name;
	private int age;
	private Person2 father;
	
	public Person2 getFather() {
		return father;
	}
	public void setFather(Person2 father) {
		this.father = father;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public Person2(String name, int age, Person2 father) {
		this.name = name;
		this.age = age;
		this.father = father;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	@Override
	public int compareTo(Person2 o) {
		return name.compareTo(o.getName());
	}
}
