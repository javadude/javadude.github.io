package com.javadude.java8;


public class BinaryTreeNode<T extends Comparable<T>> {
	private final T data;
	private BinaryTreeNode<T> left;
	private BinaryTreeNode<T> right;
	public BinaryTreeNode(T data) {
		this.data = data;
	}
	public final void add(T data) {
		if (data.compareTo(this.data) < 0) {
			if (left == null)
				left = new BinaryTreeNode<T>(data);
			else
				left.add(data);
		} else {
			if (right == null)
				right = new BinaryTreeNode<T>(data);
			else
				right.add(data);
		}
	}
	public T getData() {
		return data;
	}
	public BinaryTreeNode<T> getLeft() {
		return left;
	}
	public BinaryTreeNode<T> getRight() {
		return right;
	}
	private void process() {
		System.out.println(data);
	}
	public void inorder() {
		if (left != null)
			left.inorder();
		
		// do something
		process();
		
		if (right != null)
			right.inorder();
	}
	@Override
	public String toString() {
		return "BinaryTreeNode [data=" + data + "]";
	}
}
