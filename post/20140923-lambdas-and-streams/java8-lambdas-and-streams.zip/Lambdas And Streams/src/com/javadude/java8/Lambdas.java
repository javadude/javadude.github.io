package com.javadude.java8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

@SuppressWarnings("serial")
public class Lambdas implements ActionListener {
//	private class InternalListener implements ActionListener {
//		public void actionPerformed(ActionEvent e) {
//			System.out.println("Internal: button pressed");
//		}
//	}	
	
	
	public void go() {
		new JFrame() {{
			add(new JButton("Press Me!") {{
//				addActionListener(Lambdas.this);
//				addActionListener(new PressMeListener());
//				addActionListener(new InternalListener());
//				addActionListener(new ActionListener() {
//					@Override public void actionPerformed(ActionEvent e) {
//						System.out.println("Anonymous: button pressed");
//					}});
//				addActionListener((e) -> {System.out.println("Lambda1: button pressed");});
//				addActionListener(e -> {System.out.println("Lambda2: button pressed");});
//				addActionListener(e -> System.out.println("Lambda3: button pressed"));
//				addActionListener(e -> System.out.println(e));
				addActionListener(System.out::println);
			}});
			pack();
			setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			setVisible(true);
		}};
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("Lambas: button pressed");
	}
	public static void main(String[] args) {
		new Lambdas().go();
	}
}
