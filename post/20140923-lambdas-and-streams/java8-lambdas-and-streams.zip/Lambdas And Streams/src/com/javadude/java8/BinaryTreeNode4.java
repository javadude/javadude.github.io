package com.javadude.java8;

import java.util.function.Consumer;


public final class BinaryTreeNode4<T extends Comparable<T>> {
	private final T data;
	private BinaryTreeNode4<T> left;
	private BinaryTreeNode4<T> right;
	public BinaryTreeNode4(T data) {
		this.data = data;
	}
	public final void add(T data) {
		if (data.compareTo(this.data) < 0) {
			if (left == null)
				left = new BinaryTreeNode4<T>(data);
			else
				left.add(data);
		} else {
			if (right == null)
				right = new BinaryTreeNode4<T>(data);
			else
				right.add(data);
		}
	}
	public T getData() {
		return data;
	}
	public BinaryTreeNode4<T> getLeft() {
		return left;
	}
	public BinaryTreeNode4<T> getRight() {
		return right;
	}
	public void inorder(Consumer<T> consumer) {
		if (left != null)
			left.inorder(consumer);
		
		// do something
		consumer.accept(data);
		
		if (right != null)
			right.inorder(consumer);
	}
	@Override
	public String toString() {
		return "BinaryTreeNode [data=" + data + "]";
	}
}
