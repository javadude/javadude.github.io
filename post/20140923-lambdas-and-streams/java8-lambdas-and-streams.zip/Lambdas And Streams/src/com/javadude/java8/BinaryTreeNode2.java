package com.javadude.java8;


public abstract class BinaryTreeNode2<T extends Comparable<T>> {
	private final T data;
	private BinaryTreeNode2<T> left;
	private BinaryTreeNode2<T> right;
	public BinaryTreeNode2(T data) {
		this.data = data;
	}
	public final void add(T data) {
		if (data.compareTo(this.data) < 0) {
			if (left == null)
				left = create(data);
			else
				left.add(data);
		} else {
			if (right == null)
				right = create(data);
			else
				right.add(data);
		}
	}
	protected abstract BinaryTreeNode2<T> create(T data);
	public T getData() {
		return data;
	}
	public BinaryTreeNode2<T> getLeft() {
		return left;
	}
	public BinaryTreeNode2<T> getRight() {
		return right;
	}
	protected abstract void process();
	public void inorder() {
		if (left != null)
			left.inorder();
		
		// do something
		process();
		
		if (right != null)
			right.inorder();
	}
	@Override
	public String toString() {
		return "BinaryTreeNode [data=" + data + "]";
	}
}
