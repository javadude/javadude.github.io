package com.javadude.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sorting {
	
	public static void main(String[] args) {
			List<Person> people = new ArrayList<Person>();
			people.add(new Person("Scott", 47));
			people.add(new Person("Steve", 46));
			people.add(new Person("Claire", 17));
			people.add(new Person("Kai", 7));
			
			people.stream();
			
//			Collections.sort(people, new Comparator<Person>() {
//				@Override public int compare(Person o1, Person o2) {
//					return o1.getName().compareTo(o2.getName());
//				}});
//			Collections.sort(people, (o1, o2) -> o1.getName().compareTo(o2.getName()));
			Collections.sort(people, (o1, o2) -> o1.getAge() - o2.getAge());
			for (Person person : people) {
				System.out.println(person);
			}
	}

}
