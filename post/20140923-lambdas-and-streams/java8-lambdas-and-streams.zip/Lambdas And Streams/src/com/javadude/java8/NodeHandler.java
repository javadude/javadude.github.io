package com.javadude.java8;

@FunctionalInterface
public interface NodeHandler<T extends Comparable<T>> {
	void handle(T data);
}
