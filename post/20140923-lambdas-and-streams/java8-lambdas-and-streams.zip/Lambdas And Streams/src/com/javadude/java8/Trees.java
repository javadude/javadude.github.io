package com.javadude.java8;

import java.util.function.Function;
import java.util.function.Predicate;

public class Trees {

	public static void main(String[] args) {
		BinaryTreeNode<Person> root = new BinaryTreeNode<Person>(new Person("Scott", 47));
		root.add(new Person("Steve", 46));
		root.add(new Person("Claire", 17));
		root.add(new Person("Kai", 7));
		
		root.inorder();

		System.out.println("--------------------------------");
		PrintNode<Person> root2 = new PrintNode<Person>(new Person("Scott", 47));
		root2.add(new Person("Steve", 46));
		root2.add(new Person("Claire", 17));
		root2.add(new Person("Kai", 7));
		
		root2.inorder();

		System.out.println("--------------------------------");
		BinaryTreeNode3<Person> root3 = new BinaryTreeNode3<Person>(new Person("Scott", 47));
		root3.add(new Person("Steve", 46));
		root3.add(new Person("Claire", 17));
		root3.add(new Person("Kai", 7));
		
		root3.inorder(data -> System.out.println(data));
		System.out.println("--------------------------------");
		root3.inorder(System.out::println);

		int[] sum = {0};
		root3.inorder(data -> sum[0] += data.getAge());
		System.out.println(sum[0]);

		System.out.println("--------------------------------");
		BinaryTreeNode4<Person> root4 = new BinaryTreeNode4<Person>(new Person("Scott", 47));
		root4.add(new Person("Steve", 46));
		root4.add(new Person("Claire", 17));
		root4.add(new Person("Kai", 7));
		root4.inorder(System.out::println);
		
		System.out.println("--------------------------------");
		BinaryTreeNode5<Person> root5 = new BinaryTreeNode5<Person>(new Person("Scott", 47));
		root5.add(new Person("Steve", 46));
		root5.add(new Person("Cameron", 58));
		root5.add(new Person("Claire", 17));
		root5.add(new Person("Kai", 7));
		
		Predicate<Person> lessThan40 = data -> data.getAge()< 40;
		Predicate<Person> startsWithC = data -> data.getName().startsWith("C");
		
 		root5.inorder(lessThan40, System.out::println);
 		System.out.println("--------------------------------");
 		root5.inorder(lessThan40.negate().and(startsWithC), System.out::println);
	}

}
