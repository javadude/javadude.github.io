package com.javadude.java8;

public class PrintNode<T extends Comparable<T>> extends BinaryTreeNode2<T> {
	public PrintNode(T data) {
		super(data);
	}

	@Override
	protected BinaryTreeNode2<T> create(T data) {
		return new PrintNode<T>(data);
	}

	@Override
	protected void process() {
		System.out.println(getData());
	}
}
