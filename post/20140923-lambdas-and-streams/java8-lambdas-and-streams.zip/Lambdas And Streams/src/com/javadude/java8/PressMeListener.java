package com.javadude.java8;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PressMeListener implements ActionListener {

	public void actionPerformed(ActionEvent e) {
		System.out.println("External: button pressed");
	}
}
