package com.javadude.deadlock

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.text
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        text.setOnClickListener {
            val obj1 = Any()
            val obj2 = Any()
            startThread("t1", obj1, obj2)
            startThread("t2", obj2, obj1)
        }
    }

    private fun startThread(name : String, obj1: Any, obj2: Any) =
            thread(name = name) {
                synchronized(obj1) {
                    Log.d("!!!DL EXAMPLE", "$name: acquired $obj1")
                    Thread.sleep(500)
                    synchronized(obj2) {
                        Log.d("!!!DL EXAMPLE", "$name: acquired $obj2")
                    }
                }
                Log.d("!!!DL EXAMPLE", "$name finished execution.")
            }
}