/**
 */
package com.javadude.beans2.dsl.beansDsl;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enum Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.javadude.beans2.dsl.beansDsl.EnumType#getValues <em>Values</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.javadude.beans2.dsl.beansDsl.BeansDslPackage#getEnumType()
 * @model
 * @generated
 */
public interface EnumType extends Type
{
  /**
   * Returns the value of the '<em><b>Values</b></em>' containment reference list.
   * The list contents are of type {@link com.javadude.beans2.dsl.beansDsl.Value}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Values</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Values</em>' containment reference list.
   * @see com.javadude.beans2.dsl.beansDsl.BeansDslPackage#getEnumType_Values()
   * @model containment="true"
   * @generated
   */
  EList<Value> getValues();

} // EnumType
