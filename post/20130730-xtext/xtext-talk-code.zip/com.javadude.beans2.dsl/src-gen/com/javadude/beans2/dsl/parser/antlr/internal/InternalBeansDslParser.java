package com.javadude.beans2.dsl.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import com.javadude.beans2.dsl.services.BeansDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalBeansDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_LBRACE", "RULE_RBRACE", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'.'", "'class'", "'bound'", "';'", "'List'", "'<'", "'>'", "'enum'", "'primitive'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_RBRACE=6;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=12;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=10;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__19=19;
    public static final int RULE_STRING=8;
    public static final int T__16=16;
    public static final int T__15=15;
    public static final int T__18=18;
    public static final int T__17=17;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=7;
    public static final int RULE_LBRACE=5;
    public static final int RULE_WS=11;

    // delegates
    // delegators


        public InternalBeansDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalBeansDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalBeansDslParser.tokenNames; }
    public String getGrammarFileName() { return "../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g"; }



     	private BeansDslGrammarAccess grammarAccess;
     	
        public InternalBeansDslParser(TokenStream input, BeansDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "Model";	
       	}
       	
       	@Override
       	protected BeansDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRuleModel"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:67:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:68:2: (iv_ruleModel= ruleModel EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:69:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_ruleModel_in_entryRuleModel75);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleModel85); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:76:1: ruleModel returns [EObject current=null] : (otherlv_0= 'package' ( (lv_packageName_1_0= ruleFQN ) ) ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+ ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_packageName_1_0 = null;

        EObject lv_types_2_0 = null;

        EObject lv_types_3_0 = null;

        EObject lv_types_4_0 = null;


         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:79:28: ( (otherlv_0= 'package' ( (lv_packageName_1_0= ruleFQN ) ) ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+ ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:80:1: (otherlv_0= 'package' ( (lv_packageName_1_0= ruleFQN ) ) ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+ )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:80:1: (otherlv_0= 'package' ( (lv_packageName_1_0= ruleFQN ) ) ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+ )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:80:3: otherlv_0= 'package' ( (lv_packageName_1_0= ruleFQN ) ) ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+
            {
            otherlv_0=(Token)match(input,13,FOLLOW_13_in_ruleModel122); 

                	newLeafNode(otherlv_0, grammarAccess.getModelAccess().getPackageKeyword_0());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:84:1: ( (lv_packageName_1_0= ruleFQN ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:85:1: (lv_packageName_1_0= ruleFQN )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:85:1: (lv_packageName_1_0= ruleFQN )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:86:3: lv_packageName_1_0= ruleFQN
            {
             
            	        newCompositeNode(grammarAccess.getModelAccess().getPackageNameFQNParserRuleCall_1_0()); 
            	    
            pushFollow(FOLLOW_ruleFQN_in_ruleModel143);
            lv_packageName_1_0=ruleFQN();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getModelRule());
            	        }
                   		set(
                   			current, 
                   			"packageName",
                    		lv_packageName_1_0, 
                    		"FQN");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:102:2: ( ( (lv_types_2_0= ruleClassType ) ) | ( (lv_types_3_0= ruleEnumType ) ) | ( (lv_types_4_0= rulePrimitiveType ) ) )+
            int cnt1=0;
            loop1:
            do {
                int alt1=4;
                switch ( input.LA(1) ) {
                case 15:
                    {
                    alt1=1;
                    }
                    break;
                case 21:
                    {
                    alt1=2;
                    }
                    break;
                case 22:
                    {
                    alt1=3;
                    }
                    break;

                }

                switch (alt1) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:102:3: ( (lv_types_2_0= ruleClassType ) )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:102:3: ( (lv_types_2_0= ruleClassType ) )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:103:1: (lv_types_2_0= ruleClassType )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:103:1: (lv_types_2_0= ruleClassType )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:104:3: lv_types_2_0= ruleClassType
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getModelAccess().getTypesClassTypeParserRuleCall_2_0_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleClassType_in_ruleModel165);
            	    lv_types_2_0=ruleClassType();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"types",
            	            		lv_types_2_0, 
            	            		"ClassType");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;
            	case 2 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:121:6: ( (lv_types_3_0= ruleEnumType ) )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:121:6: ( (lv_types_3_0= ruleEnumType ) )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:122:1: (lv_types_3_0= ruleEnumType )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:122:1: (lv_types_3_0= ruleEnumType )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:123:3: lv_types_3_0= ruleEnumType
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getModelAccess().getTypesEnumTypeParserRuleCall_2_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleEnumType_in_ruleModel192);
            	    lv_types_3_0=ruleEnumType();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"types",
            	            		lv_types_3_0, 
            	            		"EnumType");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;
            	case 3 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:140:6: ( (lv_types_4_0= rulePrimitiveType ) )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:140:6: ( (lv_types_4_0= rulePrimitiveType ) )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:141:1: (lv_types_4_0= rulePrimitiveType )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:141:1: (lv_types_4_0= rulePrimitiveType )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:142:3: lv_types_4_0= rulePrimitiveType
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getModelAccess().getTypesPrimitiveTypeParserRuleCall_2_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_rulePrimitiveType_in_ruleModel219);
            	    lv_types_4_0=rulePrimitiveType();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"types",
            	            		lv_types_4_0, 
            	            		"PrimitiveType");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleFQN"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:166:1: entryRuleFQN returns [String current=null] : iv_ruleFQN= ruleFQN EOF ;
    public final String entryRuleFQN() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleFQN = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:167:2: (iv_ruleFQN= ruleFQN EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:168:2: iv_ruleFQN= ruleFQN EOF
            {
             newCompositeNode(grammarAccess.getFQNRule()); 
            pushFollow(FOLLOW_ruleFQN_in_entryRuleFQN258);
            iv_ruleFQN=ruleFQN();

            state._fsp--;

             current =iv_ruleFQN.getText(); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFQN269); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFQN"


    // $ANTLR start "ruleFQN"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:175:1: ruleFQN returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleFQN() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_2=null;

         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:178:28: ( (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:179:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:179:1: (this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )* )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:179:6: this_ID_0= RULE_ID (kw= '.' this_ID_2= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFQN309); 

            		current.merge(this_ID_0);
                
             
                newLeafNode(this_ID_0, grammarAccess.getFQNAccess().getIDTerminalRuleCall_0()); 
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:186:1: (kw= '.' this_ID_2= RULE_ID )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==14) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:187:2: kw= '.' this_ID_2= RULE_ID
            	    {
            	    kw=(Token)match(input,14,FOLLOW_14_in_ruleFQN328); 

            	            current.merge(kw);
            	            newLeafNode(kw, grammarAccess.getFQNAccess().getFullStopKeyword_1_0()); 
            	        
            	    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFQN343); 

            	    		current.merge(this_ID_2);
            	        
            	     
            	        newLeafNode(this_ID_2, grammarAccess.getFQNAccess().getIDTerminalRuleCall_1_1()); 
            	        

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFQN"


    // $ANTLR start "entryRuleClassType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:209:1: entryRuleClassType returns [EObject current=null] : iv_ruleClassType= ruleClassType EOF ;
    public final EObject entryRuleClassType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClassType = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:210:2: (iv_ruleClassType= ruleClassType EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:211:2: iv_ruleClassType= ruleClassType EOF
            {
             newCompositeNode(grammarAccess.getClassTypeRule()); 
            pushFollow(FOLLOW_ruleClassType_in_entryRuleClassType392);
            iv_ruleClassType=ruleClassType();

            state._fsp--;

             current =iv_ruleClassType; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleClassType402); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClassType"


    // $ANTLR start "ruleClassType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:218:1: ruleClassType returns [EObject current=null] : (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_fields_3_0= ruleField ) )* this_RBRACE_4= RULE_RBRACE ) ;
    public final EObject ruleClassType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_LBRACE_2=null;
        Token this_RBRACE_4=null;
        EObject lv_fields_3_0 = null;


         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:221:28: ( (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_fields_3_0= ruleField ) )* this_RBRACE_4= RULE_RBRACE ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:222:1: (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_fields_3_0= ruleField ) )* this_RBRACE_4= RULE_RBRACE )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:222:1: (otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_fields_3_0= ruleField ) )* this_RBRACE_4= RULE_RBRACE )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:222:3: otherlv_0= 'class' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_fields_3_0= ruleField ) )* this_RBRACE_4= RULE_RBRACE
            {
            otherlv_0=(Token)match(input,15,FOLLOW_15_in_ruleClassType439); 

                	newLeafNode(otherlv_0, grammarAccess.getClassTypeAccess().getClassKeyword_0());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:226:1: ( (lv_name_1_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:227:1: (lv_name_1_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:227:1: (lv_name_1_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:228:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleClassType456); 

            			newLeafNode(lv_name_1_0, grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getClassTypeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            this_LBRACE_2=(Token)match(input,RULE_LBRACE,FOLLOW_RULE_LBRACE_in_ruleClassType472); 
             
                newLeafNode(this_LBRACE_2, grammarAccess.getClassTypeAccess().getLBRACETerminalRuleCall_2()); 
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:248:1: ( (lv_fields_3_0= ruleField ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID||LA3_0==16||LA3_0==18) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:249:1: (lv_fields_3_0= ruleField )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:249:1: (lv_fields_3_0= ruleField )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:250:3: lv_fields_3_0= ruleField
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getClassTypeAccess().getFieldsFieldParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleField_in_ruleClassType492);
            	    lv_fields_3_0=ruleField();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getClassTypeRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"fields",
            	            		lv_fields_3_0, 
            	            		"Field");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            this_RBRACE_4=(Token)match(input,RULE_RBRACE,FOLLOW_RULE_RBRACE_in_ruleClassType504); 
             
                newLeafNode(this_RBRACE_4, grammarAccess.getClassTypeAccess().getRBRACETerminalRuleCall_4()); 
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClassType"


    // $ANTLR start "entryRuleField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:278:1: entryRuleField returns [EObject current=null] : iv_ruleField= ruleField EOF ;
    public final EObject entryRuleField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleField = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:279:2: (iv_ruleField= ruleField EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:280:2: iv_ruleField= ruleField EOF
            {
             newCompositeNode(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField539);
            iv_ruleField=ruleField();

            state._fsp--;

             current =iv_ruleField; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField549); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:287:1: ruleField returns [EObject current=null] : (this_SimpleField_0= ruleSimpleField | this_ListField_1= ruleListField ) ;
    public final EObject ruleField() throws RecognitionException {
        EObject current = null;

        EObject this_SimpleField_0 = null;

        EObject this_ListField_1 = null;


         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:290:28: ( (this_SimpleField_0= ruleSimpleField | this_ListField_1= ruleListField ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:291:1: (this_SimpleField_0= ruleSimpleField | this_ListField_1= ruleListField )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:291:1: (this_SimpleField_0= ruleSimpleField | this_ListField_1= ruleListField )
            int alt4=2;
            switch ( input.LA(1) ) {
            case 16:
                {
                int LA4_1 = input.LA(2);

                if ( (LA4_1==18) ) {
                    alt4=2;
                }
                else if ( (LA4_1==RULE_ID) ) {
                    alt4=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
                {
                alt4=1;
                }
                break;
            case 18:
                {
                alt4=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }

            switch (alt4) {
                case 1 :
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:292:5: this_SimpleField_0= ruleSimpleField
                    {
                     
                            newCompositeNode(grammarAccess.getFieldAccess().getSimpleFieldParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleSimpleField_in_ruleField596);
                    this_SimpleField_0=ruleSimpleField();

                    state._fsp--;

                     
                            current = this_SimpleField_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:302:5: this_ListField_1= ruleListField
                    {
                     
                            newCompositeNode(grammarAccess.getFieldAccess().getListFieldParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleListField_in_ruleField623);
                    this_ListField_1=ruleListField();

                    state._fsp--;

                     
                            current = this_ListField_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleSimpleField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:318:1: entryRuleSimpleField returns [EObject current=null] : iv_ruleSimpleField= ruleSimpleField EOF ;
    public final EObject entryRuleSimpleField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSimpleField = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:319:2: (iv_ruleSimpleField= ruleSimpleField EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:320:2: iv_ruleSimpleField= ruleSimpleField EOF
            {
             newCompositeNode(grammarAccess.getSimpleFieldRule()); 
            pushFollow(FOLLOW_ruleSimpleField_in_entryRuleSimpleField658);
            iv_ruleSimpleField=ruleSimpleField();

            state._fsp--;

             current =iv_ruleSimpleField; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSimpleField668); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSimpleField"


    // $ANTLR start "ruleSimpleField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:327:1: ruleSimpleField returns [EObject current=null] : ( ( (lv_bound_0_0= 'bound' ) )? ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= ';' ) ;
    public final EObject ruleSimpleField() throws RecognitionException {
        EObject current = null;

        Token lv_bound_0_0=null;
        Token otherlv_1=null;
        Token lv_name_2_0=null;
        Token otherlv_3=null;

         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:330:28: ( ( ( (lv_bound_0_0= 'bound' ) )? ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= ';' ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:331:1: ( ( (lv_bound_0_0= 'bound' ) )? ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= ';' )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:331:1: ( ( (lv_bound_0_0= 'bound' ) )? ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= ';' )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:331:2: ( (lv_bound_0_0= 'bound' ) )? ( (otherlv_1= RULE_ID ) ) ( (lv_name_2_0= RULE_ID ) ) otherlv_3= ';'
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:331:2: ( (lv_bound_0_0= 'bound' ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:332:1: (lv_bound_0_0= 'bound' )
                    {
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:332:1: (lv_bound_0_0= 'bound' )
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:333:3: lv_bound_0_0= 'bound'
                    {
                    lv_bound_0_0=(Token)match(input,16,FOLLOW_16_in_ruleSimpleField711); 

                            newLeafNode(lv_bound_0_0, grammarAccess.getSimpleFieldAccess().getBoundBoundKeyword_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getSimpleFieldRule());
                    	        }
                           		setWithLastConsumed(current, "bound", true, "bound");
                    	    

                    }


                    }
                    break;

            }

            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:346:3: ( (otherlv_1= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:347:1: (otherlv_1= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:347:1: (otherlv_1= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:348:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getSimpleFieldRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleSimpleField745); 

            		newLeafNode(otherlv_1, grammarAccess.getSimpleFieldAccess().getTypeTypeCrossReference_1_0()); 
            	

            }


            }

            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:359:2: ( (lv_name_2_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:360:1: (lv_name_2_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:360:1: (lv_name_2_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:361:3: lv_name_2_0= RULE_ID
            {
            lv_name_2_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleSimpleField762); 

            			newLeafNode(lv_name_2_0, grammarAccess.getSimpleFieldAccess().getNameIDTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getSimpleFieldRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_2_0, 
                    		"ID");
            	    

            }


            }

            otherlv_3=(Token)match(input,17,FOLLOW_17_in_ruleSimpleField779); 

                	newLeafNode(otherlv_3, grammarAccess.getSimpleFieldAccess().getSemicolonKeyword_3());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSimpleField"


    // $ANTLR start "entryRuleListField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:389:1: entryRuleListField returns [EObject current=null] : iv_ruleListField= ruleListField EOF ;
    public final EObject entryRuleListField() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleListField = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:390:2: (iv_ruleListField= ruleListField EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:391:2: iv_ruleListField= ruleListField EOF
            {
             newCompositeNode(grammarAccess.getListFieldRule()); 
            pushFollow(FOLLOW_ruleListField_in_entryRuleListField815);
            iv_ruleListField=ruleListField();

            state._fsp--;

             current =iv_ruleListField; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListField825); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleListField"


    // $ANTLR start "ruleListField"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:398:1: ruleListField returns [EObject current=null] : ( ( (lv_bound_0_0= 'bound' ) )? otherlv_1= 'List' otherlv_2= '<' ( (otherlv_3= RULE_ID ) ) otherlv_4= '>' ( (lv_name_5_0= RULE_ID ) ) otherlv_6= ';' ) ;
    public final EObject ruleListField() throws RecognitionException {
        EObject current = null;

        Token lv_bound_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token lv_name_5_0=null;
        Token otherlv_6=null;

         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:401:28: ( ( ( (lv_bound_0_0= 'bound' ) )? otherlv_1= 'List' otherlv_2= '<' ( (otherlv_3= RULE_ID ) ) otherlv_4= '>' ( (lv_name_5_0= RULE_ID ) ) otherlv_6= ';' ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:402:1: ( ( (lv_bound_0_0= 'bound' ) )? otherlv_1= 'List' otherlv_2= '<' ( (otherlv_3= RULE_ID ) ) otherlv_4= '>' ( (lv_name_5_0= RULE_ID ) ) otherlv_6= ';' )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:402:1: ( ( (lv_bound_0_0= 'bound' ) )? otherlv_1= 'List' otherlv_2= '<' ( (otherlv_3= RULE_ID ) ) otherlv_4= '>' ( (lv_name_5_0= RULE_ID ) ) otherlv_6= ';' )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:402:2: ( (lv_bound_0_0= 'bound' ) )? otherlv_1= 'List' otherlv_2= '<' ( (otherlv_3= RULE_ID ) ) otherlv_4= '>' ( (lv_name_5_0= RULE_ID ) ) otherlv_6= ';'
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:402:2: ( (lv_bound_0_0= 'bound' ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==16) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:403:1: (lv_bound_0_0= 'bound' )
                    {
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:403:1: (lv_bound_0_0= 'bound' )
                    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:404:3: lv_bound_0_0= 'bound'
                    {
                    lv_bound_0_0=(Token)match(input,16,FOLLOW_16_in_ruleListField868); 

                            newLeafNode(lv_bound_0_0, grammarAccess.getListFieldAccess().getBoundBoundKeyword_0_0());
                        

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getListFieldRule());
                    	        }
                           		setWithLastConsumed(current, "bound", true, "bound");
                    	    

                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,18,FOLLOW_18_in_ruleListField894); 

                	newLeafNode(otherlv_1, grammarAccess.getListFieldAccess().getListKeyword_1());
                
            otherlv_2=(Token)match(input,19,FOLLOW_19_in_ruleListField906); 

                	newLeafNode(otherlv_2, grammarAccess.getListFieldAccess().getLessThanSignKeyword_2());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:425:1: ( (otherlv_3= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:426:1: (otherlv_3= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:426:1: (otherlv_3= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:427:3: otherlv_3= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getListFieldRule());
            	        }
                    
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListField926); 

            		newLeafNode(otherlv_3, grammarAccess.getListFieldAccess().getTypeTypeCrossReference_3_0()); 
            	

            }


            }

            otherlv_4=(Token)match(input,20,FOLLOW_20_in_ruleListField938); 

                	newLeafNode(otherlv_4, grammarAccess.getListFieldAccess().getGreaterThanSignKeyword_4());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:442:1: ( (lv_name_5_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:443:1: (lv_name_5_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:443:1: (lv_name_5_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:444:3: lv_name_5_0= RULE_ID
            {
            lv_name_5_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleListField955); 

            			newLeafNode(lv_name_5_0, grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_5_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getListFieldRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_5_0, 
                    		"ID");
            	    

            }


            }

            otherlv_6=(Token)match(input,17,FOLLOW_17_in_ruleListField972); 

                	newLeafNode(otherlv_6, grammarAccess.getListFieldAccess().getSemicolonKeyword_6());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleListField"


    // $ANTLR start "entryRuleEnumType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:472:1: entryRuleEnumType returns [EObject current=null] : iv_ruleEnumType= ruleEnumType EOF ;
    public final EObject entryRuleEnumType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnumType = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:473:2: (iv_ruleEnumType= ruleEnumType EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:474:2: iv_ruleEnumType= ruleEnumType EOF
            {
             newCompositeNode(grammarAccess.getEnumTypeRule()); 
            pushFollow(FOLLOW_ruleEnumType_in_entryRuleEnumType1008);
            iv_ruleEnumType=ruleEnumType();

            state._fsp--;

             current =iv_ruleEnumType; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEnumType1018); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnumType"


    // $ANTLR start "ruleEnumType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:481:1: ruleEnumType returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_values_3_0= ruleValue ) )+ this_RBRACE_4= RULE_RBRACE ) ;
    public final EObject ruleEnumType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;
        Token this_LBRACE_2=null;
        Token this_RBRACE_4=null;
        EObject lv_values_3_0 = null;


         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:484:28: ( (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_values_3_0= ruleValue ) )+ this_RBRACE_4= RULE_RBRACE ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:485:1: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_values_3_0= ruleValue ) )+ this_RBRACE_4= RULE_RBRACE )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:485:1: (otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_values_3_0= ruleValue ) )+ this_RBRACE_4= RULE_RBRACE )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:485:3: otherlv_0= 'enum' ( (lv_name_1_0= RULE_ID ) ) this_LBRACE_2= RULE_LBRACE ( (lv_values_3_0= ruleValue ) )+ this_RBRACE_4= RULE_RBRACE
            {
            otherlv_0=(Token)match(input,21,FOLLOW_21_in_ruleEnumType1055); 

                	newLeafNode(otherlv_0, grammarAccess.getEnumTypeAccess().getEnumKeyword_0());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:489:1: ( (lv_name_1_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:490:1: (lv_name_1_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:490:1: (lv_name_1_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:491:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEnumType1072); 

            			newLeafNode(lv_name_1_0, grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getEnumTypeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }

            this_LBRACE_2=(Token)match(input,RULE_LBRACE,FOLLOW_RULE_LBRACE_in_ruleEnumType1088); 
             
                newLeafNode(this_LBRACE_2, grammarAccess.getEnumTypeAccess().getLBRACETerminalRuleCall_2()); 
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:511:1: ( (lv_values_3_0= ruleValue ) )+
            int cnt7=0;
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==RULE_ID) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:512:1: (lv_values_3_0= ruleValue )
            	    {
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:512:1: (lv_values_3_0= ruleValue )
            	    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:513:3: lv_values_3_0= ruleValue
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getEnumTypeAccess().getValuesValueParserRuleCall_3_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleValue_in_ruleEnumType1108);
            	    lv_values_3_0=ruleValue();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getEnumTypeRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"values",
            	            		lv_values_3_0, 
            	            		"Value");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt7 >= 1 ) break loop7;
                        EarlyExitException eee =
                            new EarlyExitException(7, input);
                        throw eee;
                }
                cnt7++;
            } while (true);

            this_RBRACE_4=(Token)match(input,RULE_RBRACE,FOLLOW_RULE_RBRACE_in_ruleEnumType1120); 
             
                newLeafNode(this_RBRACE_4, grammarAccess.getEnumTypeAccess().getRBRACETerminalRuleCall_4()); 
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnumType"


    // $ANTLR start "entryRuleValue"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:541:1: entryRuleValue returns [EObject current=null] : iv_ruleValue= ruleValue EOF ;
    public final EObject entryRuleValue() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValue = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:542:2: (iv_ruleValue= ruleValue EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:543:2: iv_ruleValue= ruleValue EOF
            {
             newCompositeNode(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_ruleValue_in_entryRuleValue1155);
            iv_ruleValue=ruleValue();

            state._fsp--;

             current =iv_ruleValue; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleValue1165); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValue"


    // $ANTLR start "ruleValue"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:550:1: ruleValue returns [EObject current=null] : ( (lv_name_0_0= RULE_ID ) ) ;
    public final EObject ruleValue() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;

         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:553:28: ( ( (lv_name_0_0= RULE_ID ) ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:554:1: ( (lv_name_0_0= RULE_ID ) )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:554:1: ( (lv_name_0_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:555:1: (lv_name_0_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:555:1: (lv_name_0_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:556:3: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleValue1206); 

            			newLeafNode(lv_name_0_0, grammarAccess.getValueAccess().getNameIDTerminalRuleCall_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getValueRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_0_0, 
                    		"ID");
            	    

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValue"


    // $ANTLR start "entryRulePrimitiveType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:580:1: entryRulePrimitiveType returns [EObject current=null] : iv_rulePrimitiveType= rulePrimitiveType EOF ;
    public final EObject entryRulePrimitiveType() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrimitiveType = null;


        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:581:2: (iv_rulePrimitiveType= rulePrimitiveType EOF )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:582:2: iv_rulePrimitiveType= rulePrimitiveType EOF
            {
             newCompositeNode(grammarAccess.getPrimitiveTypeRule()); 
            pushFollow(FOLLOW_rulePrimitiveType_in_entryRulePrimitiveType1246);
            iv_rulePrimitiveType=rulePrimitiveType();

            state._fsp--;

             current =iv_rulePrimitiveType; 
            match(input,EOF,FOLLOW_EOF_in_entryRulePrimitiveType1256); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrimitiveType"


    // $ANTLR start "rulePrimitiveType"
    // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:589:1: rulePrimitiveType returns [EObject current=null] : (otherlv_0= 'primitive' ( (lv_name_1_0= RULE_ID ) ) ) ;
    public final EObject rulePrimitiveType() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_name_1_0=null;

         enterRule(); 
            
        try {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:592:28: ( (otherlv_0= 'primitive' ( (lv_name_1_0= RULE_ID ) ) ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:593:1: (otherlv_0= 'primitive' ( (lv_name_1_0= RULE_ID ) ) )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:593:1: (otherlv_0= 'primitive' ( (lv_name_1_0= RULE_ID ) ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:593:3: otherlv_0= 'primitive' ( (lv_name_1_0= RULE_ID ) )
            {
            otherlv_0=(Token)match(input,22,FOLLOW_22_in_rulePrimitiveType1293); 

                	newLeafNode(otherlv_0, grammarAccess.getPrimitiveTypeAccess().getPrimitiveKeyword_0());
                
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:597:1: ( (lv_name_1_0= RULE_ID ) )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:598:1: (lv_name_1_0= RULE_ID )
            {
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:598:1: (lv_name_1_0= RULE_ID )
            // ../com.javadude.beans2.dsl/src-gen/com/javadude/beans2/dsl/parser/antlr/internal/InternalBeansDsl.g:599:3: lv_name_1_0= RULE_ID
            {
            lv_name_1_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_rulePrimitiveType1310); 

            			newLeafNode(lv_name_1_0, grammarAccess.getPrimitiveTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getPrimitiveTypeRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_1_0, 
                    		"ID");
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrimitiveType"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleModel_in_entryRuleModel75 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleModel85 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_ruleModel122 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleFQN_in_ruleModel143 = new BitSet(new long[]{0x0000000000608000L});
    public static final BitSet FOLLOW_ruleClassType_in_ruleModel165 = new BitSet(new long[]{0x0000000000608002L});
    public static final BitSet FOLLOW_ruleEnumType_in_ruleModel192 = new BitSet(new long[]{0x0000000000608002L});
    public static final BitSet FOLLOW_rulePrimitiveType_in_ruleModel219 = new BitSet(new long[]{0x0000000000608002L});
    public static final BitSet FOLLOW_ruleFQN_in_entryRuleFQN258 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFQN269 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFQN309 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_14_in_ruleFQN328 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFQN343 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_ruleClassType_in_entryRuleClassType392 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleClassType402 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_ruleClassType439 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleClassType456 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_LBRACE_in_ruleClassType472 = new BitSet(new long[]{0x0000000000050050L});
    public static final BitSet FOLLOW_ruleField_in_ruleClassType492 = new BitSet(new long[]{0x0000000000050050L});
    public static final BitSet FOLLOW_RULE_RBRACE_in_ruleClassType504 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField539 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField549 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSimpleField_in_ruleField596 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListField_in_ruleField623 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSimpleField_in_entryRuleSimpleField658 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSimpleField668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_ruleSimpleField711 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleSimpleField745 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleSimpleField762 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleSimpleField779 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListField_in_entryRuleListField815 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListField825 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_ruleListField868 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleListField894 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_ruleListField906 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListField926 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_ruleListField938 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleListField955 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleListField972 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEnumType_in_entryRuleEnumType1008 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEnumType1018 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_ruleEnumType1055 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEnumType1072 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_LBRACE_in_ruleEnumType1088 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleValue_in_ruleEnumType1108 = new BitSet(new long[]{0x0000000000000050L});
    public static final BitSet FOLLOW_RULE_RBRACE_in_ruleEnumType1120 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleValue_in_entryRuleValue1155 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleValue1165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleValue1206 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimitiveType_in_entryRulePrimitiveType1246 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePrimitiveType1256 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rulePrimitiveType1293 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_rulePrimitiveType1310 = new BitSet(new long[]{0x0000000000000002L});

}