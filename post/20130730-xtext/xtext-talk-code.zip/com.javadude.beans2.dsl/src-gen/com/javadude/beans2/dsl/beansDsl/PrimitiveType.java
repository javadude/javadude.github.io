/**
 */
package com.javadude.beans2.dsl.beansDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.javadude.beans2.dsl.beansDsl.BeansDslPackage#getPrimitiveType()
 * @model
 * @generated
 */
public interface PrimitiveType extends Type
{
} // PrimitiveType
