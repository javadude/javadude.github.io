/**
 */
package com.javadude.beans2.dsl.beansDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Field</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.javadude.beans2.dsl.beansDsl.BeansDslPackage#getSimpleField()
 * @model
 * @generated
 */
public interface SimpleField extends Field
{
} // SimpleField
