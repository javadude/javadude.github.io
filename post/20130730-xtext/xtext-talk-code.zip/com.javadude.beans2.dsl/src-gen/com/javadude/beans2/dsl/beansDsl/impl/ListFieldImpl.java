/**
 */
package com.javadude.beans2.dsl.beansDsl.impl;

import com.javadude.beans2.dsl.beansDsl.BeansDslPackage;
import com.javadude.beans2.dsl.beansDsl.ListField;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>List Field</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ListFieldImpl extends FieldImpl implements ListField
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ListFieldImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return BeansDslPackage.Literals.LIST_FIELD;
  }

} //ListFieldImpl
