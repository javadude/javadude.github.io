package com.javadude.beans2.dsl.serializer;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.javadude.beans2.dsl.beansDsl.BeansDslPackage;
import com.javadude.beans2.dsl.beansDsl.ClassType;
import com.javadude.beans2.dsl.beansDsl.EnumType;
import com.javadude.beans2.dsl.beansDsl.ListField;
import com.javadude.beans2.dsl.beansDsl.Model;
import com.javadude.beans2.dsl.beansDsl.PrimitiveType;
import com.javadude.beans2.dsl.beansDsl.SimpleField;
import com.javadude.beans2.dsl.beansDsl.Value;
import com.javadude.beans2.dsl.services.BeansDslGrammarAccess;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.serializer.acceptor.ISemanticSequenceAcceptor;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.diagnostic.ISemanticSequencerDiagnosticProvider;
import org.eclipse.xtext.serializer.diagnostic.ISerializationDiagnostic.Acceptor;
import org.eclipse.xtext.serializer.sequencer.AbstractDelegatingSemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.GenericSequencer;
import org.eclipse.xtext.serializer.sequencer.ISemanticNodeProvider.INodesForEObjectProvider;
import org.eclipse.xtext.serializer.sequencer.ISemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;

@SuppressWarnings("all")
public class BeansDslSemanticSequencer extends AbstractDelegatingSemanticSequencer {

	@Inject
	private BeansDslGrammarAccess grammarAccess;
	
	public void createSequence(EObject context, EObject semanticObject) {
		if(semanticObject.eClass().getEPackage() == BeansDslPackage.eINSTANCE) switch(semanticObject.eClass().getClassifierID()) {
			case BeansDslPackage.CLASS_TYPE:
				if(context == grammarAccess.getClassTypeRule() ||
				   context == grammarAccess.getTypeRule()) {
					sequence_ClassType(context, (ClassType) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.ENUM_TYPE:
				if(context == grammarAccess.getEnumTypeRule() ||
				   context == grammarAccess.getTypeRule()) {
					sequence_EnumType(context, (EnumType) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.LIST_FIELD:
				if(context == grammarAccess.getFieldRule() ||
				   context == grammarAccess.getListFieldRule()) {
					sequence_ListField(context, (ListField) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.MODEL:
				if(context == grammarAccess.getModelRule()) {
					sequence_Model(context, (Model) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.PRIMITIVE_TYPE:
				if(context == grammarAccess.getPrimitiveTypeRule() ||
				   context == grammarAccess.getTypeRule()) {
					sequence_PrimitiveType(context, (PrimitiveType) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.SIMPLE_FIELD:
				if(context == grammarAccess.getFieldRule() ||
				   context == grammarAccess.getSimpleFieldRule()) {
					sequence_SimpleField(context, (SimpleField) semanticObject); 
					return; 
				}
				else break;
			case BeansDslPackage.VALUE:
				if(context == grammarAccess.getValueRule()) {
					sequence_Value(context, (Value) semanticObject); 
					return; 
				}
				else break;
			}
		if (errorAcceptor != null) errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Constraint:
	 *     (name=ID fields+=Field*)
	 */
	protected void sequence_ClassType(EObject context, ClassType semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (name=ID values+=Value+)
	 */
	protected void sequence_EnumType(EObject context, EnumType semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (bound?='bound'? type=[Type|ID] name=ID)
	 */
	protected void sequence_ListField(EObject context, ListField semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (packageName=FQN (types+=ClassType | types+=EnumType | types+=PrimitiveType)+)
	 */
	protected void sequence_Model(EObject context, Model semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     name=ID
	 */
	protected void sequence_PrimitiveType(EObject context, PrimitiveType semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, BeansDslPackage.Literals.TYPE__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, BeansDslPackage.Literals.TYPE__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getPrimitiveTypeAccess().getNameIDTerminalRuleCall_1_0(), semanticObject.getName());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (bound?='bound'? type=[Type|ID] name=ID)
	 */
	protected void sequence_SimpleField(EObject context, SimpleField semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     name=ID
	 */
	protected void sequence_Value(EObject context, Value semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, BeansDslPackage.Literals.VALUE__NAME) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, BeansDslPackage.Literals.VALUE__NAME));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getValueAccess().getNameIDTerminalRuleCall_0(), semanticObject.getName());
		feeder.finish();
	}
}
