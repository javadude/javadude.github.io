/**
 */
package com.javadude.beans2.dsl.beansDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List Field</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see com.javadude.beans2.dsl.beansDsl.BeansDslPackage#getListField()
 * @model
 * @generated
 */
public interface ListField extends Field
{
} // ListField
