package com.javadude.beans2.dsl.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import com.javadude.beans2.dsl.services.BeansDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalBeansDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_LBRACE", "RULE_RBRACE", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'package'", "'.'", "'class'", "';'", "'List'", "'<'", "'>'", "'enum'", "'primitive'", "'bound'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_RBRACE=6;
    public static final int T__22=22;
    public static final int RULE_ANY_OTHER=12;
    public static final int T__21=21;
    public static final int T__20=20;
    public static final int RULE_SL_COMMENT=10;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=9;
    public static final int T__19=19;
    public static final int RULE_STRING=8;
    public static final int T__16=16;
    public static final int T__15=15;
    public static final int T__18=18;
    public static final int T__17=17;
    public static final int T__14=14;
    public static final int T__13=13;
    public static final int RULE_INT=7;
    public static final int RULE_LBRACE=5;
    public static final int RULE_WS=11;

    // delegates
    // delegators


        public InternalBeansDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalBeansDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalBeansDslParser.tokenNames; }
    public String getGrammarFileName() { return "../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g"; }


     
     	private BeansDslGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(BeansDslGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleModel"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:60:1: entryRuleModel : ruleModel EOF ;
    public final void entryRuleModel() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:61:1: ( ruleModel EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:62:1: ruleModel EOF
            {
             before(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_ruleModel_in_entryRuleModel61);
            ruleModel();

            state._fsp--;

             after(grammarAccess.getModelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleModel68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:69:1: ruleModel : ( ( rule__Model__Group__0 ) ) ;
    public final void ruleModel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:73:2: ( ( ( rule__Model__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:74:1: ( ( rule__Model__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:74:1: ( ( rule__Model__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:75:1: ( rule__Model__Group__0 )
            {
             before(grammarAccess.getModelAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:76:1: ( rule__Model__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:76:2: rule__Model__Group__0
            {
            pushFollow(FOLLOW_rule__Model__Group__0_in_ruleModel94);
            rule__Model__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleFQN"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:88:1: entryRuleFQN : ruleFQN EOF ;
    public final void entryRuleFQN() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:89:1: ( ruleFQN EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:90:1: ruleFQN EOF
            {
             before(grammarAccess.getFQNRule()); 
            pushFollow(FOLLOW_ruleFQN_in_entryRuleFQN121);
            ruleFQN();

            state._fsp--;

             after(grammarAccess.getFQNRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFQN128); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFQN"


    // $ANTLR start "ruleFQN"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:97:1: ruleFQN : ( ( rule__FQN__Group__0 ) ) ;
    public final void ruleFQN() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:101:2: ( ( ( rule__FQN__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:102:1: ( ( rule__FQN__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:102:1: ( ( rule__FQN__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:103:1: ( rule__FQN__Group__0 )
            {
             before(grammarAccess.getFQNAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:104:1: ( rule__FQN__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:104:2: rule__FQN__Group__0
            {
            pushFollow(FOLLOW_rule__FQN__Group__0_in_ruleFQN154);
            rule__FQN__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFQNAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFQN"


    // $ANTLR start "entryRuleClassType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:118:1: entryRuleClassType : ruleClassType EOF ;
    public final void entryRuleClassType() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:119:1: ( ruleClassType EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:120:1: ruleClassType EOF
            {
             before(grammarAccess.getClassTypeRule()); 
            pushFollow(FOLLOW_ruleClassType_in_entryRuleClassType183);
            ruleClassType();

            state._fsp--;

             after(grammarAccess.getClassTypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleClassType190); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClassType"


    // $ANTLR start "ruleClassType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:127:1: ruleClassType : ( ( rule__ClassType__Group__0 ) ) ;
    public final void ruleClassType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:131:2: ( ( ( rule__ClassType__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:132:1: ( ( rule__ClassType__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:132:1: ( ( rule__ClassType__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:133:1: ( rule__ClassType__Group__0 )
            {
             before(grammarAccess.getClassTypeAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:134:1: ( rule__ClassType__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:134:2: rule__ClassType__Group__0
            {
            pushFollow(FOLLOW_rule__ClassType__Group__0_in_ruleClassType216);
            rule__ClassType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClassTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClassType"


    // $ANTLR start "entryRuleField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:146:1: entryRuleField : ruleField EOF ;
    public final void entryRuleField() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:147:1: ( ruleField EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:148:1: ruleField EOF
            {
             before(grammarAccess.getFieldRule()); 
            pushFollow(FOLLOW_ruleField_in_entryRuleField243);
            ruleField();

            state._fsp--;

             after(grammarAccess.getFieldRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleField250); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleField"


    // $ANTLR start "ruleField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:155:1: ruleField : ( ( rule__Field__Alternatives ) ) ;
    public final void ruleField() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:159:2: ( ( ( rule__Field__Alternatives ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:160:1: ( ( rule__Field__Alternatives ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:160:1: ( ( rule__Field__Alternatives ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:161:1: ( rule__Field__Alternatives )
            {
             before(grammarAccess.getFieldAccess().getAlternatives()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:162:1: ( rule__Field__Alternatives )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:162:2: rule__Field__Alternatives
            {
            pushFollow(FOLLOW_rule__Field__Alternatives_in_ruleField276);
            rule__Field__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getFieldAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleField"


    // $ANTLR start "entryRuleSimpleField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:174:1: entryRuleSimpleField : ruleSimpleField EOF ;
    public final void entryRuleSimpleField() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:175:1: ( ruleSimpleField EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:176:1: ruleSimpleField EOF
            {
             before(grammarAccess.getSimpleFieldRule()); 
            pushFollow(FOLLOW_ruleSimpleField_in_entryRuleSimpleField303);
            ruleSimpleField();

            state._fsp--;

             after(grammarAccess.getSimpleFieldRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSimpleField310); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSimpleField"


    // $ANTLR start "ruleSimpleField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:183:1: ruleSimpleField : ( ( rule__SimpleField__Group__0 ) ) ;
    public final void ruleSimpleField() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:187:2: ( ( ( rule__SimpleField__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:188:1: ( ( rule__SimpleField__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:188:1: ( ( rule__SimpleField__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:189:1: ( rule__SimpleField__Group__0 )
            {
             before(grammarAccess.getSimpleFieldAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:190:1: ( rule__SimpleField__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:190:2: rule__SimpleField__Group__0
            {
            pushFollow(FOLLOW_rule__SimpleField__Group__0_in_ruleSimpleField336);
            rule__SimpleField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSimpleFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSimpleField"


    // $ANTLR start "entryRuleListField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:202:1: entryRuleListField : ruleListField EOF ;
    public final void entryRuleListField() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:203:1: ( ruleListField EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:204:1: ruleListField EOF
            {
             before(grammarAccess.getListFieldRule()); 
            pushFollow(FOLLOW_ruleListField_in_entryRuleListField363);
            ruleListField();

            state._fsp--;

             after(grammarAccess.getListFieldRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleListField370); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleListField"


    // $ANTLR start "ruleListField"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:211:1: ruleListField : ( ( rule__ListField__Group__0 ) ) ;
    public final void ruleListField() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:215:2: ( ( ( rule__ListField__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:216:1: ( ( rule__ListField__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:216:1: ( ( rule__ListField__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:217:1: ( rule__ListField__Group__0 )
            {
             before(grammarAccess.getListFieldAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:218:1: ( rule__ListField__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:218:2: rule__ListField__Group__0
            {
            pushFollow(FOLLOW_rule__ListField__Group__0_in_ruleListField396);
            rule__ListField__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleListField"


    // $ANTLR start "entryRuleEnumType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:230:1: entryRuleEnumType : ruleEnumType EOF ;
    public final void entryRuleEnumType() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:231:1: ( ruleEnumType EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:232:1: ruleEnumType EOF
            {
             before(grammarAccess.getEnumTypeRule()); 
            pushFollow(FOLLOW_ruleEnumType_in_entryRuleEnumType423);
            ruleEnumType();

            state._fsp--;

             after(grammarAccess.getEnumTypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEnumType430); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnumType"


    // $ANTLR start "ruleEnumType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:239:1: ruleEnumType : ( ( rule__EnumType__Group__0 ) ) ;
    public final void ruleEnumType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:243:2: ( ( ( rule__EnumType__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:244:1: ( ( rule__EnumType__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:244:1: ( ( rule__EnumType__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:245:1: ( rule__EnumType__Group__0 )
            {
             before(grammarAccess.getEnumTypeAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:246:1: ( rule__EnumType__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:246:2: rule__EnumType__Group__0
            {
            pushFollow(FOLLOW_rule__EnumType__Group__0_in_ruleEnumType456);
            rule__EnumType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnumType"


    // $ANTLR start "entryRuleValue"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:258:1: entryRuleValue : ruleValue EOF ;
    public final void entryRuleValue() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:259:1: ( ruleValue EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:260:1: ruleValue EOF
            {
             before(grammarAccess.getValueRule()); 
            pushFollow(FOLLOW_ruleValue_in_entryRuleValue483);
            ruleValue();

            state._fsp--;

             after(grammarAccess.getValueRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleValue490); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleValue"


    // $ANTLR start "ruleValue"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:267:1: ruleValue : ( ( rule__Value__NameAssignment ) ) ;
    public final void ruleValue() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:271:2: ( ( ( rule__Value__NameAssignment ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:272:1: ( ( rule__Value__NameAssignment ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:272:1: ( ( rule__Value__NameAssignment ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:273:1: ( rule__Value__NameAssignment )
            {
             before(grammarAccess.getValueAccess().getNameAssignment()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:274:1: ( rule__Value__NameAssignment )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:274:2: rule__Value__NameAssignment
            {
            pushFollow(FOLLOW_rule__Value__NameAssignment_in_ruleValue516);
            rule__Value__NameAssignment();

            state._fsp--;


            }

             after(grammarAccess.getValueAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleValue"


    // $ANTLR start "entryRulePrimitiveType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:286:1: entryRulePrimitiveType : rulePrimitiveType EOF ;
    public final void entryRulePrimitiveType() throws RecognitionException {
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:287:1: ( rulePrimitiveType EOF )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:288:1: rulePrimitiveType EOF
            {
             before(grammarAccess.getPrimitiveTypeRule()); 
            pushFollow(FOLLOW_rulePrimitiveType_in_entryRulePrimitiveType543);
            rulePrimitiveType();

            state._fsp--;

             after(grammarAccess.getPrimitiveTypeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePrimitiveType550); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrimitiveType"


    // $ANTLR start "rulePrimitiveType"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:295:1: rulePrimitiveType : ( ( rule__PrimitiveType__Group__0 ) ) ;
    public final void rulePrimitiveType() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:299:2: ( ( ( rule__PrimitiveType__Group__0 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:300:1: ( ( rule__PrimitiveType__Group__0 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:300:1: ( ( rule__PrimitiveType__Group__0 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:301:1: ( rule__PrimitiveType__Group__0 )
            {
             before(grammarAccess.getPrimitiveTypeAccess().getGroup()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:302:1: ( rule__PrimitiveType__Group__0 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:302:2: rule__PrimitiveType__Group__0
            {
            pushFollow(FOLLOW_rule__PrimitiveType__Group__0_in_rulePrimitiveType576);
            rule__PrimitiveType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrimitiveType"


    // $ANTLR start "rule__Model__Alternatives_2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:314:1: rule__Model__Alternatives_2 : ( ( ( rule__Model__TypesAssignment_2_0 ) ) | ( ( rule__Model__TypesAssignment_2_1 ) ) | ( ( rule__Model__TypesAssignment_2_2 ) ) );
    public final void rule__Model__Alternatives_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:318:1: ( ( ( rule__Model__TypesAssignment_2_0 ) ) | ( ( rule__Model__TypesAssignment_2_1 ) ) | ( ( rule__Model__TypesAssignment_2_2 ) ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt1=1;
                }
                break;
            case 20:
                {
                alt1=2;
                }
                break;
            case 21:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:319:1: ( ( rule__Model__TypesAssignment_2_0 ) )
                    {
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:319:1: ( ( rule__Model__TypesAssignment_2_0 ) )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:320:1: ( rule__Model__TypesAssignment_2_0 )
                    {
                     before(grammarAccess.getModelAccess().getTypesAssignment_2_0()); 
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:321:1: ( rule__Model__TypesAssignment_2_0 )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:321:2: rule__Model__TypesAssignment_2_0
                    {
                    pushFollow(FOLLOW_rule__Model__TypesAssignment_2_0_in_rule__Model__Alternatives_2612);
                    rule__Model__TypesAssignment_2_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getTypesAssignment_2_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:325:6: ( ( rule__Model__TypesAssignment_2_1 ) )
                    {
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:325:6: ( ( rule__Model__TypesAssignment_2_1 ) )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:326:1: ( rule__Model__TypesAssignment_2_1 )
                    {
                     before(grammarAccess.getModelAccess().getTypesAssignment_2_1()); 
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:327:1: ( rule__Model__TypesAssignment_2_1 )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:327:2: rule__Model__TypesAssignment_2_1
                    {
                    pushFollow(FOLLOW_rule__Model__TypesAssignment_2_1_in_rule__Model__Alternatives_2630);
                    rule__Model__TypesAssignment_2_1();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getTypesAssignment_2_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:331:6: ( ( rule__Model__TypesAssignment_2_2 ) )
                    {
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:331:6: ( ( rule__Model__TypesAssignment_2_2 ) )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:332:1: ( rule__Model__TypesAssignment_2_2 )
                    {
                     before(grammarAccess.getModelAccess().getTypesAssignment_2_2()); 
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:333:1: ( rule__Model__TypesAssignment_2_2 )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:333:2: rule__Model__TypesAssignment_2_2
                    {
                    pushFollow(FOLLOW_rule__Model__TypesAssignment_2_2_in_rule__Model__Alternatives_2648);
                    rule__Model__TypesAssignment_2_2();

                    state._fsp--;


                    }

                     after(grammarAccess.getModelAccess().getTypesAssignment_2_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Alternatives_2"


    // $ANTLR start "rule__Field__Alternatives"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:343:1: rule__Field__Alternatives : ( ( ruleSimpleField ) | ( ruleListField ) );
    public final void rule__Field__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:347:1: ( ( ruleSimpleField ) | ( ruleListField ) )
            int alt2=2;
            switch ( input.LA(1) ) {
            case 22:
                {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==17) ) {
                    alt2=2;
                }
                else if ( (LA2_1==RULE_ID) ) {
                    alt2=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;
                }
                }
                break;
            case RULE_ID:
                {
                alt2=1;
                }
                break;
            case 17:
                {
                alt2=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:348:1: ( ruleSimpleField )
                    {
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:348:1: ( ruleSimpleField )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:349:1: ruleSimpleField
                    {
                     before(grammarAccess.getFieldAccess().getSimpleFieldParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleSimpleField_in_rule__Field__Alternatives682);
                    ruleSimpleField();

                    state._fsp--;

                     after(grammarAccess.getFieldAccess().getSimpleFieldParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:354:6: ( ruleListField )
                    {
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:354:6: ( ruleListField )
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:355:1: ruleListField
                    {
                     before(grammarAccess.getFieldAccess().getListFieldParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleListField_in_rule__Field__Alternatives699);
                    ruleListField();

                    state._fsp--;

                     after(grammarAccess.getFieldAccess().getListFieldParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Field__Alternatives"


    // $ANTLR start "rule__Model__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:367:1: rule__Model__Group__0 : rule__Model__Group__0__Impl rule__Model__Group__1 ;
    public final void rule__Model__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:371:1: ( rule__Model__Group__0__Impl rule__Model__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:372:2: rule__Model__Group__0__Impl rule__Model__Group__1
            {
            pushFollow(FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__0729);
            rule__Model__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__1_in_rule__Model__Group__0732);
            rule__Model__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0"


    // $ANTLR start "rule__Model__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:379:1: rule__Model__Group__0__Impl : ( 'package' ) ;
    public final void rule__Model__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:383:1: ( ( 'package' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:384:1: ( 'package' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:384:1: ( 'package' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:385:1: 'package'
            {
             before(grammarAccess.getModelAccess().getPackageKeyword_0()); 
            match(input,13,FOLLOW_13_in_rule__Model__Group__0__Impl760); 
             after(grammarAccess.getModelAccess().getPackageKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__0__Impl"


    // $ANTLR start "rule__Model__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:398:1: rule__Model__Group__1 : rule__Model__Group__1__Impl rule__Model__Group__2 ;
    public final void rule__Model__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:402:1: ( rule__Model__Group__1__Impl rule__Model__Group__2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:403:2: rule__Model__Group__1__Impl rule__Model__Group__2
            {
            pushFollow(FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__1791);
            rule__Model__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Model__Group__2_in_rule__Model__Group__1794);
            rule__Model__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1"


    // $ANTLR start "rule__Model__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:410:1: rule__Model__Group__1__Impl : ( ( rule__Model__PackageNameAssignment_1 ) ) ;
    public final void rule__Model__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:414:1: ( ( ( rule__Model__PackageNameAssignment_1 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:415:1: ( ( rule__Model__PackageNameAssignment_1 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:415:1: ( ( rule__Model__PackageNameAssignment_1 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:416:1: ( rule__Model__PackageNameAssignment_1 )
            {
             before(grammarAccess.getModelAccess().getPackageNameAssignment_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:417:1: ( rule__Model__PackageNameAssignment_1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:417:2: rule__Model__PackageNameAssignment_1
            {
            pushFollow(FOLLOW_rule__Model__PackageNameAssignment_1_in_rule__Model__Group__1__Impl821);
            rule__Model__PackageNameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getPackageNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__1__Impl"


    // $ANTLR start "rule__Model__Group__2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:427:1: rule__Model__Group__2 : rule__Model__Group__2__Impl ;
    public final void rule__Model__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:431:1: ( rule__Model__Group__2__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:432:2: rule__Model__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Model__Group__2__Impl_in_rule__Model__Group__2851);
            rule__Model__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2"


    // $ANTLR start "rule__Model__Group__2__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:438:1: rule__Model__Group__2__Impl : ( ( ( rule__Model__Alternatives_2 ) ) ( ( rule__Model__Alternatives_2 )* ) ) ;
    public final void rule__Model__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:442:1: ( ( ( ( rule__Model__Alternatives_2 ) ) ( ( rule__Model__Alternatives_2 )* ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:443:1: ( ( ( rule__Model__Alternatives_2 ) ) ( ( rule__Model__Alternatives_2 )* ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:443:1: ( ( ( rule__Model__Alternatives_2 ) ) ( ( rule__Model__Alternatives_2 )* ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:444:1: ( ( rule__Model__Alternatives_2 ) ) ( ( rule__Model__Alternatives_2 )* )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:444:1: ( ( rule__Model__Alternatives_2 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:445:1: ( rule__Model__Alternatives_2 )
            {
             before(grammarAccess.getModelAccess().getAlternatives_2()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:446:1: ( rule__Model__Alternatives_2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:446:2: rule__Model__Alternatives_2
            {
            pushFollow(FOLLOW_rule__Model__Alternatives_2_in_rule__Model__Group__2__Impl880);
            rule__Model__Alternatives_2();

            state._fsp--;


            }

             after(grammarAccess.getModelAccess().getAlternatives_2()); 

            }

            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:449:1: ( ( rule__Model__Alternatives_2 )* )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:450:1: ( rule__Model__Alternatives_2 )*
            {
             before(grammarAccess.getModelAccess().getAlternatives_2()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:451:1: ( rule__Model__Alternatives_2 )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==15||(LA3_0>=20 && LA3_0<=21)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:451:2: rule__Model__Alternatives_2
            	    {
            	    pushFollow(FOLLOW_rule__Model__Alternatives_2_in_rule__Model__Group__2__Impl892);
            	    rule__Model__Alternatives_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

             after(grammarAccess.getModelAccess().getAlternatives_2()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__Group__2__Impl"


    // $ANTLR start "rule__FQN__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:468:1: rule__FQN__Group__0 : rule__FQN__Group__0__Impl rule__FQN__Group__1 ;
    public final void rule__FQN__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:472:1: ( rule__FQN__Group__0__Impl rule__FQN__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:473:2: rule__FQN__Group__0__Impl rule__FQN__Group__1
            {
            pushFollow(FOLLOW_rule__FQN__Group__0__Impl_in_rule__FQN__Group__0931);
            rule__FQN__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FQN__Group__1_in_rule__FQN__Group__0934);
            rule__FQN__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group__0"


    // $ANTLR start "rule__FQN__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:480:1: rule__FQN__Group__0__Impl : ( RULE_ID ) ;
    public final void rule__FQN__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:484:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:485:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:485:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:486:1: RULE_ID
            {
             before(grammarAccess.getFQNAccess().getIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FQN__Group__0__Impl961); 
             after(grammarAccess.getFQNAccess().getIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group__0__Impl"


    // $ANTLR start "rule__FQN__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:497:1: rule__FQN__Group__1 : rule__FQN__Group__1__Impl ;
    public final void rule__FQN__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:501:1: ( rule__FQN__Group__1__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:502:2: rule__FQN__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__FQN__Group__1__Impl_in_rule__FQN__Group__1990);
            rule__FQN__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group__1"


    // $ANTLR start "rule__FQN__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:508:1: rule__FQN__Group__1__Impl : ( ( rule__FQN__Group_1__0 )* ) ;
    public final void rule__FQN__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:512:1: ( ( ( rule__FQN__Group_1__0 )* ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:513:1: ( ( rule__FQN__Group_1__0 )* )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:513:1: ( ( rule__FQN__Group_1__0 )* )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:514:1: ( rule__FQN__Group_1__0 )*
            {
             before(grammarAccess.getFQNAccess().getGroup_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:515:1: ( rule__FQN__Group_1__0 )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==14) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:515:2: rule__FQN__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__FQN__Group_1__0_in_rule__FQN__Group__1__Impl1017);
            	    rule__FQN__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

             after(grammarAccess.getFQNAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group__1__Impl"


    // $ANTLR start "rule__FQN__Group_1__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:529:1: rule__FQN__Group_1__0 : rule__FQN__Group_1__0__Impl rule__FQN__Group_1__1 ;
    public final void rule__FQN__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:533:1: ( rule__FQN__Group_1__0__Impl rule__FQN__Group_1__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:534:2: rule__FQN__Group_1__0__Impl rule__FQN__Group_1__1
            {
            pushFollow(FOLLOW_rule__FQN__Group_1__0__Impl_in_rule__FQN__Group_1__01052);
            rule__FQN__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FQN__Group_1__1_in_rule__FQN__Group_1__01055);
            rule__FQN__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group_1__0"


    // $ANTLR start "rule__FQN__Group_1__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:541:1: rule__FQN__Group_1__0__Impl : ( '.' ) ;
    public final void rule__FQN__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:545:1: ( ( '.' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:546:1: ( '.' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:546:1: ( '.' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:547:1: '.'
            {
             before(grammarAccess.getFQNAccess().getFullStopKeyword_1_0()); 
            match(input,14,FOLLOW_14_in_rule__FQN__Group_1__0__Impl1083); 
             after(grammarAccess.getFQNAccess().getFullStopKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group_1__0__Impl"


    // $ANTLR start "rule__FQN__Group_1__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:560:1: rule__FQN__Group_1__1 : rule__FQN__Group_1__1__Impl ;
    public final void rule__FQN__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:564:1: ( rule__FQN__Group_1__1__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:565:2: rule__FQN__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__FQN__Group_1__1__Impl_in_rule__FQN__Group_1__11114);
            rule__FQN__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group_1__1"


    // $ANTLR start "rule__FQN__Group_1__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:571:1: rule__FQN__Group_1__1__Impl : ( RULE_ID ) ;
    public final void rule__FQN__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:575:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:576:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:576:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:577:1: RULE_ID
            {
             before(grammarAccess.getFQNAccess().getIDTerminalRuleCall_1_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FQN__Group_1__1__Impl1141); 
             after(grammarAccess.getFQNAccess().getIDTerminalRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FQN__Group_1__1__Impl"


    // $ANTLR start "rule__ClassType__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:592:1: rule__ClassType__Group__0 : rule__ClassType__Group__0__Impl rule__ClassType__Group__1 ;
    public final void rule__ClassType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:596:1: ( rule__ClassType__Group__0__Impl rule__ClassType__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:597:2: rule__ClassType__Group__0__Impl rule__ClassType__Group__1
            {
            pushFollow(FOLLOW_rule__ClassType__Group__0__Impl_in_rule__ClassType__Group__01174);
            rule__ClassType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ClassType__Group__1_in_rule__ClassType__Group__01177);
            rule__ClassType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__0"


    // $ANTLR start "rule__ClassType__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:604:1: rule__ClassType__Group__0__Impl : ( 'class' ) ;
    public final void rule__ClassType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:608:1: ( ( 'class' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:609:1: ( 'class' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:609:1: ( 'class' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:610:1: 'class'
            {
             before(grammarAccess.getClassTypeAccess().getClassKeyword_0()); 
            match(input,15,FOLLOW_15_in_rule__ClassType__Group__0__Impl1205); 
             after(grammarAccess.getClassTypeAccess().getClassKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__0__Impl"


    // $ANTLR start "rule__ClassType__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:623:1: rule__ClassType__Group__1 : rule__ClassType__Group__1__Impl rule__ClassType__Group__2 ;
    public final void rule__ClassType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:627:1: ( rule__ClassType__Group__1__Impl rule__ClassType__Group__2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:628:2: rule__ClassType__Group__1__Impl rule__ClassType__Group__2
            {
            pushFollow(FOLLOW_rule__ClassType__Group__1__Impl_in_rule__ClassType__Group__11236);
            rule__ClassType__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ClassType__Group__2_in_rule__ClassType__Group__11239);
            rule__ClassType__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__1"


    // $ANTLR start "rule__ClassType__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:635:1: rule__ClassType__Group__1__Impl : ( ( rule__ClassType__NameAssignment_1 ) ) ;
    public final void rule__ClassType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:639:1: ( ( ( rule__ClassType__NameAssignment_1 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:640:1: ( ( rule__ClassType__NameAssignment_1 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:640:1: ( ( rule__ClassType__NameAssignment_1 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:641:1: ( rule__ClassType__NameAssignment_1 )
            {
             before(grammarAccess.getClassTypeAccess().getNameAssignment_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:642:1: ( rule__ClassType__NameAssignment_1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:642:2: rule__ClassType__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__ClassType__NameAssignment_1_in_rule__ClassType__Group__1__Impl1266);
            rule__ClassType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClassTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__1__Impl"


    // $ANTLR start "rule__ClassType__Group__2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:652:1: rule__ClassType__Group__2 : rule__ClassType__Group__2__Impl rule__ClassType__Group__3 ;
    public final void rule__ClassType__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:656:1: ( rule__ClassType__Group__2__Impl rule__ClassType__Group__3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:657:2: rule__ClassType__Group__2__Impl rule__ClassType__Group__3
            {
            pushFollow(FOLLOW_rule__ClassType__Group__2__Impl_in_rule__ClassType__Group__21296);
            rule__ClassType__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ClassType__Group__3_in_rule__ClassType__Group__21299);
            rule__ClassType__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__2"


    // $ANTLR start "rule__ClassType__Group__2__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:664:1: rule__ClassType__Group__2__Impl : ( RULE_LBRACE ) ;
    public final void rule__ClassType__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:668:1: ( ( RULE_LBRACE ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:669:1: ( RULE_LBRACE )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:669:1: ( RULE_LBRACE )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:670:1: RULE_LBRACE
            {
             before(grammarAccess.getClassTypeAccess().getLBRACETerminalRuleCall_2()); 
            match(input,RULE_LBRACE,FOLLOW_RULE_LBRACE_in_rule__ClassType__Group__2__Impl1326); 
             after(grammarAccess.getClassTypeAccess().getLBRACETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__2__Impl"


    // $ANTLR start "rule__ClassType__Group__3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:681:1: rule__ClassType__Group__3 : rule__ClassType__Group__3__Impl rule__ClassType__Group__4 ;
    public final void rule__ClassType__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:685:1: ( rule__ClassType__Group__3__Impl rule__ClassType__Group__4 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:686:2: rule__ClassType__Group__3__Impl rule__ClassType__Group__4
            {
            pushFollow(FOLLOW_rule__ClassType__Group__3__Impl_in_rule__ClassType__Group__31355);
            rule__ClassType__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ClassType__Group__4_in_rule__ClassType__Group__31358);
            rule__ClassType__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__3"


    // $ANTLR start "rule__ClassType__Group__3__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:693:1: rule__ClassType__Group__3__Impl : ( ( rule__ClassType__FieldsAssignment_3 )* ) ;
    public final void rule__ClassType__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:697:1: ( ( ( rule__ClassType__FieldsAssignment_3 )* ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:698:1: ( ( rule__ClassType__FieldsAssignment_3 )* )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:698:1: ( ( rule__ClassType__FieldsAssignment_3 )* )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:699:1: ( rule__ClassType__FieldsAssignment_3 )*
            {
             before(grammarAccess.getClassTypeAccess().getFieldsAssignment_3()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:700:1: ( rule__ClassType__FieldsAssignment_3 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID||LA5_0==17||LA5_0==22) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:700:2: rule__ClassType__FieldsAssignment_3
            	    {
            	    pushFollow(FOLLOW_rule__ClassType__FieldsAssignment_3_in_rule__ClassType__Group__3__Impl1385);
            	    rule__ClassType__FieldsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getClassTypeAccess().getFieldsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__3__Impl"


    // $ANTLR start "rule__ClassType__Group__4"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:710:1: rule__ClassType__Group__4 : rule__ClassType__Group__4__Impl ;
    public final void rule__ClassType__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:714:1: ( rule__ClassType__Group__4__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:715:2: rule__ClassType__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__ClassType__Group__4__Impl_in_rule__ClassType__Group__41416);
            rule__ClassType__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__4"


    // $ANTLR start "rule__ClassType__Group__4__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:721:1: rule__ClassType__Group__4__Impl : ( RULE_RBRACE ) ;
    public final void rule__ClassType__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:725:1: ( ( RULE_RBRACE ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:726:1: ( RULE_RBRACE )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:726:1: ( RULE_RBRACE )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:727:1: RULE_RBRACE
            {
             before(grammarAccess.getClassTypeAccess().getRBRACETerminalRuleCall_4()); 
            match(input,RULE_RBRACE,FOLLOW_RULE_RBRACE_in_rule__ClassType__Group__4__Impl1443); 
             after(grammarAccess.getClassTypeAccess().getRBRACETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__Group__4__Impl"


    // $ANTLR start "rule__SimpleField__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:748:1: rule__SimpleField__Group__0 : rule__SimpleField__Group__0__Impl rule__SimpleField__Group__1 ;
    public final void rule__SimpleField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:752:1: ( rule__SimpleField__Group__0__Impl rule__SimpleField__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:753:2: rule__SimpleField__Group__0__Impl rule__SimpleField__Group__1
            {
            pushFollow(FOLLOW_rule__SimpleField__Group__0__Impl_in_rule__SimpleField__Group__01482);
            rule__SimpleField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__SimpleField__Group__1_in_rule__SimpleField__Group__01485);
            rule__SimpleField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__0"


    // $ANTLR start "rule__SimpleField__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:760:1: rule__SimpleField__Group__0__Impl : ( ( rule__SimpleField__BoundAssignment_0 )? ) ;
    public final void rule__SimpleField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:764:1: ( ( ( rule__SimpleField__BoundAssignment_0 )? ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:765:1: ( ( rule__SimpleField__BoundAssignment_0 )? )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:765:1: ( ( rule__SimpleField__BoundAssignment_0 )? )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:766:1: ( rule__SimpleField__BoundAssignment_0 )?
            {
             before(grammarAccess.getSimpleFieldAccess().getBoundAssignment_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:767:1: ( rule__SimpleField__BoundAssignment_0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==22) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:767:2: rule__SimpleField__BoundAssignment_0
                    {
                    pushFollow(FOLLOW_rule__SimpleField__BoundAssignment_0_in_rule__SimpleField__Group__0__Impl1512);
                    rule__SimpleField__BoundAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSimpleFieldAccess().getBoundAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__0__Impl"


    // $ANTLR start "rule__SimpleField__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:777:1: rule__SimpleField__Group__1 : rule__SimpleField__Group__1__Impl rule__SimpleField__Group__2 ;
    public final void rule__SimpleField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:781:1: ( rule__SimpleField__Group__1__Impl rule__SimpleField__Group__2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:782:2: rule__SimpleField__Group__1__Impl rule__SimpleField__Group__2
            {
            pushFollow(FOLLOW_rule__SimpleField__Group__1__Impl_in_rule__SimpleField__Group__11543);
            rule__SimpleField__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__SimpleField__Group__2_in_rule__SimpleField__Group__11546);
            rule__SimpleField__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__1"


    // $ANTLR start "rule__SimpleField__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:789:1: rule__SimpleField__Group__1__Impl : ( ( rule__SimpleField__TypeAssignment_1 ) ) ;
    public final void rule__SimpleField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:793:1: ( ( ( rule__SimpleField__TypeAssignment_1 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:794:1: ( ( rule__SimpleField__TypeAssignment_1 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:794:1: ( ( rule__SimpleField__TypeAssignment_1 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:795:1: ( rule__SimpleField__TypeAssignment_1 )
            {
             before(grammarAccess.getSimpleFieldAccess().getTypeAssignment_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:796:1: ( rule__SimpleField__TypeAssignment_1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:796:2: rule__SimpleField__TypeAssignment_1
            {
            pushFollow(FOLLOW_rule__SimpleField__TypeAssignment_1_in_rule__SimpleField__Group__1__Impl1573);
            rule__SimpleField__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getSimpleFieldAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__1__Impl"


    // $ANTLR start "rule__SimpleField__Group__2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:806:1: rule__SimpleField__Group__2 : rule__SimpleField__Group__2__Impl rule__SimpleField__Group__3 ;
    public final void rule__SimpleField__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:810:1: ( rule__SimpleField__Group__2__Impl rule__SimpleField__Group__3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:811:2: rule__SimpleField__Group__2__Impl rule__SimpleField__Group__3
            {
            pushFollow(FOLLOW_rule__SimpleField__Group__2__Impl_in_rule__SimpleField__Group__21603);
            rule__SimpleField__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__SimpleField__Group__3_in_rule__SimpleField__Group__21606);
            rule__SimpleField__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__2"


    // $ANTLR start "rule__SimpleField__Group__2__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:818:1: rule__SimpleField__Group__2__Impl : ( ( rule__SimpleField__NameAssignment_2 ) ) ;
    public final void rule__SimpleField__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:822:1: ( ( ( rule__SimpleField__NameAssignment_2 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:823:1: ( ( rule__SimpleField__NameAssignment_2 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:823:1: ( ( rule__SimpleField__NameAssignment_2 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:824:1: ( rule__SimpleField__NameAssignment_2 )
            {
             before(grammarAccess.getSimpleFieldAccess().getNameAssignment_2()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:825:1: ( rule__SimpleField__NameAssignment_2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:825:2: rule__SimpleField__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__SimpleField__NameAssignment_2_in_rule__SimpleField__Group__2__Impl1633);
            rule__SimpleField__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSimpleFieldAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__2__Impl"


    // $ANTLR start "rule__SimpleField__Group__3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:835:1: rule__SimpleField__Group__3 : rule__SimpleField__Group__3__Impl ;
    public final void rule__SimpleField__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:839:1: ( rule__SimpleField__Group__3__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:840:2: rule__SimpleField__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__SimpleField__Group__3__Impl_in_rule__SimpleField__Group__31663);
            rule__SimpleField__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__3"


    // $ANTLR start "rule__SimpleField__Group__3__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:846:1: rule__SimpleField__Group__3__Impl : ( ';' ) ;
    public final void rule__SimpleField__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:850:1: ( ( ';' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:851:1: ( ';' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:851:1: ( ';' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:852:1: ';'
            {
             before(grammarAccess.getSimpleFieldAccess().getSemicolonKeyword_3()); 
            match(input,16,FOLLOW_16_in_rule__SimpleField__Group__3__Impl1691); 
             after(grammarAccess.getSimpleFieldAccess().getSemicolonKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__Group__3__Impl"


    // $ANTLR start "rule__ListField__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:873:1: rule__ListField__Group__0 : rule__ListField__Group__0__Impl rule__ListField__Group__1 ;
    public final void rule__ListField__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:877:1: ( rule__ListField__Group__0__Impl rule__ListField__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:878:2: rule__ListField__Group__0__Impl rule__ListField__Group__1
            {
            pushFollow(FOLLOW_rule__ListField__Group__0__Impl_in_rule__ListField__Group__01730);
            rule__ListField__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__1_in_rule__ListField__Group__01733);
            rule__ListField__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__0"


    // $ANTLR start "rule__ListField__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:885:1: rule__ListField__Group__0__Impl : ( ( rule__ListField__BoundAssignment_0 )? ) ;
    public final void rule__ListField__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:889:1: ( ( ( rule__ListField__BoundAssignment_0 )? ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:890:1: ( ( rule__ListField__BoundAssignment_0 )? )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:890:1: ( ( rule__ListField__BoundAssignment_0 )? )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:891:1: ( rule__ListField__BoundAssignment_0 )?
            {
             before(grammarAccess.getListFieldAccess().getBoundAssignment_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:892:1: ( rule__ListField__BoundAssignment_0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==22) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:892:2: rule__ListField__BoundAssignment_0
                    {
                    pushFollow(FOLLOW_rule__ListField__BoundAssignment_0_in_rule__ListField__Group__0__Impl1760);
                    rule__ListField__BoundAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getListFieldAccess().getBoundAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__0__Impl"


    // $ANTLR start "rule__ListField__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:902:1: rule__ListField__Group__1 : rule__ListField__Group__1__Impl rule__ListField__Group__2 ;
    public final void rule__ListField__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:906:1: ( rule__ListField__Group__1__Impl rule__ListField__Group__2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:907:2: rule__ListField__Group__1__Impl rule__ListField__Group__2
            {
            pushFollow(FOLLOW_rule__ListField__Group__1__Impl_in_rule__ListField__Group__11791);
            rule__ListField__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__2_in_rule__ListField__Group__11794);
            rule__ListField__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__1"


    // $ANTLR start "rule__ListField__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:914:1: rule__ListField__Group__1__Impl : ( 'List' ) ;
    public final void rule__ListField__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:918:1: ( ( 'List' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:919:1: ( 'List' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:919:1: ( 'List' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:920:1: 'List'
            {
             before(grammarAccess.getListFieldAccess().getListKeyword_1()); 
            match(input,17,FOLLOW_17_in_rule__ListField__Group__1__Impl1822); 
             after(grammarAccess.getListFieldAccess().getListKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__1__Impl"


    // $ANTLR start "rule__ListField__Group__2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:933:1: rule__ListField__Group__2 : rule__ListField__Group__2__Impl rule__ListField__Group__3 ;
    public final void rule__ListField__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:937:1: ( rule__ListField__Group__2__Impl rule__ListField__Group__3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:938:2: rule__ListField__Group__2__Impl rule__ListField__Group__3
            {
            pushFollow(FOLLOW_rule__ListField__Group__2__Impl_in_rule__ListField__Group__21853);
            rule__ListField__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__3_in_rule__ListField__Group__21856);
            rule__ListField__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__2"


    // $ANTLR start "rule__ListField__Group__2__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:945:1: rule__ListField__Group__2__Impl : ( '<' ) ;
    public final void rule__ListField__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:949:1: ( ( '<' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:950:1: ( '<' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:950:1: ( '<' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:951:1: '<'
            {
             before(grammarAccess.getListFieldAccess().getLessThanSignKeyword_2()); 
            match(input,18,FOLLOW_18_in_rule__ListField__Group__2__Impl1884); 
             after(grammarAccess.getListFieldAccess().getLessThanSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__2__Impl"


    // $ANTLR start "rule__ListField__Group__3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:964:1: rule__ListField__Group__3 : rule__ListField__Group__3__Impl rule__ListField__Group__4 ;
    public final void rule__ListField__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:968:1: ( rule__ListField__Group__3__Impl rule__ListField__Group__4 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:969:2: rule__ListField__Group__3__Impl rule__ListField__Group__4
            {
            pushFollow(FOLLOW_rule__ListField__Group__3__Impl_in_rule__ListField__Group__31915);
            rule__ListField__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__4_in_rule__ListField__Group__31918);
            rule__ListField__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__3"


    // $ANTLR start "rule__ListField__Group__3__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:976:1: rule__ListField__Group__3__Impl : ( ( rule__ListField__TypeAssignment_3 ) ) ;
    public final void rule__ListField__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:980:1: ( ( ( rule__ListField__TypeAssignment_3 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:981:1: ( ( rule__ListField__TypeAssignment_3 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:981:1: ( ( rule__ListField__TypeAssignment_3 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:982:1: ( rule__ListField__TypeAssignment_3 )
            {
             before(grammarAccess.getListFieldAccess().getTypeAssignment_3()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:983:1: ( rule__ListField__TypeAssignment_3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:983:2: rule__ListField__TypeAssignment_3
            {
            pushFollow(FOLLOW_rule__ListField__TypeAssignment_3_in_rule__ListField__Group__3__Impl1945);
            rule__ListField__TypeAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getTypeAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__3__Impl"


    // $ANTLR start "rule__ListField__Group__4"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:993:1: rule__ListField__Group__4 : rule__ListField__Group__4__Impl rule__ListField__Group__5 ;
    public final void rule__ListField__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:997:1: ( rule__ListField__Group__4__Impl rule__ListField__Group__5 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:998:2: rule__ListField__Group__4__Impl rule__ListField__Group__5
            {
            pushFollow(FOLLOW_rule__ListField__Group__4__Impl_in_rule__ListField__Group__41975);
            rule__ListField__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__5_in_rule__ListField__Group__41978);
            rule__ListField__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__4"


    // $ANTLR start "rule__ListField__Group__4__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1005:1: rule__ListField__Group__4__Impl : ( '>' ) ;
    public final void rule__ListField__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1009:1: ( ( '>' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1010:1: ( '>' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1010:1: ( '>' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1011:1: '>'
            {
             before(grammarAccess.getListFieldAccess().getGreaterThanSignKeyword_4()); 
            match(input,19,FOLLOW_19_in_rule__ListField__Group__4__Impl2006); 
             after(grammarAccess.getListFieldAccess().getGreaterThanSignKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__4__Impl"


    // $ANTLR start "rule__ListField__Group__5"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1024:1: rule__ListField__Group__5 : rule__ListField__Group__5__Impl rule__ListField__Group__6 ;
    public final void rule__ListField__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1028:1: ( rule__ListField__Group__5__Impl rule__ListField__Group__6 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1029:2: rule__ListField__Group__5__Impl rule__ListField__Group__6
            {
            pushFollow(FOLLOW_rule__ListField__Group__5__Impl_in_rule__ListField__Group__52037);
            rule__ListField__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ListField__Group__6_in_rule__ListField__Group__52040);
            rule__ListField__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__5"


    // $ANTLR start "rule__ListField__Group__5__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1036:1: rule__ListField__Group__5__Impl : ( ( rule__ListField__NameAssignment_5 ) ) ;
    public final void rule__ListField__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1040:1: ( ( ( rule__ListField__NameAssignment_5 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1041:1: ( ( rule__ListField__NameAssignment_5 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1041:1: ( ( rule__ListField__NameAssignment_5 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1042:1: ( rule__ListField__NameAssignment_5 )
            {
             before(grammarAccess.getListFieldAccess().getNameAssignment_5()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1043:1: ( rule__ListField__NameAssignment_5 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1043:2: rule__ListField__NameAssignment_5
            {
            pushFollow(FOLLOW_rule__ListField__NameAssignment_5_in_rule__ListField__Group__5__Impl2067);
            rule__ListField__NameAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getListFieldAccess().getNameAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__5__Impl"


    // $ANTLR start "rule__ListField__Group__6"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1053:1: rule__ListField__Group__6 : rule__ListField__Group__6__Impl ;
    public final void rule__ListField__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1057:1: ( rule__ListField__Group__6__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1058:2: rule__ListField__Group__6__Impl
            {
            pushFollow(FOLLOW_rule__ListField__Group__6__Impl_in_rule__ListField__Group__62097);
            rule__ListField__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__6"


    // $ANTLR start "rule__ListField__Group__6__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1064:1: rule__ListField__Group__6__Impl : ( ';' ) ;
    public final void rule__ListField__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1068:1: ( ( ';' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1069:1: ( ';' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1069:1: ( ';' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1070:1: ';'
            {
             before(grammarAccess.getListFieldAccess().getSemicolonKeyword_6()); 
            match(input,16,FOLLOW_16_in_rule__ListField__Group__6__Impl2125); 
             after(grammarAccess.getListFieldAccess().getSemicolonKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__Group__6__Impl"


    // $ANTLR start "rule__EnumType__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1097:1: rule__EnumType__Group__0 : rule__EnumType__Group__0__Impl rule__EnumType__Group__1 ;
    public final void rule__EnumType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1101:1: ( rule__EnumType__Group__0__Impl rule__EnumType__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1102:2: rule__EnumType__Group__0__Impl rule__EnumType__Group__1
            {
            pushFollow(FOLLOW_rule__EnumType__Group__0__Impl_in_rule__EnumType__Group__02170);
            rule__EnumType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EnumType__Group__1_in_rule__EnumType__Group__02173);
            rule__EnumType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__0"


    // $ANTLR start "rule__EnumType__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1109:1: rule__EnumType__Group__0__Impl : ( 'enum' ) ;
    public final void rule__EnumType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1113:1: ( ( 'enum' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1114:1: ( 'enum' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1114:1: ( 'enum' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1115:1: 'enum'
            {
             before(grammarAccess.getEnumTypeAccess().getEnumKeyword_0()); 
            match(input,20,FOLLOW_20_in_rule__EnumType__Group__0__Impl2201); 
             after(grammarAccess.getEnumTypeAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__0__Impl"


    // $ANTLR start "rule__EnumType__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1128:1: rule__EnumType__Group__1 : rule__EnumType__Group__1__Impl rule__EnumType__Group__2 ;
    public final void rule__EnumType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1132:1: ( rule__EnumType__Group__1__Impl rule__EnumType__Group__2 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1133:2: rule__EnumType__Group__1__Impl rule__EnumType__Group__2
            {
            pushFollow(FOLLOW_rule__EnumType__Group__1__Impl_in_rule__EnumType__Group__12232);
            rule__EnumType__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EnumType__Group__2_in_rule__EnumType__Group__12235);
            rule__EnumType__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__1"


    // $ANTLR start "rule__EnumType__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1140:1: rule__EnumType__Group__1__Impl : ( ( rule__EnumType__NameAssignment_1 ) ) ;
    public final void rule__EnumType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1144:1: ( ( ( rule__EnumType__NameAssignment_1 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1145:1: ( ( rule__EnumType__NameAssignment_1 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1145:1: ( ( rule__EnumType__NameAssignment_1 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1146:1: ( rule__EnumType__NameAssignment_1 )
            {
             before(grammarAccess.getEnumTypeAccess().getNameAssignment_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1147:1: ( rule__EnumType__NameAssignment_1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1147:2: rule__EnumType__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__EnumType__NameAssignment_1_in_rule__EnumType__Group__1__Impl2262);
            rule__EnumType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__1__Impl"


    // $ANTLR start "rule__EnumType__Group__2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1157:1: rule__EnumType__Group__2 : rule__EnumType__Group__2__Impl rule__EnumType__Group__3 ;
    public final void rule__EnumType__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1161:1: ( rule__EnumType__Group__2__Impl rule__EnumType__Group__3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1162:2: rule__EnumType__Group__2__Impl rule__EnumType__Group__3
            {
            pushFollow(FOLLOW_rule__EnumType__Group__2__Impl_in_rule__EnumType__Group__22292);
            rule__EnumType__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EnumType__Group__3_in_rule__EnumType__Group__22295);
            rule__EnumType__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__2"


    // $ANTLR start "rule__EnumType__Group__2__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1169:1: rule__EnumType__Group__2__Impl : ( RULE_LBRACE ) ;
    public final void rule__EnumType__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1173:1: ( ( RULE_LBRACE ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1174:1: ( RULE_LBRACE )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1174:1: ( RULE_LBRACE )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1175:1: RULE_LBRACE
            {
             before(grammarAccess.getEnumTypeAccess().getLBRACETerminalRuleCall_2()); 
            match(input,RULE_LBRACE,FOLLOW_RULE_LBRACE_in_rule__EnumType__Group__2__Impl2322); 
             after(grammarAccess.getEnumTypeAccess().getLBRACETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__2__Impl"


    // $ANTLR start "rule__EnumType__Group__3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1186:1: rule__EnumType__Group__3 : rule__EnumType__Group__3__Impl rule__EnumType__Group__4 ;
    public final void rule__EnumType__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1190:1: ( rule__EnumType__Group__3__Impl rule__EnumType__Group__4 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1191:2: rule__EnumType__Group__3__Impl rule__EnumType__Group__4
            {
            pushFollow(FOLLOW_rule__EnumType__Group__3__Impl_in_rule__EnumType__Group__32351);
            rule__EnumType__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__EnumType__Group__4_in_rule__EnumType__Group__32354);
            rule__EnumType__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__3"


    // $ANTLR start "rule__EnumType__Group__3__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1198:1: rule__EnumType__Group__3__Impl : ( ( ( rule__EnumType__ValuesAssignment_3 ) ) ( ( rule__EnumType__ValuesAssignment_3 )* ) ) ;
    public final void rule__EnumType__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1202:1: ( ( ( ( rule__EnumType__ValuesAssignment_3 ) ) ( ( rule__EnumType__ValuesAssignment_3 )* ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1203:1: ( ( ( rule__EnumType__ValuesAssignment_3 ) ) ( ( rule__EnumType__ValuesAssignment_3 )* ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1203:1: ( ( ( rule__EnumType__ValuesAssignment_3 ) ) ( ( rule__EnumType__ValuesAssignment_3 )* ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1204:1: ( ( rule__EnumType__ValuesAssignment_3 ) ) ( ( rule__EnumType__ValuesAssignment_3 )* )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1204:1: ( ( rule__EnumType__ValuesAssignment_3 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1205:1: ( rule__EnumType__ValuesAssignment_3 )
            {
             before(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1206:1: ( rule__EnumType__ValuesAssignment_3 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1206:2: rule__EnumType__ValuesAssignment_3
            {
            pushFollow(FOLLOW_rule__EnumType__ValuesAssignment_3_in_rule__EnumType__Group__3__Impl2383);
            rule__EnumType__ValuesAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 

            }

            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1209:1: ( ( rule__EnumType__ValuesAssignment_3 )* )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1210:1: ( rule__EnumType__ValuesAssignment_3 )*
            {
             before(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1211:1: ( rule__EnumType__ValuesAssignment_3 )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==RULE_ID) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1211:2: rule__EnumType__ValuesAssignment_3
            	    {
            	    pushFollow(FOLLOW_rule__EnumType__ValuesAssignment_3_in_rule__EnumType__Group__3__Impl2395);
            	    rule__EnumType__ValuesAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

             after(grammarAccess.getEnumTypeAccess().getValuesAssignment_3()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__3__Impl"


    // $ANTLR start "rule__EnumType__Group__4"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1222:1: rule__EnumType__Group__4 : rule__EnumType__Group__4__Impl ;
    public final void rule__EnumType__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1226:1: ( rule__EnumType__Group__4__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1227:2: rule__EnumType__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__EnumType__Group__4__Impl_in_rule__EnumType__Group__42428);
            rule__EnumType__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__4"


    // $ANTLR start "rule__EnumType__Group__4__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1233:1: rule__EnumType__Group__4__Impl : ( RULE_RBRACE ) ;
    public final void rule__EnumType__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1237:1: ( ( RULE_RBRACE ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1238:1: ( RULE_RBRACE )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1238:1: ( RULE_RBRACE )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1239:1: RULE_RBRACE
            {
             before(grammarAccess.getEnumTypeAccess().getRBRACETerminalRuleCall_4()); 
            match(input,RULE_RBRACE,FOLLOW_RULE_RBRACE_in_rule__EnumType__Group__4__Impl2455); 
             after(grammarAccess.getEnumTypeAccess().getRBRACETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__Group__4__Impl"


    // $ANTLR start "rule__PrimitiveType__Group__0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1260:1: rule__PrimitiveType__Group__0 : rule__PrimitiveType__Group__0__Impl rule__PrimitiveType__Group__1 ;
    public final void rule__PrimitiveType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1264:1: ( rule__PrimitiveType__Group__0__Impl rule__PrimitiveType__Group__1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1265:2: rule__PrimitiveType__Group__0__Impl rule__PrimitiveType__Group__1
            {
            pushFollow(FOLLOW_rule__PrimitiveType__Group__0__Impl_in_rule__PrimitiveType__Group__02494);
            rule__PrimitiveType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__PrimitiveType__Group__1_in_rule__PrimitiveType__Group__02497);
            rule__PrimitiveType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveType__Group__0"


    // $ANTLR start "rule__PrimitiveType__Group__0__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1272:1: rule__PrimitiveType__Group__0__Impl : ( 'primitive' ) ;
    public final void rule__PrimitiveType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1276:1: ( ( 'primitive' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1277:1: ( 'primitive' )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1277:1: ( 'primitive' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1278:1: 'primitive'
            {
             before(grammarAccess.getPrimitiveTypeAccess().getPrimitiveKeyword_0()); 
            match(input,21,FOLLOW_21_in_rule__PrimitiveType__Group__0__Impl2525); 
             after(grammarAccess.getPrimitiveTypeAccess().getPrimitiveKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveType__Group__0__Impl"


    // $ANTLR start "rule__PrimitiveType__Group__1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1291:1: rule__PrimitiveType__Group__1 : rule__PrimitiveType__Group__1__Impl ;
    public final void rule__PrimitiveType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1295:1: ( rule__PrimitiveType__Group__1__Impl )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1296:2: rule__PrimitiveType__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__PrimitiveType__Group__1__Impl_in_rule__PrimitiveType__Group__12556);
            rule__PrimitiveType__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveType__Group__1"


    // $ANTLR start "rule__PrimitiveType__Group__1__Impl"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1302:1: rule__PrimitiveType__Group__1__Impl : ( ( rule__PrimitiveType__NameAssignment_1 ) ) ;
    public final void rule__PrimitiveType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1306:1: ( ( ( rule__PrimitiveType__NameAssignment_1 ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1307:1: ( ( rule__PrimitiveType__NameAssignment_1 ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1307:1: ( ( rule__PrimitiveType__NameAssignment_1 ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1308:1: ( rule__PrimitiveType__NameAssignment_1 )
            {
             before(grammarAccess.getPrimitiveTypeAccess().getNameAssignment_1()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1309:1: ( rule__PrimitiveType__NameAssignment_1 )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1309:2: rule__PrimitiveType__NameAssignment_1
            {
            pushFollow(FOLLOW_rule__PrimitiveType__NameAssignment_1_in_rule__PrimitiveType__Group__1__Impl2583);
            rule__PrimitiveType__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getPrimitiveTypeAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveType__Group__1__Impl"


    // $ANTLR start "rule__Model__PackageNameAssignment_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1324:1: rule__Model__PackageNameAssignment_1 : ( ruleFQN ) ;
    public final void rule__Model__PackageNameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1328:1: ( ( ruleFQN ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1329:1: ( ruleFQN )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1329:1: ( ruleFQN )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1330:1: ruleFQN
            {
             before(grammarAccess.getModelAccess().getPackageNameFQNParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleFQN_in_rule__Model__PackageNameAssignment_12622);
            ruleFQN();

            state._fsp--;

             after(grammarAccess.getModelAccess().getPackageNameFQNParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__PackageNameAssignment_1"


    // $ANTLR start "rule__Model__TypesAssignment_2_0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1339:1: rule__Model__TypesAssignment_2_0 : ( ruleClassType ) ;
    public final void rule__Model__TypesAssignment_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1343:1: ( ( ruleClassType ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1344:1: ( ruleClassType )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1344:1: ( ruleClassType )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1345:1: ruleClassType
            {
             before(grammarAccess.getModelAccess().getTypesClassTypeParserRuleCall_2_0_0()); 
            pushFollow(FOLLOW_ruleClassType_in_rule__Model__TypesAssignment_2_02653);
            ruleClassType();

            state._fsp--;

             after(grammarAccess.getModelAccess().getTypesClassTypeParserRuleCall_2_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__TypesAssignment_2_0"


    // $ANTLR start "rule__Model__TypesAssignment_2_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1354:1: rule__Model__TypesAssignment_2_1 : ( ruleEnumType ) ;
    public final void rule__Model__TypesAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1358:1: ( ( ruleEnumType ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1359:1: ( ruleEnumType )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1359:1: ( ruleEnumType )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1360:1: ruleEnumType
            {
             before(grammarAccess.getModelAccess().getTypesEnumTypeParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_ruleEnumType_in_rule__Model__TypesAssignment_2_12684);
            ruleEnumType();

            state._fsp--;

             after(grammarAccess.getModelAccess().getTypesEnumTypeParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__TypesAssignment_2_1"


    // $ANTLR start "rule__Model__TypesAssignment_2_2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1369:1: rule__Model__TypesAssignment_2_2 : ( rulePrimitiveType ) ;
    public final void rule__Model__TypesAssignment_2_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1373:1: ( ( rulePrimitiveType ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1374:1: ( rulePrimitiveType )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1374:1: ( rulePrimitiveType )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1375:1: rulePrimitiveType
            {
             before(grammarAccess.getModelAccess().getTypesPrimitiveTypeParserRuleCall_2_2_0()); 
            pushFollow(FOLLOW_rulePrimitiveType_in_rule__Model__TypesAssignment_2_22715);
            rulePrimitiveType();

            state._fsp--;

             after(grammarAccess.getModelAccess().getTypesPrimitiveTypeParserRuleCall_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Model__TypesAssignment_2_2"


    // $ANTLR start "rule__ClassType__NameAssignment_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1384:1: rule__ClassType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__ClassType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1388:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1389:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1389:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1390:1: RULE_ID
            {
             before(grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ClassType__NameAssignment_12746); 
             after(grammarAccess.getClassTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__NameAssignment_1"


    // $ANTLR start "rule__ClassType__FieldsAssignment_3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1399:1: rule__ClassType__FieldsAssignment_3 : ( ruleField ) ;
    public final void rule__ClassType__FieldsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1403:1: ( ( ruleField ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1404:1: ( ruleField )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1404:1: ( ruleField )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1405:1: ruleField
            {
             before(grammarAccess.getClassTypeAccess().getFieldsFieldParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleField_in_rule__ClassType__FieldsAssignment_32777);
            ruleField();

            state._fsp--;

             after(grammarAccess.getClassTypeAccess().getFieldsFieldParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ClassType__FieldsAssignment_3"


    // $ANTLR start "rule__SimpleField__BoundAssignment_0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1414:1: rule__SimpleField__BoundAssignment_0 : ( ( 'bound' ) ) ;
    public final void rule__SimpleField__BoundAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1418:1: ( ( ( 'bound' ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1419:1: ( ( 'bound' ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1419:1: ( ( 'bound' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1420:1: ( 'bound' )
            {
             before(grammarAccess.getSimpleFieldAccess().getBoundBoundKeyword_0_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1421:1: ( 'bound' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1422:1: 'bound'
            {
             before(grammarAccess.getSimpleFieldAccess().getBoundBoundKeyword_0_0()); 
            match(input,22,FOLLOW_22_in_rule__SimpleField__BoundAssignment_02813); 
             after(grammarAccess.getSimpleFieldAccess().getBoundBoundKeyword_0_0()); 

            }

             after(grammarAccess.getSimpleFieldAccess().getBoundBoundKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__BoundAssignment_0"


    // $ANTLR start "rule__SimpleField__TypeAssignment_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1437:1: rule__SimpleField__TypeAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__SimpleField__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1441:1: ( ( ( RULE_ID ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1442:1: ( ( RULE_ID ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1442:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1443:1: ( RULE_ID )
            {
             before(grammarAccess.getSimpleFieldAccess().getTypeTypeCrossReference_1_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1444:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1445:1: RULE_ID
            {
             before(grammarAccess.getSimpleFieldAccess().getTypeTypeIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__SimpleField__TypeAssignment_12856); 
             after(grammarAccess.getSimpleFieldAccess().getTypeTypeIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getSimpleFieldAccess().getTypeTypeCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__TypeAssignment_1"


    // $ANTLR start "rule__SimpleField__NameAssignment_2"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1456:1: rule__SimpleField__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__SimpleField__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1460:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1461:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1461:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1462:1: RULE_ID
            {
             before(grammarAccess.getSimpleFieldAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__SimpleField__NameAssignment_22891); 
             after(grammarAccess.getSimpleFieldAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SimpleField__NameAssignment_2"


    // $ANTLR start "rule__ListField__BoundAssignment_0"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1471:1: rule__ListField__BoundAssignment_0 : ( ( 'bound' ) ) ;
    public final void rule__ListField__BoundAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1475:1: ( ( ( 'bound' ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1476:1: ( ( 'bound' ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1476:1: ( ( 'bound' ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1477:1: ( 'bound' )
            {
             before(grammarAccess.getListFieldAccess().getBoundBoundKeyword_0_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1478:1: ( 'bound' )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1479:1: 'bound'
            {
             before(grammarAccess.getListFieldAccess().getBoundBoundKeyword_0_0()); 
            match(input,22,FOLLOW_22_in_rule__ListField__BoundAssignment_02927); 
             after(grammarAccess.getListFieldAccess().getBoundBoundKeyword_0_0()); 

            }

             after(grammarAccess.getListFieldAccess().getBoundBoundKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__BoundAssignment_0"


    // $ANTLR start "rule__ListField__TypeAssignment_3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1494:1: rule__ListField__TypeAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__ListField__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1498:1: ( ( ( RULE_ID ) ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1499:1: ( ( RULE_ID ) )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1499:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1500:1: ( RULE_ID )
            {
             before(grammarAccess.getListFieldAccess().getTypeTypeCrossReference_3_0()); 
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1501:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1502:1: RULE_ID
            {
             before(grammarAccess.getListFieldAccess().getTypeTypeIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListField__TypeAssignment_32970); 
             after(grammarAccess.getListFieldAccess().getTypeTypeIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getListFieldAccess().getTypeTypeCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__TypeAssignment_3"


    // $ANTLR start "rule__ListField__NameAssignment_5"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1513:1: rule__ListField__NameAssignment_5 : ( RULE_ID ) ;
    public final void rule__ListField__NameAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1517:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1518:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1518:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1519:1: RULE_ID
            {
             before(grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_5_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ListField__NameAssignment_53005); 
             after(grammarAccess.getListFieldAccess().getNameIDTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ListField__NameAssignment_5"


    // $ANTLR start "rule__EnumType__NameAssignment_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1528:1: rule__EnumType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__EnumType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1532:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1533:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1533:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1534:1: RULE_ID
            {
             before(grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EnumType__NameAssignment_13036); 
             after(grammarAccess.getEnumTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__NameAssignment_1"


    // $ANTLR start "rule__EnumType__ValuesAssignment_3"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1543:1: rule__EnumType__ValuesAssignment_3 : ( ruleValue ) ;
    public final void rule__EnumType__ValuesAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1547:1: ( ( ruleValue ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1548:1: ( ruleValue )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1548:1: ( ruleValue )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1549:1: ruleValue
            {
             before(grammarAccess.getEnumTypeAccess().getValuesValueParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleValue_in_rule__EnumType__ValuesAssignment_33067);
            ruleValue();

            state._fsp--;

             after(grammarAccess.getEnumTypeAccess().getValuesValueParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EnumType__ValuesAssignment_3"


    // $ANTLR start "rule__Value__NameAssignment"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1558:1: rule__Value__NameAssignment : ( RULE_ID ) ;
    public final void rule__Value__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1562:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1563:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1563:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1564:1: RULE_ID
            {
             before(grammarAccess.getValueAccess().getNameIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Value__NameAssignment3098); 
             after(grammarAccess.getValueAccess().getNameIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Value__NameAssignment"


    // $ANTLR start "rule__PrimitiveType__NameAssignment_1"
    // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1573:1: rule__PrimitiveType__NameAssignment_1 : ( RULE_ID ) ;
    public final void rule__PrimitiveType__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1577:1: ( ( RULE_ID ) )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1578:1: ( RULE_ID )
            {
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1578:1: ( RULE_ID )
            // ../com.javadude.beans2.dsl.ui/src-gen/com/javadude/beans2/dsl/ui/contentassist/antlr/internal/InternalBeansDsl.g:1579:1: RULE_ID
            {
             before(grammarAccess.getPrimitiveTypeAccess().getNameIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__PrimitiveType__NameAssignment_13129); 
             after(grammarAccess.getPrimitiveTypeAccess().getNameIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PrimitiveType__NameAssignment_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_ruleModel_in_entryRuleModel61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleModel68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0_in_ruleModel94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFQN_in_entryRuleFQN121 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFQN128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FQN__Group__0_in_ruleFQN154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleClassType_in_entryRuleClassType183 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleClassType190 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__Group__0_in_ruleClassType216 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_entryRuleField243 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleField250 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Field__Alternatives_in_ruleField276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSimpleField_in_entryRuleSimpleField303 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSimpleField310 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__0_in_ruleSimpleField336 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListField_in_entryRuleListField363 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleListField370 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__0_in_ruleListField396 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEnumType_in_entryRuleEnumType423 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEnumType430 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__Group__0_in_ruleEnumType456 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleValue_in_entryRuleValue483 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleValue490 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Value__NameAssignment_in_ruleValue516 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimitiveType_in_entryRulePrimitiveType543 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePrimitiveType550 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PrimitiveType__Group__0_in_rulePrimitiveType576 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__TypesAssignment_2_0_in_rule__Model__Alternatives_2612 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__TypesAssignment_2_1_in_rule__Model__Alternatives_2630 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__TypesAssignment_2_2_in_rule__Model__Alternatives_2648 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleSimpleField_in_rule__Field__Alternatives682 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleListField_in_rule__Field__Alternatives699 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__0__Impl_in_rule__Model__Group__0729 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Model__Group__1_in_rule__Model__Group__0732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Model__Group__0__Impl760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__1__Impl_in_rule__Model__Group__1791 = new BitSet(new long[]{0x0000000000308000L});
    public static final BitSet FOLLOW_rule__Model__Group__2_in_rule__Model__Group__1794 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__PackageNameAssignment_1_in_rule__Model__Group__1__Impl821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Group__2__Impl_in_rule__Model__Group__2851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Model__Alternatives_2_in_rule__Model__Group__2__Impl880 = new BitSet(new long[]{0x0000000000308002L});
    public static final BitSet FOLLOW_rule__Model__Alternatives_2_in_rule__Model__Group__2__Impl892 = new BitSet(new long[]{0x0000000000308002L});
    public static final BitSet FOLLOW_rule__FQN__Group__0__Impl_in_rule__FQN__Group__0931 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_rule__FQN__Group__1_in_rule__FQN__Group__0934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FQN__Group__0__Impl961 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FQN__Group__1__Impl_in_rule__FQN__Group__1990 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FQN__Group_1__0_in_rule__FQN__Group__1__Impl1017 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_rule__FQN__Group_1__0__Impl_in_rule__FQN__Group_1__01052 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FQN__Group_1__1_in_rule__FQN__Group_1__01055 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__FQN__Group_1__0__Impl1083 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FQN__Group_1__1__Impl_in_rule__FQN__Group_1__11114 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FQN__Group_1__1__Impl1141 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__Group__0__Impl_in_rule__ClassType__Group__01174 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ClassType__Group__1_in_rule__ClassType__Group__01177 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__ClassType__Group__0__Impl1205 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__Group__1__Impl_in_rule__ClassType__Group__11236 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__ClassType__Group__2_in_rule__ClassType__Group__11239 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__NameAssignment_1_in_rule__ClassType__Group__1__Impl1266 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__Group__2__Impl_in_rule__ClassType__Group__21296 = new BitSet(new long[]{0x0000000000420050L});
    public static final BitSet FOLLOW_rule__ClassType__Group__3_in_rule__ClassType__Group__21299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_LBRACE_in_rule__ClassType__Group__2__Impl1326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__Group__3__Impl_in_rule__ClassType__Group__31355 = new BitSet(new long[]{0x0000000000420050L});
    public static final BitSet FOLLOW_rule__ClassType__Group__4_in_rule__ClassType__Group__31358 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ClassType__FieldsAssignment_3_in_rule__ClassType__Group__3__Impl1385 = new BitSet(new long[]{0x0000000000420012L});
    public static final BitSet FOLLOW_rule__ClassType__Group__4__Impl_in_rule__ClassType__Group__41416 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_RBRACE_in_rule__ClassType__Group__4__Impl1443 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__0__Impl_in_rule__SimpleField__Group__01482 = new BitSet(new long[]{0x0000000000400010L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__1_in_rule__SimpleField__Group__01485 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__BoundAssignment_0_in_rule__SimpleField__Group__0__Impl1512 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__1__Impl_in_rule__SimpleField__Group__11543 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__2_in_rule__SimpleField__Group__11546 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__TypeAssignment_1_in_rule__SimpleField__Group__1__Impl1573 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__2__Impl_in_rule__SimpleField__Group__21603 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__3_in_rule__SimpleField__Group__21606 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__NameAssignment_2_in_rule__SimpleField__Group__2__Impl1633 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__SimpleField__Group__3__Impl_in_rule__SimpleField__Group__31663 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__SimpleField__Group__3__Impl1691 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__0__Impl_in_rule__ListField__Group__01730 = new BitSet(new long[]{0x0000000000420010L});
    public static final BitSet FOLLOW_rule__ListField__Group__1_in_rule__ListField__Group__01733 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__BoundAssignment_0_in_rule__ListField__Group__0__Impl1760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__1__Impl_in_rule__ListField__Group__11791 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_rule__ListField__Group__2_in_rule__ListField__Group__11794 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__ListField__Group__1__Impl1822 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__2__Impl_in_rule__ListField__Group__21853 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListField__Group__3_in_rule__ListField__Group__21856 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__ListField__Group__2__Impl1884 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__3__Impl_in_rule__ListField__Group__31915 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_rule__ListField__Group__4_in_rule__ListField__Group__31918 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__TypeAssignment_3_in_rule__ListField__Group__3__Impl1945 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__4__Impl_in_rule__ListField__Group__41975 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ListField__Group__5_in_rule__ListField__Group__41978 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__ListField__Group__4__Impl2006 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__5__Impl_in_rule__ListField__Group__52037 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_rule__ListField__Group__6_in_rule__ListField__Group__52040 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__NameAssignment_5_in_rule__ListField__Group__5__Impl2067 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ListField__Group__6__Impl_in_rule__ListField__Group__62097 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__ListField__Group__6__Impl2125 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__Group__0__Impl_in_rule__EnumType__Group__02170 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EnumType__Group__1_in_rule__EnumType__Group__02173 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__EnumType__Group__0__Impl2201 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__Group__1__Impl_in_rule__EnumType__Group__12232 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__EnumType__Group__2_in_rule__EnumType__Group__12235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__NameAssignment_1_in_rule__EnumType__Group__1__Impl2262 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__Group__2__Impl_in_rule__EnumType__Group__22292 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EnumType__Group__3_in_rule__EnumType__Group__22295 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_LBRACE_in_rule__EnumType__Group__2__Impl2322 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__Group__3__Impl_in_rule__EnumType__Group__32351 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__EnumType__Group__4_in_rule__EnumType__Group__32354 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EnumType__ValuesAssignment_3_in_rule__EnumType__Group__3__Impl2383 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_rule__EnumType__ValuesAssignment_3_in_rule__EnumType__Group__3__Impl2395 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_rule__EnumType__Group__4__Impl_in_rule__EnumType__Group__42428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_RBRACE_in_rule__EnumType__Group__4__Impl2455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PrimitiveType__Group__0__Impl_in_rule__PrimitiveType__Group__02494 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__PrimitiveType__Group__1_in_rule__PrimitiveType__Group__02497 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__PrimitiveType__Group__0__Impl2525 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PrimitiveType__Group__1__Impl_in_rule__PrimitiveType__Group__12556 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__PrimitiveType__NameAssignment_1_in_rule__PrimitiveType__Group__1__Impl2583 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFQN_in_rule__Model__PackageNameAssignment_12622 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleClassType_in_rule__Model__TypesAssignment_2_02653 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEnumType_in_rule__Model__TypesAssignment_2_12684 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimitiveType_in_rule__Model__TypesAssignment_2_22715 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ClassType__NameAssignment_12746 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleField_in_rule__ClassType__FieldsAssignment_32777 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__SimpleField__BoundAssignment_02813 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__SimpleField__TypeAssignment_12856 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__SimpleField__NameAssignment_22891 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__ListField__BoundAssignment_02927 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListField__TypeAssignment_32970 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ListField__NameAssignment_53005 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EnumType__NameAssignment_13036 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleValue_in_rule__EnumType__ValuesAssignment_33067 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Value__NameAssignment3098 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__PrimitiveType__NameAssignment_13129 = new BitSet(new long[]{0x0000000000000002L});

}