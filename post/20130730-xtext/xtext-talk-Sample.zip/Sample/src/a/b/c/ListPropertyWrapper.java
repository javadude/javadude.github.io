package a.b.c;

import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListPropertyWrapper<E> implements List<E> {
	private List<E> realList;
	private PropertyChangeSupport pcs;
	private String propertyName;

	public ListPropertyWrapper(List<E> realList, String propertyName, PropertyChangeSupport pcs) {
		this.realList = realList;
		this.propertyName = propertyName;
		this.pcs = pcs;
	}
	public int size() { return realList.size(); }
	public boolean isEmpty() { return realList.isEmpty(); }
	public boolean contains(Object o) { return realList.contains(o); }
	public Object[] toArray() { return realList.toArray(); }
	public <T> T[] toArray(T[] a) { return realList.toArray(a); }
	public boolean containsAll(Collection<?> c) { return realList.containsAll(c); }
	public boolean equals(Object o) { return realList.equals(o); }
	public int hashCode() { return realList.hashCode(); }
	public E get(int index) { return realList.get(index); }
	public int indexOf(Object o) { return realList.indexOf(o); }
	public int lastIndexOf(Object o) { return realList.lastIndexOf(o); }

	
	public boolean add(E e) {
		List<E> old = Collections.unmodifiableList(new ArrayList<>(this));
		boolean result = realList.add(e);
		pcs.firePropertyChange(propertyName, old, this);
		return result;
	}
	public boolean remove(Object o) {
		List<E> old = Collections.unmodifiableList(new ArrayList<>(this));
		boolean result = realList.remove(o);
		pcs.firePropertyChange(propertyName, old, this);
		return result;
	}
	public boolean addAll(Collection<? extends E> c) {
		return realList.addAll(c);
	}
	public boolean addAll(int index, Collection<? extends E> c) {
		return realList.addAll(index, c);
	}
	public boolean removeAll(Collection<?> c) {
		return realList.removeAll(c);
	}
	public boolean retainAll(Collection<?> c) {
		return realList.retainAll(c);
	}
	public void clear() {
		List<E> old = Collections.unmodifiableList(new ArrayList<>(this));
		realList.clear();
		pcs.firePropertyChange(propertyName, old, this);
	}
	public E set(int index, E element) {
		return realList.set(index, element);
	}
	public void add(int index, E element) {
		realList.add(index, element);
	}
	public E remove(int index) {
		return realList.remove(index);
	}

	
	// iterators/sublists
	public Iterator<E> iterator() {
		return realList.iterator();
	}
	public ListIterator<E> listIterator() {
		return realList.listIterator();
	}
	
	public ListIterator<E> listIterator(int index) {
		return realList.listIterator(index);
	}
	
	
	public List<E> subList(int fromIndex, int toIndex) {
		return new ListPropertyWrapper<>(realList.subList(fromIndex, toIndex), propertyName, pcs);
	}
}
