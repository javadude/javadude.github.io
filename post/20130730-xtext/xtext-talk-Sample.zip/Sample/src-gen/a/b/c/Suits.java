package a.b.c;


public enum Suits {
	Spades, 
	Hearts, 
	Diamonds, 
	Clubs
}
