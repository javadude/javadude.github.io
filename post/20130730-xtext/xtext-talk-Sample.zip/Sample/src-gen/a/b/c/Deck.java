package a.b.c;

import java.util.ArrayList;
import java.util.List;

public class Deck {

	private List<Card> cards = new ArrayList<>();
	public List<Card> getCards() {
		return this.cards;
	}
}
