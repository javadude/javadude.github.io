package a.b.c;

import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener;

public class Card {
	private PropertyChangeSupport pcs = new PropertyChangeSupport(this);

	public void addPropertyChangeListener(PropertyChangeListener listener) {
		pcs.addPropertyChangeListener(listener);
	}
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		pcs.removePropertyChangeListener(listener);
	}
	public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		pcs.addPropertyChangeListener(propertyName, listener);
	}
	public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		pcs.removePropertyChangeListener(propertyName, listener);
	}

	private int value;
	public int getValue() {
		return this.value;
	}
	public void setValue(int value) {
		int old = this.value; 
		this.value = value;
		pcs.firePropertyChange("value", old, value);
	}
	private Suits suit;
	public Suits getSuit() {
		return this.suit;
	}
	public void setSuit(Suits suit) {
		this.suit = suit;
	}
}
