
package com.magelang.tabsplitter;

import com.magelang.editors.ColorSelector;
import com.magelang.editors.BasicColorSelector;
import java.awt.Panel;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyEditor;
import java.beans.PropertyChangeSupport;

/**
 *  <p>Use this code at your own risk!  MageLang Institute is not
 *  responsible for any damage caused directly or indirectly through
 *  use of this code.
 *  <p><p>
 *  <b>SOFTWARE RIGHTS</b>
 *  <p>
 *  TabSplitter, version 2.0, Scott Stanchfield, MageLang Institute
 *  <p>
 *  We reserve no legal rights to this code--it is fully in the
 *  public domain. An individual or company may do whatever
 *  they wish with source code distributed with it, including
 *  including the incorporation of it into commerical software.
 *
 *  <p>However, this code <i>cannot</i> be sold as a standalone product.
 *  <p>
 *  We encourage users to develop software with this code. However,
 *  we do ask that credit is given to us for developing it
 *  By "credit", we mean that if you use these components or
 *  incorporate any source code into one of your programs
 *  (commercial product, research project, or otherwise) that
 *  you acknowledge this fact somewhere in the documentation,
 *  research report, etc... If you like these components and have
 *  developed a nice tool with the output, please mention that
 *  you developed it using these components. In addition, we ask that
 *  the headers remain intact in our source code. As long as these
 *  guidelines are kept, we expect to continue enhancing this
 *  system and expect to make other tools available as they are
 *  completed.
 *  <p>
 *  The MageLang Support Classes Gang:
 *  @version TabSplitter 2.0, MageLang Insitute, Jan 18, 1998
 *  @author <a href="http:www.scruz.net/~thetick">Scott Stanchfield</a>, <a href=http://www.MageLang.com>MageLang Institute</a>
 */
public class TabColorEditor extends Panel implements ActionListener, PropertyChangeListener, PropertyEditor {
	private Button addButton = new Button("Add Tab Color");
	private Button removeButton = new Button("Remove Tab Color");
	private Panel buttonPanel = new Panel();
	private TabPanel tabPanel = new TabPanel();
	protected transient PropertyChangeSupport propertyChange = new PropertyChangeSupport(this);


public TabColorEditor() {
	super();
	setName("TabColorEditor");
	setLayout(new BorderLayout());
	add("Center", tabPanel);
	buttonPanel.setLayout(new FlowLayout());
	buttonPanel.add(addButton, addButton.getName());
	buttonPanel.add(removeButton, removeButton.getName());
	add("South", buttonPanel);

	addButton.addActionListener(this);
	removeButton.addActionListener(this);
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
public void actionPerformed(java.awt.event.ActionEvent e) {
	if ((e.getSource() == addButton) )
		addTabColor(null);
	else if ((e.getSource() == removeButton) ) {
		removeCurrentTabColor();
	}
}
/**
 * addPropertyChangeListener method comment.
 */
public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
	protected void addTabColor(java.awt.Color color) {
		com.magelang.editors.BasicColorSelector c = new com.magelang.editors.BasicColorSelector();
		c.setSelectedColor(color);
		c.addPropertyChangeListener(this);
		
		tabPanel.add("  ", c);
		tabPanel.show(c);

		int compCount = tabPanel.getComponentCount();
		if (compCount > tabPanel.getTabColors().length) {
			tabPanel.setTabColors(compCount-1, color);
			firePropertyChange("tabColors", null, tabPanel.getTabColors());
		}	
	}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * getAsText method comment.
 */
public String getAsText() {
	return null;
}
/**
 * getCustomEditor method comment.
 */
public Component getCustomEditor() {
	return this;
}
/**
 * getJavaInitializationString method comment.
 */
public String getJavaInitializationString() {
	String initString = "new java.awt.Color[] {";
	Color tabColors[] = tabPanel.getTabColors();
	Component comps[] = tabPanel.getComponents();
	for(int i=0; i < tabColors.length; i++) {
		initString += ((ColorSelector)comps[i]).getJavaInitializationString() + ",";
	}
	initString += "}";
	return initString;
}
/**
 * getTags method comment.
 */
public java.lang.String[] getTags() {
	return null;
}
/**
 * getValue method comment.
 */
public Object getValue() {
	return tabPanel.getTabColors();
}
/**
 * isPaintable method comment.
 */
public boolean isPaintable() {
	return true;
}
/**
 * paintValue method comment.
 */
public void paintValue(Graphics gfx, Rectangle box) {
	Color colors[] = tabPanel.getTabColors();
	int w = box.width/colors.length;
	int x = box.x;
	for(int i = 0; i<colors.length; i++) {
		Color c = colors[i];
		gfx.setColor((c==null)?Color.lightGray:c);
		gfx.fill3DRect(x, box.y, w-1, box.height-1,true);
		x += w;
	}	
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
public void propertyChange(PropertyChangeEvent evt) {
	Color[] colors = tabPanel.getTabColors();
	
	/* Set the tabColors property (attribute) to the new value. */
	tabPanel.setTabColors(tabPanel.getSelectedTabNum(), ((ColorSelector)evt.getSource()).getSelectedColor());

	firePropertyChange("tabColors", null, tabPanel.getTabColors());
	invalidate();
	if (tabPanel.isVisible())
		tabPanel.repaint();
}
	protected void removeCurrentTabColor() {
		if (tabPanel.getComponentCount() > 1) {
			int currentTab = tabPanel.getSelectedTabNum();
			tabPanel.remove(currentTab);
			
			// remove the actual color from the tab colors array
			Color colors[] = tabPanel.getTabColors();
			Color newColors[] = new Color[colors.length-1];
			if (currentTab > 0)
				System.arraycopy(colors, 0, newColors, 0, currentTab);
			if (currentTab < colors.length-1)
				System.arraycopy(colors, currentTab+1, newColors, currentTab,
				                 colors.length-currentTab-1);
			tabPanel.setTabColors(newColors);
		}	
	}
/**
 * removePropertyChangeListener method comment.
 */
public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * setAsText method comment.
 */
public void setAsText(String text) throws IllegalArgumentException {
}
/**
 * Sets the tabColors property (java.awt.Color[]) value.
 * @param tabColors The new value for the property.
 */
public void setTabColors(java.awt.Color[] tabColors) {
	/* Get the old property value for fire property change event. */
	java.awt.Color[] oldValue = tabPanel.getTabColors();
	/* Set the tabColors property (attribute) to the new value. */
	tabPanel.setTabColors(tabColors);
	for(int i = tabPanel.getComponentCount(); i < tabColors.length; i++)
		addTabColor(tabColors[i]);
	tabPanel.show(tabPanel.getComponent(0));
	/* Fire (signal/notify) the tabColors property change event. */
	firePropertyChange("tabColors", oldValue, tabColors);
	return;
}
/**
 * setValue method comment.
 */
public void setValue(Object value) {
	setTabColors((Color[])value);
}
/**
 * supportsCustomEditor method comment.
 */
public boolean supportsCustomEditor() {
	return true;
}
}