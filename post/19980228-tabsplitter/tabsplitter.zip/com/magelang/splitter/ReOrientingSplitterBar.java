
package com.magelang.splitter;

import java.awt.*;
import java.awt.event.*;
public class ReOrientingSplitterBar extends SplitterBar implements ActionListener {
	private boolean needsToBeSetup=true;

/**
 * ReOrientingSplitterBar constructor comment.
 */
public ReOrientingSplitterBar() {
	super();
	setupBar();
}
	public void actionPerformed(ActionEvent e) {
		if (getParent() != null && (getParent().getLayout() instanceof SplitterLayout))
			((SplitterLayout)getParent().getLayout()).swapOrientation(getParent());
	}	
	public void setOrientation(int orientation) {
		super.setOrientation(orientation);
		if (needsToBeSetup) {
			setupBar();
			needsToBeSetup = false;
		}	
	}	
	protected void setupBar() {
		removeAll();

		SwapButton swapper = new SwapButton();
				
		setLayout(new BorderLayout());
		add("Center",new SplitterSpace());
		if (getOrientation() == SplitterLayout.VERTICAL)
			add("West", swapper);
		else
			add("North", swapper);

		swapper.addActionListener(this);
		
	}	
	public void swapOrientation() {
		super.swapOrientation();
		setupBar();
	}	
}