
package com.magelang.splitter;

import java.awt.*;
import java.awt.event.*;
import com.magelang.Colors;

public class SwapButton extends Canvas implements java.awt.event.MouseListener {
	protected transient ActionListener aActionListener = null;
	private boolean state = true;

/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public SwapButton() {
	super();
	initialize();
}

public void addActionListener(java.awt.event.ActionListener newListener) {
	aActionListener = java.awt.AWTEventMulticaster.add(aActionListener, newListener);
	return;
}
/**
 * conn0:  (SwapButton.mouse.mouseReleased(java.awt.event.MouseEvent) --> SwapButton.fireActionPerformed(Ljava.awt.event.ActionEvent;)V)
 * @param arg1 java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void conn0(MouseEvent arg1) {
	try {
		// user code begin {1}
		if (state) return;
		// user code end
		this.fireActionPerformed(new ActionEvent(this,ActionEvent.ACTION_PERFORMED,""));
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}

/**
 * Method to support listener events.
 */
protected void fireActionPerformed(java.awt.event.ActionEvent e) {
	if (aActionListener == null) {
		return;
	};
	aActionListener.actionPerformed(e);
}
	public Dimension getMinimumSize() {
	  	return minimumSize();
	}
	public Dimension getPreferredSize() {
	  	return preferredSize();
	}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}

/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	this.addMouseListener(this);
}

/**
 * Initialize class
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("SwapButton");
	setName("SwapButton");
	setSize(150, 150);
	initConnections();
	// user code begin {2}
	// user code end
}

	public Dimension minimumSize() {
	  	return new Dimension(10,10);
	}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseClicked(MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseEntered(MouseEvent e) {
	// user code begin {1}
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseExited(MouseEvent e) {
	// user code begin {1}
	state = true;
	repaint();
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mousePressed(MouseEvent e) {
	// user code begin {1}
	state = false;
	repaint();
	// user code end
	// user code begin {2}
	// user code end
}

/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void mouseReleased(MouseEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == this) ) {
		conn0(e);
	}
	// user code begin {2}
	state = true;
	repaint();
	// user code end
}

	public void paint(Graphics g) {
		Dimension d = getSize();
		g.setColor(Color.gray);
		g.fill3DRect(0,0,d.width-1,d.height-1,state);
		g.setColor(Colors.lightSkyBlue3.brighter());
		g.drawLine(2,2,d.width-4, d.height-4);
		g.drawLine(2,d.height-4, d.width-4, 2);
	}	
	public Dimension preferredSize() {
	  	return new Dimension(10,10);
	}
public void removeActionListener(java.awt.event.ActionListener newListener) {
	aActionListener = java.awt.AWTEventMulticaster.remove(aActionListener, newListener);
	return;
}
}