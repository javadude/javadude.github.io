
package com.magelang.editors;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.beans.PropertyChangeSupport;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class BasicColorSelector extends ColorSelector implements MouseListener {
	protected transient PropertyChangeSupport propertyChange = new PropertyChangeSupport(this);
	private ColorToggle selectedToggle = null;
	private static String colorNames[] = {"white", "lightGray", "gray", "darkGray", "black", "red", "pink", "orange", "yellow", "green", "magenta", "cyan", "blue", null};
	private static Color  colors[]     = {Color.white, Color.lightGray, Color.gray, Color.darkGray, Color.black, Color.red, Color.pink, Color.orange, Color.yellow, Color.green, Color.magenta, Color.cyan, Color.blue, null};

/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public BasicColorSelector() {
	super();
	setLayout(new GridLayout(0, 2));
	setBackground(Color.lightGray);

	for (int i=0; i < 14; i++) {
		ColorToggle ct = new ColorToggle((colorNames[i]==null)?"null":("java.awt.Color."+colorNames[i]), colors[i]);
		ct.addMouseListener(this);
		add(ct);
	}	
}
	public java.awt.Insets getInsets() {
		return new java.awt.Insets(5,5,5,5);
	}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseClicked(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseEntered(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseExited(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mousePressed(java.awt.event.MouseEvent e) {
}
/**
 * Method to handle events for the MouseListener interface.
 * @param e java.awt.event.MouseEvent
 */
public void mouseReleased(MouseEvent e) {
	Color c = ((ColorToggle)e.getSource()).getColor();
	setSelectedColor(c);
}
public void setSelectedColor(java.awt.Color c) {
	super.setSelectedColor(c);
	
	if (selectedToggle != null)
		selectedToggle.setState(false);
	
	Component comps[] = getComponents();
	for (int i=getComponentCount()-1; i > -1; i--) {
		if ((c == null && ((ColorToggle)comps[i]).getColor() == null) ||
			(c != null && c.equals(((ColorToggle)comps[i]).getColor()))) {
			selectedToggle = (ColorToggle)comps[i];
		}	
	}	
	
	setInitString(selectedToggle.getColorInit());
	selectedToggle.setState(true);
	invalidate();
}
}