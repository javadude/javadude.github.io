
package com.magelang.editors;

import com.magelang.BorderPanel;
import java.awt.Panel;
import java.awt.Color;
import java.awt.Insets;
import java.awt.Graphics;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Label;
import java.awt.BorderLayout;
import java.awt.GridLayout;

public class ColorToggle extends Panel {
	private boolean state = false;
	private Color borderColor = Color.lightGray;
	private Color color = null;
	private String colorInit;

/**
 * ColorToggle constructor comment.
 */
public ColorToggle(String colorInit, Color color) {
	super();
	setColorInit(colorInit);
	setColor(color);
}
/**
 * Gets the borderColor property (java.awt.Color) value.
 * @return The borderColor property value.
 * @see #setBorderColor
 */
public Color getBorderColor() {
	return borderColor;
}
/**
 * Gets the color property (java.awt.Color) value.
 * @return The color property value.
 * @see #setColor
 */
public Color getColor() {
	return color;
}
	public String getColorInit() {
		return colorInit;
	}
	public Insets getInsets() {
		return new Insets(7,40,7,40);
	}	
/**
 * Gets the state property (boolean) value.
 * @return The state property value.
 * @see #setState
 */
public boolean getState() {
	/* Returns the state property value. */
	return state;
}
	public void paint(Graphics g) {
		Dimension d = getSize();
		
		g.setColor(getBorderColor());
		g.draw3DRect(0, 0, d.width-1, d.height-1, !getState());
		
		if (getColor() == null) {
			FontMetrics fm = getFontMetrics(g.getFont());
			g.setColor(Color.white);
			g.fillRect(2, 2, d.width-5, d.height-5);
			g.setColor(Color.black);
			int x = (d.width-10-fm.stringWidth("<default>")) / 2;
			int y = (fm.getAscent() + d.height)/2;
			g.drawString("<default>", x, y);
		}
		else {	
			g.setColor(getColor());
			g.fillRect(2, 2, d.width-5, d.height-5);
		}	
	}	
/**
 * Sets the borderColor property (java.awt.Color) value.
 * @param borderColor The new value for the property.
 * @see #getBorderColor
 */
public void setBorderColor(Color borderColor) {
	this.borderColor = borderColor;
}
/**
 * Sets the color property (java.awt.Color) value.
 * @param color The new value for the property.
 * @see #getColor
 */
public void setColor(Color c) {
	if (c == null) {
		super.setBackground(Color.white);
//		setLayout(new GridLayout(1,0));
//		BorderPanel bp = new BorderPanel();
//		add(bp);
//		bp.add(new Label("<default>", Label.CENTER));
		repaint();
	}
	else {
		if (color == null && getComponentCount() != 0) {
			removeAll();
			repaint();
		}	
	}	
	color = c;
}
	public void setColorInit(String colorInit) {
		this.colorInit = colorInit;
	}	
/**
 * Sets the state property (boolean) value.
 * @param state The new value for the property.
 * @see #getState
 */
public void setState(boolean state) {
	this.state = state;
	invalidate();
	getParent().validate();
	repaint();
}
}