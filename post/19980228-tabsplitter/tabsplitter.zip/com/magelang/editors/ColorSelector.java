
package com.magelang.editors;

public class ColorSelector extends java.awt.Panel implements java.beans.PropertyEditor {
	java.awt.Color fieldSelectedColor = null;
	protected transient java.beans.PropertyChangeSupport propertyChange = new java.beans.PropertyChangeSupport(this);
	private String initString;

/**
 * addPropertyChangeListener method comment.
 */
public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.addPropertyChangeListener(listener);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	propertyChange.firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * getAsText method comment.
 */
public String getAsText() {
	return null;
}
/**
 * getCustomEditor method comment.
 */
public java.awt.Component getCustomEditor() {
	return this;
}
/**
 * getJavaInitializationString method comment.
 */
public String getJavaInitializationString() {
	return initString;
}
/**
 * Gets the selectedColor property (java.awt.Color) value.
 * @return The selectedColor property value.
 * @see #setSelectedColor
 */
public java.awt.Color getSelectedColor() {
	return fieldSelectedColor;
}
/**
 * getTags method comment.
 */
public java.lang.String[] getTags() {
	return null;
}
/**
 * getValue method comment.
 */
public Object getValue() {
	return getSelectedColor();
}
/**
 * isPaintable method comment.
 */
public boolean isPaintable() {
	return true;
}
/**
 * paintValue method comment.
 */
public void paintValue(java.awt.Graphics gfx, java.awt.Rectangle box) {
	if (getSelectedColor() != null) {
		gfx.setColor(getSelectedColor());
		gfx.fill3DRect(box.x+1, box.y+1, box.width-3, box.height-3, true);
	}
	else {
		java.awt.FontMetrics fm = getFontMetrics(gfx.getFont());
		gfx.setColor(java.awt.Color.lightGray);
		gfx.fill3DRect(box.x, box.y, box.width-1, box.height-1, true);
		gfx.setColor(java.awt.Color.black);
		int x = box.x + 3;
		int y = box.y + (fm.getAscent() + box.height)/2 - 1;
		gfx.drawString("<default>", x, y);
	}	
}
/**
 * removePropertyChangeListener method comment.
 */
public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	propertyChange.removePropertyChangeListener(listener);
}
/**
 * setAsText method comment.
 */
public void setAsText(String text) throws IllegalArgumentException {
	throw new IllegalArgumentException("bogus setAsText call, dude");
}
	protected void setInitString(String initString) {
		this.initString = initString;
	}
/**
 * Sets the selectedColor property (java.awt.Color) value.
 * @param selectedColor The new value for the property.
 * @see #getSelectedColor
 */
public void setSelectedColor(java.awt.Color selectedColor) {
	/* Get the old property value for fire property change event. */
	java.awt.Color oldValue = fieldSelectedColor;
	/* Set the selectedColor property (attribute) to the new value. */
	fieldSelectedColor = selectedColor;
	/* Fire (signal/notify) the selectedColor property change event. */
	firePropertyChange("selectedColor", oldValue, selectedColor);
	return;
}
/**
 * setValue method comment.
 */
public void setValue(Object value) {
	if (value == null)
		setSelectedColor(null);
	else if (!(value instanceof java.awt.Color))
		throw new IllegalArgumentException("Not a color: "+value);
	else
		setSelectedColor((java.awt.Color)value);
}
/**
 * supportsCustomEditor method comment.
 */
public boolean supportsCustomEditor() {
	return true;
}
}