
package com.magelang.test;

import java.applet.*;
import java.awt.*;
import com.magelang.splitter.*;
public class SplitterEx3 extends Applet {

	public void init() {
		super.init();
		setLayout(new SplitterLayout(SplitterLayout.VERTICAL));
		add("1",new Button("A (1)"));

		SplitterBar b1 = new SplitterBar();
		b1.setLayout(new GridLayout(1,0));
		b1.add(new SplitterSpace());
		b1.add(new Label("Status"));
		b1.add(new TextField("Enter your name"));
		b1.add(new SplitterSpace());
		add(b1);
		add("2",new Button("B (2)"));

		SplitterBar b2 = new SplitterBar();
		b2.setLayout(new SplitterLayout(SplitterLayout.HORIZONTAL));
		b2.add("5",new SplitterSpace());
		b2.add(new SplitterBar());
		b2.add("10",new Label("Status"));
		b2.add(new SplitterBar());
		b2.add("40",new TextField("Enter your name"));
		add(b2);
		add("4",new Button("C (4)"));
	}
}