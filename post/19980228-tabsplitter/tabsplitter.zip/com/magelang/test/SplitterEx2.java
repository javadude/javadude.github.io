
package com.magelang.test;

import java.applet.*;
import java.awt.*;
import com.magelang.splitter.*;
public class SplitterEx2 extends Applet {

	public void init() {
		super.init();
		setLayout(new SplitterLayout(SplitterLayout.HORIZONTAL));
		add("1",new Button("A (1)"));
		add(new SplitterBar());
		add("2",new Button("B (2)"));
		add(new SplitterBar());
		add("4",new Button("C (4)"));
		add(new SplitterBar());
		add("8",new Button("D (8)"));
		add(new SplitterBar());
		add("3",new Button("E (3)"));
	}
}