package com.magelang.vaj.compareprojver;

/**
 * A simple dialog that allows the user to select two
 * project versions.  When the user presses "Ok", it
 * fires a CompareVersionsEvent, asking listener(s) to
 * do the actual comparison.  When the user presses
 * "Cancel", it simply calls System.exit(0)
 */

public class VersionsPicker extends com.sun.java.swing.JDialog implements java.awt.event.ActionListener, java.beans.PropertyChangeListener {
	private com.sun.java.swing.JButton ivjJButton1 = null;
	private com.sun.java.swing.JButton ivjJButton2 = null;
	private com.sun.java.swing.JPanel ivjJDialogContentPane = null;
	private com.sun.java.swing.JLabel ivjJLabel1 = null;
	private com.sun.java.swing.JList ivjJList1 = null;
	private com.sun.java.swing.JList ivjJList11 = null;
	private com.sun.java.swing.JPanel ivjJPanel1 = null;
	private java.awt.FlowLayout ivjJPanel1FlowLayout = null;
	private com.sun.java.swing.JPanel ivjJPanel2 = null;
	private java.awt.GridLayout ivjJPanel2GridLayout = null;
	private com.sun.java.swing.JPanel ivjJPanel3 = null;
	private java.awt.GridLayout ivjJPanel3GridLayout = null;
	private com.sun.java.swing.JScrollPane ivjJScrollPane1 = null;
	private com.sun.java.swing.JScrollPane ivjJScrollPane11 = null;
	private com.sun.java.swing.DefaultListModel ivjversionsData = null;
	protected transient com.magelang.vaj.compareprojver.CompareVersionsListener aCompareVersionsListener = null;
	private CompareVersionsEvent ivjversionEventFactory = null;
	private com.sun.java.swing.ListCellRenderer fieldRenderer = null;
	private com.sun.java.swing.JPanel ivjJPanel4 = null;
	private java.awt.BorderLayout ivjJPanel4BorderLayout = null;
	private com.sun.java.swing.JLabel ivjprojectName = null;
	protected transient java.beans.PropertyChangeSupport propertyChange;
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public VersionsPicker() {
	super();
	initialize();
}
/**
 * Method to handle events for the ActionListener interface.
 * @param e java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void actionPerformed(java.awt.event.ActionEvent e) {
	// user code begin {1}
	// user code end
	if ((e.getSource() == getJButton1()) ) {
		connEtoC1(e);
	}
	if ((e.getSource() == getJButton2()) ) {
		connEtoM2(e);
	}
	if ((e.getSource() == getJButton2()) ) {
		connEtoM1(e);
	}
	// user code begin {2}
	// user code end
}
/**
 * 
 * @param newListener com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 */
public void addCompareVersionsListener(com.magelang.vaj.compareprojver.CompareVersionsListener newListener) {
	aCompareVersionsListener = com.magelang.vaj.compareprojver.CompareVersionsEventMulticaster.add(aCompareVersionsListener, newListener);
	return;
}
/**
 * The addPropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().addPropertyChangeListener(listener);
}
/**
 * connEtoC1:  (JButton1.action.actionPerformed(java.awt.event.ActionEvent) --> VersionsPicker.jButton1_ActionPerformed()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.jButton1_ActionPerformed();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC2:  ( (JButton2,action.actionPerformed(java.awt.event.ActionEvent) --> versionEventFactory,CompareVersionsEvent(java.lang.Object, com.ibm.ivj.util.base.ProjectEdition, com.ibm.ivj.util.base.ProjectEdition)).normalResult --> VersionsPicker.fireCompareVersions(Lcom.magelang.vaj.compareprojver.CompareVersionsEvent;)V)
 * @param result com.magelang.vaj.compareprojver.CompareVersionsEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC2(CompareVersionsEvent result) {
	try {
		// user code begin {1}
		// user code end
		this.fireCompareVersions(result);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC3:  (projectName.text --> VersionsPicker.firePropertyChange(Ljava.lang.String;Ljava.lang.Object;Ljava.lang.Object;)V)
 * @param arg1 java.beans.PropertyChangeEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC3(java.beans.PropertyChangeEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.firePropertyChange("projectNameText", arg1.getOldValue(), arg1.getNewValue());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoC4:  (projectName.text --> VersionsPicker.firePropertyChange(Ljava.lang.String;Ljava.lang.Object;Ljava.lang.Object;)V)
 * @param arg1 java.beans.PropertyChangeEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC4(java.beans.PropertyChangeEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.firePropertyChange("projectName", arg1.getOldValue(), arg1.getNewValue());
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connEtoM1:  (JButton2.action.actionPerformed(java.awt.event.ActionEvent) --> versionEventFactory.CompareVersionsEvent(java.lang.Object, com.ibm.ivj.util.base.ProjectEdition, com.ibm.ivj.util.base.ProjectEdition))
 * @return com.magelang.vaj.compareprojver.CompareVersionsEvent
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private CompareVersionsEvent connEtoM1(java.awt.event.ActionEvent arg1) {
	com.magelang.vaj.compareprojver.CompareVersionsEvent connEtoM1Result = null;
	try {
		// user code begin {1}
		// user code end
		connEtoM1Result = new com.magelang.vaj.compareprojver.CompareVersionsEvent(this, (com.ibm.ivj.util.base.ProjectEdition)getJList1().getSelectedValue(), (com.ibm.ivj.util.base.ProjectEdition)getJList11().getSelectedValue());
		setversionEventFactory(connEtoM1Result);
		connEtoC2(connEtoM1Result);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
	return connEtoM1Result;
}
/**
 * connEtoM2:  (JButton2.action.actionPerformed(java.awt.event.ActionEvent) --> VersionsPicker.dispose()V)
 * @param arg1 java.awt.event.ActionEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoM2(java.awt.event.ActionEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.dispose();
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connPtoP1SetTarget:  (versionsData.this <--> JList1.model)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connPtoP1SetTarget() {
	/* Set the target from the source */
	try {
		getJList1().setModel(getversionsData());
		// user code begin {1}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * connPtoP2SetTarget:  (versionsData.this <--> JList11.model)
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connPtoP2SetTarget() {
	/* Set the target from the source */
	try {
		getJList11().setModel(getversionsData());
		// user code begin {1}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * Pre-select the "just-before-latest" and "latest" version
 */
public void doInitialSelections() {
	getJList1().setSelectedIndex(1);
	getJList11().setSelectedIndex(0);
}
/**
 * Method to support listener events.
 * @param event com.magelang.vaj.tool.compareprojver.CompareVersionsEvent
 */
protected void fireCompareVersions(com.magelang.vaj.compareprojver.CompareVersionsEvent event) {
	if (aCompareVersionsListener == null) {
		return;
	};
	aCompareVersionsListener.compareVersions(event);
}
/**
 * The firePropertyChange method was generated to support the propertyChange field.
 * @param propertyName java.lang.String
 * @param oldValue java.lang.Object
 * @param newValue java.lang.Object
 */
public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	getPropertyChange().firePropertyChange(propertyName, oldValue, newValue);
}
/**
 * Return the JButton1 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButton1() {
	if (ivjJButton1 == null) {
		try {
			ivjJButton1 = new com.sun.java.swing.JButton();
			ivjJButton1.setName("JButton1");
			ivjJButton1.setText("Cancel");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButton1;
}
/**
 * Return the JButton2 property value.
 * @return com.sun.java.swing.JButton
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JButton getJButton2() {
	if (ivjJButton2 == null) {
		try {
			ivjJButton2 = new com.sun.java.swing.JButton();
			ivjJButton2.setName("JButton2");
			ivjJButton2.setText("Ok");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJButton2;
}
/**
 * Return the JDialogContentPane property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJDialogContentPane() {
	if (ivjJDialogContentPane == null) {
		try {
			ivjJDialogContentPane = new com.sun.java.swing.JPanel();
			ivjJDialogContentPane.setName("JDialogContentPane");
			ivjJDialogContentPane.setLayout(new java.awt.BorderLayout());
			getJDialogContentPane().add(getJPanel1(), "South");
			getJDialogContentPane().add(getJPanel3(), "Center");
			getJDialogContentPane().add(getJPanel4(), "North");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJDialogContentPane;
}
/**
 * Return the JLabel1 property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JLabel getJLabel1() {
	if (ivjJLabel1 == null) {
		try {
			ivjJLabel1 = new com.sun.java.swing.JLabel();
			ivjJLabel1.setName("JLabel1");
			ivjJLabel1.setText("Select versions of");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJLabel1;
}
/**
 * Return the JList1 property value.
 * @return com.sun.java.swing.JList
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JList getJList1() {
	if (ivjJList1 == null) {
		try {
			ivjJList1 = new com.sun.java.swing.JList();
			ivjJList1.setName("JList1");
			ivjJList1.setBounds(0, 0, 80, 120);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJList1;
}
/**
 * Return the JList11 property value.
 * @return com.sun.java.swing.JList
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JList getJList11() {
	if (ivjJList11 == null) {
		try {
			ivjJList11 = new com.sun.java.swing.JList();
			ivjJList11.setName("JList11");
			ivjJList11.setBounds(0, 0, 80, 120);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJList11;
}
/**
 * Return the JPanel1 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJPanel1() {
	if (ivjJPanel1 == null) {
		try {
			ivjJPanel1 = new com.sun.java.swing.JPanel();
			ivjJPanel1.setName("JPanel1");
			ivjJPanel1.setLayout(getJPanel1FlowLayout());
			getJPanel1().add(getJPanel2(), getJPanel2().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel1;
}
/**
 * Return the JPanel1FlowLayout property value.
 * @return java.awt.FlowLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.FlowLayout getJPanel1FlowLayout() {
	java.awt.FlowLayout ivjJPanel1FlowLayout = null;
	try {
		/* Create part */
		ivjJPanel1FlowLayout = new java.awt.FlowLayout();
		ivjJPanel1FlowLayout.setAlignment(java.awt.FlowLayout.RIGHT);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel1FlowLayout;
}
/**
 * Return the JPanel2 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJPanel2() {
	if (ivjJPanel2 == null) {
		try {
			ivjJPanel2 = new com.sun.java.swing.JPanel();
			ivjJPanel2.setName("JPanel2");
			ivjJPanel2.setLayout(getJPanel2GridLayout());
			getJPanel2().add(getJButton2(), getJButton2().getName());
			ivjJPanel2.add(getJButton1());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel2;
}
/**
 * Return the JPanel2GridLayout property value.
 * @return java.awt.GridLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.GridLayout getJPanel2GridLayout() {
	java.awt.GridLayout ivjJPanel2GridLayout = null;
	try {
		/* Create part */
		ivjJPanel2GridLayout = new java.awt.GridLayout();
		ivjJPanel2GridLayout.setHgap(5);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel2GridLayout;
}
/**
 * Return the JPanel3 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJPanel3() {
	if (ivjJPanel3 == null) {
		try {
			ivjJPanel3 = new com.sun.java.swing.JPanel();
			ivjJPanel3.setName("JPanel3");
			ivjJPanel3.setLayout(getJPanel3GridLayout());
			getJPanel3().add(getJScrollPane1(), getJScrollPane1().getName());
			getJPanel3().add(getJScrollPane11(), getJScrollPane11().getName());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel3;
}
/**
 * Return the JPanel3GridLayout property value.
 * @return java.awt.GridLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.GridLayout getJPanel3GridLayout() {
	java.awt.GridLayout ivjJPanel3GridLayout = null;
	try {
		/* Create part */
		ivjJPanel3GridLayout = new java.awt.GridLayout();
		ivjJPanel3GridLayout.setVgap(5);
		ivjJPanel3GridLayout.setHgap(5);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel3GridLayout;
}
/**
 * Return the JPanel4 property value.
 * @return com.sun.java.swing.JPanel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JPanel getJPanel4() {
	if (ivjJPanel4 == null) {
		try {
			ivjJPanel4 = new com.sun.java.swing.JPanel();
			ivjJPanel4.setName("JPanel4");
			ivjJPanel4.setLayout(getJPanel4BorderLayout());
			getJPanel4().add(getprojectName(), "Center");
			getJPanel4().add(getJLabel1(), "West");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJPanel4;
}
/**
 * Return the JPanel4BorderLayout property value.
 * @return java.awt.BorderLayout
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private java.awt.BorderLayout getJPanel4BorderLayout() {
	java.awt.BorderLayout ivjJPanel4BorderLayout = null;
	try {
		/* Create part */
		ivjJPanel4BorderLayout = new java.awt.BorderLayout();
		ivjJPanel4BorderLayout.setHgap(5);
	} catch (java.lang.Throwable ivjExc) {
		handleException(ivjExc);
	};
	return ivjJPanel4BorderLayout;
}
/**
 * Return the JScrollPane1 property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JScrollPane getJScrollPane1() {
	if (ivjJScrollPane1 == null) {
		try {
			ivjJScrollPane1 = new com.sun.java.swing.JScrollPane();
			ivjJScrollPane1.setName("JScrollPane1");
			getJScrollPane1().setViewportView(getJList1());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPane1;
}
/**
 * Return the JScrollPane11 property value.
 * @return com.sun.java.swing.JScrollPane
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private com.sun.java.swing.JScrollPane getJScrollPane11() {
	if (ivjJScrollPane11 == null) {
		try {
			ivjJScrollPane11 = new com.sun.java.swing.JScrollPane();
			ivjJScrollPane11.setName("JScrollPane11");
			getJScrollPane11().setViewportView(getJList11());
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjJScrollPane11;
}
/**
 * Return the projectName property value.
 * @return com.sun.java.swing.JLabel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public com.sun.java.swing.JLabel getprojectName() {
	if (ivjprojectName == null) {
		try {
			ivjprojectName = new com.sun.java.swing.JLabel();
			ivjprojectName.setName("projectName");
			ivjprojectName.setFont(new java.awt.Font("dialog", 3, 12));
			ivjprojectName.setText("<project name here>");
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjprojectName;
}
/**
 * Method generated to support the promotion of the projectName attribute.
 * @return java.lang.String
 */
public String getProjectNameText() {
	return getprojectName().getText();
}
/**
 * Accessor for the propertyChange field.
 * @return java.beans.PropertyChangeSupport
 */
protected java.beans.PropertyChangeSupport getPropertyChange() {
	if (propertyChange == null) {
		propertyChange = new java.beans.PropertyChangeSupport(this);
	};
	return propertyChange;
}
/**
 * Gets the renderer property (com.sun.java.swing.ListCellRenderer) value.
 * @return The renderer property value.
 * @see #setRenderer
 */
public com.sun.java.swing.ListCellRenderer getRenderer() {
	return getJList1().getCellRenderer();
}
/**
 * Return the versionEventFactory property value.
 * @return com.magelang.vaj.compareprojver.CompareVersionsEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private CompareVersionsEvent getversionEventFactory() {
	// user code begin {1}
	// user code end
	return ivjversionEventFactory;
}
/**
 * Return the versionsData property value.
 * @return com.sun.java.swing.DefaultListModel
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public com.sun.java.swing.DefaultListModel getversionsData() {
	if (ivjversionsData == null) {
		try {
			ivjversionsData = new com.sun.java.swing.DefaultListModel();
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjversionsData;
}
/**
 * Method generated to support the promotion of the versionsData attribute.
 * @return com.sun.java.swing.DefaultListModel
 */
public com.sun.java.swing.DefaultListModel getVersionsData() {
	return getversionsData();
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {

	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getJButton1().addActionListener(this);
	getJButton2().addActionListener(this);
	getprojectName().addPropertyChangeListener(this);
	connPtoP1SetTarget();
	connPtoP2SetTarget();
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	setName("VersionsPicker");
	setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
	setSize(426, 240);
	setTitle("Select Versions...");
	setContentPane(getJDialogContentPane());
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Comment
 */
public void jButton1_ActionPerformed() {
	System.exit(0);
}
/**
 * Method to handle events for the PropertyChangeListener interface.
 * @param evt java.beans.PropertyChangeEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void propertyChange(java.beans.PropertyChangeEvent evt) {
	// user code begin {1}
	// user code end
	if ((evt.getSource() == getprojectName()) && (evt.getPropertyName().equals("text"))) {
		connEtoC3(evt);
	}
	if ((evt.getSource() == getprojectName()) && (evt.getPropertyName().equals("text"))) {
		connEtoC4(evt);
	}
	// user code begin {2}
	// user code end
}
/**
 * 
 * @param newListener com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 */
public void removeCompareVersionsListener(com.magelang.vaj.compareprojver.CompareVersionsListener newListener) {
	aCompareVersionsListener = com.magelang.vaj.compareprojver.CompareVersionsEventMulticaster.remove(aCompareVersionsListener, newListener);
	return;
}
/**
 * The removePropertyChangeListener method was generated to support the propertyChange field.
 * @param listener java.beans.PropertyChangeListener
 */
public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	getPropertyChange().removePropertyChangeListener(listener);
}
/**
 * Method generated to support the promotion of the projectName attribute.
 * @param arg1 java.lang.String
 */
public void setProjectNameText(String arg1) {
	getprojectName().setText(arg1);
}
/**
 * Sets the renderer property (com.sun.java.swing.ListCellRenderer) value.
 * @param renderer The new value for the property.
 * @see #getRenderer
 */
public void setRenderer(com.sun.java.swing.ListCellRenderer renderer) {
	getJList1().setCellRenderer(renderer);
	getJList11().setCellRenderer(renderer);
}
/**
 * Set the versionEventFactory to a new value.
 * @param newValue com.magelang.vaj.compareprojver.CompareVersionsEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void setversionEventFactory(CompareVersionsEvent newValue) {
	if (ivjversionEventFactory != newValue) {
		try {
			ivjversionEventFactory = newValue;
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
}
}