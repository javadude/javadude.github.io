package com.magelang.vaj.compareprojver;

/**
 * A simple renderer that displays project edition info
 */
import com.ibm.ivj.util.base.*;
import java.io.*;
import com.sun.java.swing.*;
import com.sun.java.swing.border.*;

public class ProjectEditionRenderer extends com.sun.java.swing.plaf.basic.BasicListCellRenderer {
	private Workspace workspace;
/**
 * ProjectEditionRenderer constructor comment.
 */
public ProjectEditionRenderer(Workspace workspace) {
	this.workspace = workspace;
}
/**
 * getListCellRendererComponent method comment.
 */
public java.awt.Component getListCellRendererComponent(com.sun.java.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
	try {
		// get the basic renderer (it's a JLabel)
		java.awt.Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

		// find the version names or timestamps
		ProjectEdition ed = (ProjectEdition) value;
		String verName = ed.getVersionName();
		String timeStamp = ed.getVersionStamp().toString();

		// if it's in the workspace we'll add a "*" in front
		boolean loaded = ed.isLoaded();

		// set the text	
		setText(((loaded)?"*":"") + ((verName != null) ? verName : ("(" + timeStamp + ")")));
	}
	catch (Exception e) {
		// log the exception and exit
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush();
		workspace.logMessage("\nException occurred in project comparison:\n" + sw, true);
		System.exit(0);
	}
	return this;
}
}