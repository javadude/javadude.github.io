package com.magelang.vaj.compareprojver;

/**
 * A sample tool that compares two versions of a project
 * Some improvements might be:
 *   * list packages & versions, not just classes
 *   * more efficient sort routine
 */
import com.ibm.ivj.util.base.*;
import java.io.*;
import com.sun.java.swing.*;

public class CompareVer implements CompareVersionsListener {
	// Set up a few instance variables to make method calls simpler...
	private Workspace workspace;
	private Repository repository;

	// A "version picker" dialog that has two lists of versions
	// (both share the same model) and fires an event when the user says "go"
	private VersionsPicker ivjversionsPicker = null;
	private String indent = "";
/**
 * Constructor
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public CompareVer() {
	super();
	initialize();
}
/**
 * Method to handle events for the CompareVersionsListener interface.
 * @param event com.magelang.vaj.compareprojver.CompareVersionsEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
public void compareVersions(CompareVersionsEvent event) {
	// user code begin {1}
	// user code end
	if ((event.getSource() == getversionsPicker()) ) {
		connEtoC1(event);
	}
	// user code begin {2}
	// user code end
}
/**
 * connEtoC1:  (versionsPicker.compareVersions.compareVersions(com.magelang.vaj.compareprojver.CompareVersionsEvent) --> CompareVer.doCompareVersions(Lcom.magelang.vaj.compareprojver.CompareVersionsEvent;)V)
 * @param arg1 com.magelang.vaj.compareprojver.CompareVersionsEvent
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void connEtoC1(CompareVersionsEvent arg1) {
	try {
		// user code begin {1}
		// user code end
		this.doCompareVersions(arg1);
		// user code begin {2}
		// user code end
	} catch (java.lang.Throwable ivjExc) {
		// user code begin {3}
		// user code end
		handleException(ivjExc);
	}
}
/**
 * This method is triggered by the "compareVersions event" from
 * the VersionsPicker dialog.  When the user presses "Ok" on that dialog
 * it fires an event containing the selected version information
 * This allows us to make the dialog non-modal...
 */
public void doCompareVersions(CompareVersionsEvent event) {
	try {
		boolean somethingChanged = false;
		
		// grab the version info from the event
		ProjectEdition v1 = event.getVersion1();
		ProjectEdition v2 = event.getVersion2();
	
		log("Comparing "+v1.getName()+" versions "+getVersionName(v1)+"->"+getVersionName(v2));
		indent = "    ";

		// get a list of the class/interface editions in the project editions
		TypeEdition v1Types[] = v1.getTypeEditions();
		TypeEdition v2Types[] = v2.getTypeEditions();

		// sort the lists -- they don't come sorted
		sortTypeEditions(v1Types);
		sortTypeEditions(v2Types);

		// do a fun compare -- report which versions changed, and which types were
		//   added or removed.
		int i1=0, i2=0;
		while(i1<v1Types.length) {
			String vName1 = getVersionName(v1Types[i1]);
			
			if (i2 >= v2Types.length) {
				log(v1Types[i1].getName() + " " + vName1 + " removed");
				i1++;
				somethingChanged = true;
			}

			else if (v1Types[i1] == v2Types[i2]) {
				i1++; i2++;
			}

			else if (v1Types[i1].getName().equals(v2Types[i2].getName())) {
				String vName2 = getVersionName(v2Types[i2]);
				if (!vName1.equals(vName2)) {
					log(v1Types[i1].getName() + " " + vName1 + "->" + vName2);
					somethingChanged = true;
				}
				i1++; i2++;
			}

			else if (v1Types[i1].getName().compareTo(v2Types[i2].getName()) < 0) {
				log(v1Types[i1].getName() + " " + vName1 + " removed");
				i1++;
				somethingChanged = true;
			}

			else if (v1Types[i1].getName().compareTo(v2Types[i2].getName()) > 0) {
				log(v2Types[i2].getName() + " " + getVersionName(v2Types[i2]) + " added");
				i2++;
				somethingChanged = true;
			}
		}
		while(i2<v2Types.length) {
			log(v2Types[i2].getName() + " " + getVersionName(v2Types[i2]) + " added");
			i2++;
			somethingChanged = true;
		}

		if (!somethingChanged)
			log("No changed types found!");
	}
	catch (Exception e) {
		handleException(e);
	}

	// Kill the GUI thread that the dialog creates	
	System.exit(0);
}
	private String getVersionName(RepositoryModel edition) {
		String name = null;
		try {
			name = edition.getVersionName();
			if (name == null) name = "(" + edition.getVersionStamp().toString() + ")";
			if (edition.isLoaded()) name = "*" + name;
		}
		catch(Exception e) {
			handleException(e);
		}
		return name;
	}
/**
 * Return the versionsPicker property value.
 * @return com.magelang.vaj.compareprojver.VersionsPicker
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private VersionsPicker getversionsPicker() {
	if (ivjversionsPicker == null) {
		try {
			ivjversionsPicker = new com.magelang.vaj.compareprojver.VersionsPicker();
			ivjversionsPicker.setName("versionsPicker");
			ivjversionsPicker.setDefaultCloseOperation(com.sun.java.swing.WindowConstants.DISPOSE_ON_CLOSE);
			// user code begin {1}
			// user code end
		} catch (java.lang.Throwable ivjExc) {
			// user code begin {2}
			// user code end
			handleException(ivjExc);
		}
	};
	return ivjversionsPicker;
}
/**
 * This is the "starting point" for the VAJ tool interaction.
 * It will ask some questions, then pop up a dialog for the user,
 *   which will control the rest of the processing.
 */
public void go(String[] args) {
	// connect to the workspace!
	workspace = ToolEnv.connectToWorkspace();
	
	try {
		Project project;
		
		if (args.length > 0) {
			project = workspace.loadedProjectNamed(args[1]);
		}
		else {
			// ask the user which project to check
			// Note that the project must be in the workspace!
			// We could use a different version of promptForProject that allows
			//   us to pass a list of Project objects, but we'd need to ask the repository
			//   for a list of projects first...  (possible enhancement)
			project = workspace.promptForProject("Select Project...", "Select the project to compare", null);
		}

		// if nothing selected, quit!
		if (project == null) return;

		// get a ref to the repository
		repository = workspace.getRepository();

		// find all editions of the selected project
		ProjectEdition editions[] = repository.getProjectEditions(project.getName());

		// get the JList model, and fill it in with the actual ProjectEdition objects
		DefaultListModel model = getversionsPicker().getVersionsData();

		for(int i = 0; i < editions.length; i++)
			model.addElement(editions[i]);

		// Set up our VersionsPicker and show it	
		getversionsPicker().doInitialSelections();
		getversionsPicker().setLocation(50,50);
		getversionsPicker().setProjectNameText(project.getName());
		// we need a custom renderer to show how to display a ProjectEdition
		getversionsPicker().setRenderer(new ProjectEditionRenderer(workspace));
		getversionsPicker().show();

		// AT THIS POINT, we lose control, and the main thread will end.
		// The AWT thread starts running during the show() call, and it will
		//   handle the rest of the processing.  When the user presses
		//   "Ok", this class' compareVersions method will be called (set up
		//   in the VCE) to do the processing.  If the user presses "Cancel",
		//   the Dialog simply calls System.exit(0).
	}
	catch (Exception e) {
		handleException(e);
	}	
}
/**
 * Called whenever the part throws an exception.
 * @param exception java.lang.Throwable
 */
private void handleException(Throwable exception) {
	// capture the stack trace info and dump it to the VAJ log and exit
	StringWriter sw = new StringWriter();
	PrintWriter pw = new PrintWriter(sw);
	exception.printStackTrace(pw);
	pw.flush();
	log("Exception occurred in project comparison:\n"+sw);
	System.exit(0);
}
/**
 * Initializes connections
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initConnections() {
	// user code begin {1}
	// user code end
	getversionsPicker().addCompareVersionsListener(this);
}
/**
 * Initialize the class.
 */
/* WARNING: THIS METHOD WILL BE REGENERATED. */
private void initialize() {
	// user code begin {1}
	// user code end
	initConnections();
	// user code begin {2}
	// user code end
}
/**
 * Write a message to the VAJ log, and bring it to the front
 */
public void log(String message) {
	workspace.logMessage("\n" + indent + message, true);
}
/**
 * Starts the tool.
 * @param args an array of command-line arguments
 * NOTE that this tool doesn't yet do anything with args
 * For now it forces user to select a project
 */
public static void main(java.lang.String[] args) {
	new CompareVer().go(args);
}
/**
 * A lame bubblesort, sorting based on type name.
 * DON'T GIVE ME A HARD TIME ABOUT THE DAMNED BUBBLESORT!
 * I DIDN"T FEEL LIKE CODING A QUICKSORT RIGHT NOW
 * (It's been a while and I don't feel like thinking too hard
 *  or looking it up...)
 */
private void sortTypeEditions(TypeEdition[] editions) {
	// sort the returned type arrays
	// using a BubbleSort
	for (int i = 0; i < editions.length; i++)
		for (int j = i + 1; j < editions.length; j++)
			if (editions[j].getName().compareTo(editions[i].getName()) < 0) {
				TypeEdition temp = editions[i];
				editions[i] = editions[j];
				editions[j] = temp;
			}
}
}