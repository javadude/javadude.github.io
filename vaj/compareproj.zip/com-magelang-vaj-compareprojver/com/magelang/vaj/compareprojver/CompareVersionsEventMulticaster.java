package com.magelang.vaj.compareprojver;

/**
 * Event multicaster class created by VAJ
 */
public class CompareVersionsEventMulticaster extends java.awt.AWTEventMulticaster implements CompareVersionsListener {
/**
 * Constructor to support multicast events.
 * @param a com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 * @param b com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 */
protected CompareVersionsEventMulticaster(CompareVersionsListener a, CompareVersionsListener b) {
	super(a, b);
}
/**
 * Add new listener to support multicast events.
 * @return com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 * @param a com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 * @param b com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 */
public static CompareVersionsListener add(CompareVersionsListener a, CompareVersionsListener b) {
	if (a == null)  return b;
	if (b == null)  return a;
	return new CompareVersionsEventMulticaster(a, b);
}
/**
 * 
 * @param event com.magelang.vaj.tool.compareprojver.CompareVersionsEvent
 */
public void compareVersions(CompareVersionsEvent event) {
	((CompareVersionsListener)a).compareVersions(event);
	((CompareVersionsListener)b).compareVersions(event);
}
/**
 * Remove listener to support multicast events.
 * @return com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 * @param a com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 * @param b com.magelang.vaj.tool.compareprojver.CompareVersionsListener
 */
public static CompareVersionsListener remove(CompareVersionsListener a, CompareVersionsListener b) {
	return (CompareVersionsListener)removeInternal(a, b);
}
}