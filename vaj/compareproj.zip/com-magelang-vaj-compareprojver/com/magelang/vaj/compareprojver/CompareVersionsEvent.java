package com.magelang.vaj.compareprojver;

/**
 * A simple event class that holds the selected version info
 */
import com.ibm.ivj.util.base.*;
public class CompareVersionsEvent extends java.util.EventObject {
	private ProjectEdition fieldVersion1;
	private ProjectEdition fieldVersion2;
/**
 * CompareVersionsEvent constructor comment.
 * @param source java.lang.Object
 */
public CompareVersionsEvent(java.lang.Object source, ProjectEdition v1, ProjectEdition v2) {
	super(source);
	fieldVersion1 = v1;
	fieldVersion2 = v2;
}
/**
 * Gets the version1 property (java.lang.String) value.
 * @return The version1 property value.
 */
public ProjectEdition getVersion1() {
	return fieldVersion1;
}
/**
 * Gets the version2 property (java.lang.String) value.
 * @return The version2 property value.
 */
public ProjectEdition getVersion2() {
	return fieldVersion2;
}
}