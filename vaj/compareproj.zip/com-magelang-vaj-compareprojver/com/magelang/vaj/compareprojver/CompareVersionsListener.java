package com.magelang.vaj.compareprojver;

/**
 * An interface describing communication between the VersionsPicker
 *   and the CompareVer tool (created by VAJ)
 */
public interface CompareVersionsListener extends java.util.EventListener {
/**
 * Called when a VersionsPicker wants someone to perform a compare
 * @param event com.magelang.vaj.tool.compareprojver.CompareVersionsEvent
 */
void compareVersions(CompareVersionsEvent event);
}