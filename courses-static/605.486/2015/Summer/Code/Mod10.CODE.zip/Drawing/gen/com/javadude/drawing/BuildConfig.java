/** Automatically generated file. DO NOT MODIFY */
package com.javadude.drawing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}