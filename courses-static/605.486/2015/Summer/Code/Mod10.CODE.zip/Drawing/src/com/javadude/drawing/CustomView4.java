package com.javadude.drawing;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class CustomView4 extends View {
	private int cx;
	private int cy;
	private int dx = 10;
	private int dy = 20;
	private Thread mover;
	
	public CustomView4(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		processAttributes(context, attrs);
	}
	public CustomView4(Context context, AttributeSet attrs) {
		super(context, attrs);
		processAttributes(context, attrs);
	}
	public CustomView4(Context context) {
		super(context);
	}
	
	private void processAttributes(Context context, AttributeSet attrs) {
		TypedArray attributes = context.obtainStyledAttributes(attrs, R.styleable.CustomView2);
		color = attributes.getColor(R.styleable.CustomView2_color, 0xff666666);
		attributes.recycle();
	}
	
	private Paint paint;
	private Paint linePaint;
	private Paint fillPaint;
	private int radius;
	private int color;
	private Path path;
	
	private void move() {
		cx += dx;
		cy += dy;
		
		if (cx < radius) {
			dx = -dx;
			cx = radius;
		}
		if (cy < radius) {
			dy = -dy;
			cy = radius;
		}
		if (cx > getWidth() - radius) {
			dx = -dx;
			cx = getWidth() - radius;
		}
		if (cy > getHeight() - radius) {
			dy = -dy;
			cy = getHeight() - radius;
		}
	}
	
	
	private void init() {
		paint = new Paint();
		paint.setColor(color);

		linePaint = new Paint();
		linePaint.setColor(Color.BLACK);
		linePaint.setStyle(Style.STROKE);
		linePaint.setStrokeJoin(Join.ROUND);
		linePaint.setStrokeWidth(getResources().getDimension(R.dimen.stroke_width));

		fillPaint = new Paint();
		fillPaint.setColor(Color.BLUE);
		fillPaint.setStyle(Style.FILL);
		fillPaint.setStrokeJoin(Join.ROUND);
		fillPaint.setStrokeWidth(getResources().getDimension(R.dimen.stroke_width));
		
		mover = new Thread() {
			public void run() {
				while(!isInterrupted()) {
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
					move();
					postInvalidate();				
				}
			}
		};
		
		mover.start();
	}
	
	@Override protected void onDetachedFromWindow() {
		mover.interrupt();
		mover = null;
		paint = null;
		super.onDetachedFromWindow();
	}
	@Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		radius = Math.min(w, h) / 3;
		cx = radius;
		cy = radius;
		path = new Path();
		path.moveTo(10, 10);
		path.lineTo(getWidth() - 10, 10);
		path.lineTo(getWidth() / 2, getHeight() - 10);
		path.close();
	}
	@Override protected void onDraw(Canvas canvas) {
		if (paint == null)
			init();
		canvas.drawColor(Color.WHITE);
		canvas.drawCircle(cx, cy, radius, paint);
		canvas.drawPath(path, fillPaint);
		canvas.drawPath(path, linePaint);
	}
	
	@Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		// DO NOT CALL super.onMeasure(widthMeasureSpec, heightMeasureSpec); !!!!
		int width = determineMeasure(widthMeasureSpec, R.dimen.preferred_width);
		int height = determineMeasure(heightMeasureSpec, R.dimen.preferred_height);
		setMeasuredDimension(width, height);
	}

	private int determineMeasure(int measureSpec, int preferredSizeId) {
		int size = MeasureSpec.getSize(measureSpec);
		int mode = MeasureSpec.getMode(measureSpec);
		int preferredSize = (int) getResources().getDimension(preferredSizeId);
		switch(mode) {
			case MeasureSpec.AT_MOST:
				return Math.min(preferredSize, size);
			case MeasureSpec.EXACTLY:
				return size;
			case MeasureSpec.UNSPECIFIED:
				return preferredSize;
			default:
				throw new IllegalArgumentException("invalid measure mode " + mode);
		}
	}
	
}
