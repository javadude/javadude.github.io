package com.javadude.drawing;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class CustomView3 extends View {
	private int cx;
	private int cy;
	private int dx = 10;
	private int dy = 20;
	private Thread mover;
	
	public CustomView3(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		processAttributes(context, attrs);
	}
	public CustomView3(Context context, AttributeSet attrs) {
		super(context, attrs);
		processAttributes(context, attrs);
	}
	public CustomView3(Context context) {
		super(context);
	}
	
	private void processAttributes(Context context, AttributeSet attrs) {
		TypedArray attributes = context.obtainStyledAttributes(attrs, R.styleable.CustomView2);
		color = attributes.getColor(R.styleable.CustomView2_color, 0xff666666);
		attributes.recycle();
	}
	
	private Paint paint;
	private int radius;
	private int color;
	
	private void move() {
		cx += dx;
		cy += dy;
		
		if (cx < radius) {
			dx = -dx;
			cx = radius;
		}
		if (cy < radius) {
			dy = -dy;
			cy = radius;
		}
		if (cx > getWidth() - radius) {
			dx = -dx;
			cx = getWidth() - radius;
		}
		if (cy > getHeight() - radius) {
			dy = -dy;
			cy = getHeight() - radius;
		}
	}
	
	
	private void init() {
		paint = new Paint();
		paint.setColor(color);
		
		mover = new Thread() {
			public void run() {
				while(!isInterrupted()) {
					try {
						Thread.sleep(50);
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
					move();
					postInvalidate();				
				}
			}
		};
		
		mover.start();
	}
	
	@Override protected void onDetachedFromWindow() {
		mover.interrupt();
		mover = null;
		paint = null;
		super.onDetachedFromWindow();
	}
	@Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		radius = Math.min(w, h) / 3;
		cx = radius;
		cy = radius;
	}
	@Override protected void onDraw(Canvas canvas) {
		if (paint == null)
			init();
		canvas.drawColor(Color.WHITE);
		canvas.drawCircle(cx, cy, radius, paint);
	}
}
