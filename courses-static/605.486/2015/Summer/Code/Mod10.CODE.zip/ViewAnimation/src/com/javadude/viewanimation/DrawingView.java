package com.javadude.viewanimation;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class DrawingView extends View {
    private static final String SONG = "this is the song that doesn't end yes it goes on and on my friends some people started singing it not knowing what it was and they'll continue singing it forever just because";
	private Bitmap scaled;
	private Path path;
	private Paint paint;
	private Animation animation;
    public DrawingView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	public DrawingView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	public DrawingView(Context context) {
		super(context);
	}
	public void start() {
		startAnimation(animation);
	}
	
	private void init() {
		Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.pinwheel);
		int max = Math.max(bitmap.getWidth(), bitmap.getHeight());
		int min = Math.max(getWidth(), getHeight());
		float scale = ((float) min) / max / 3;
		Matrix matrix = new Matrix();
		matrix.preScale(scale, scale);
		scaled = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
		
		path = new Path();
		int cx = getWidth() / 2;
		int cy = getHeight() / 2;
		int screenMin = Math.min(cx, cy);
		path.addCircle(cx, cy, screenMin - 44, Direction.CW);
		
		paint = new Paint();
		paint.setColor(Color.BLACK);
		paint.setAntiAlias(true);
		paint.setTextSize(getResources().getDimension(R.dimen.text_size));

		
		animation = AnimationUtils.loadAnimation(getContext(), R.anim.set);
//		animation = new RotateAnimation(0, 360, getWidth()/2, getHeight()/2);
//		animation.setRepeatCount(2);
//		animation.setRepeatMode(Animation.REVERSE);
//		animation.setInterpolator(new LinearInterpolator());
//		animation.setDuration(2000);
	}
	
	@Override protected void onDraw(Canvas canvas) {
		if (paint == null)
			init();
		canvas.drawTextOnPath(SONG, path, 0, 0, paint);
		
		int x = getWidth() / 2 - scaled.getWidth() / 2;
		int y = getHeight() / 2 - scaled.getHeight() / 2;
		canvas.drawBitmap(scaled, x, y, null);
	}
}
