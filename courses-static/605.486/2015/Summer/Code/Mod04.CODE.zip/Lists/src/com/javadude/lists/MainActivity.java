package com.javadude.lists;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ListView listView = (ListView) findViewById(R.id.listView1);
		
		final String[] data = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
		
		ArrayAdapter<String> arrayAdapter =
				new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, data);

		listView.setAdapter(arrayAdapter);
	
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.d("List", "Clicked " + position);
				Log.d("List", "Clicked " + data[position]);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
