package com.javadude.lists;

import java.util.ArrayList;
import java.util.List;

import com.javadude.lists.TodoList.ChangeListener;

import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

public class TodoListAdapter implements ListAdapter {
	private List<DataSetObserver> observers = new ArrayList<DataSetObserver>();
	@Override public void registerDataSetObserver(DataSetObserver observer) { observers.add(observer); }
	@Override public void unregisterDataSetObserver(DataSetObserver observer) { observers.remove(observer); }

	private TodoList todoList;
	private LayoutInflater layoutInflater;
	
	public TodoListAdapter(TodoList todoList, LayoutInflater layoutInflater) {
		this.todoList = todoList;
		this.layoutInflater = layoutInflater;
		
		todoList.addChangeListener(new ChangeListener() {
			@Override public void changed() {
				for (DataSetObserver observer : observers) {
					observer.onChanged();
				}
			}
		});
	}

	@Override
	public int getCount() {
		return todoList.size();
	}

	@Override
	public Object getItem(int position) {
		return todoList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			if (position % 2 == 0)
				convertView = layoutInflater.inflate(R.layout.even, null);
			else
				convertView = layoutInflater.inflate(R.layout.odd, null);
		}
		
		TextView text1 = (TextView) convertView.findViewById(R.id.text1);
		TextView text2 = (TextView) convertView.findViewById(R.id.text2);
		
		TodoItem todoItem = (TodoItem) getItem(position);
		text1.setText(todoItem.getName());
		text2.setText(String.valueOf(todoItem.getPriority()));

		return convertView;
	}

	@Override
	public int getItemViewType(int position) {
		return position % 2;
	}

	@Override
	public int getViewTypeCount() {
		return 2;
	}

	@Override
	public boolean isEmpty() {
		return todoList.size() == 0;
	}

	@Override
	public boolean areAllItemsEnabled() {
		return true;
	}

	@Override
	public boolean isEnabled(int position) {
		return true;
	}
}
