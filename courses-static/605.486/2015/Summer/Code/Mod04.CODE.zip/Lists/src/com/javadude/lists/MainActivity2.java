package com.javadude.lists;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class MainActivity2 extends Activity {

	private TodoList todoList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ListView listView = (ListView) findViewById(R.id.listView1);
		
		todoList = new TodoList();
		todoList.add(new TodoItem("Wash Car", "Wash the car really well", 2));
		todoList.add(new TodoItem("Wash Cat", "Watch the claws", 15));
		todoList.add(new TodoItem("Fix the garage door", "The door has never worked. Fix it", 3));
		todoList.add(new TodoItem("Something Else", "Blah Blah Blah Blah Blah Blah Blah ", 8));
		
		listView.setAdapter(new TodoListAdapter2(todoList, getLayoutInflater()));
	
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.d("List", "Clicked " + position);
				Log.d("List", "Clicked " + todoList.get(position));
			}
		});
	}
	
	private int n = 42;
	public void addItem(View view) {
		TodoItem newItem = new TodoItem("New" + n, "Display" + n, n);
		n++;
		todoList.add(newItem);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
