package com.javadude.lists;

import java.util.ArrayList;
import java.util.List;

public class TodoList {
	public interface ChangeListener {
		void changed();
	}
	private List<ChangeListener> listeners = new ArrayList<ChangeListener>();
	private List<TodoItem> items = new ArrayList<TodoItem>();

	public void addChangeListener(ChangeListener changeListener) {
		listeners.add(changeListener);
	}
	public void removeChangeListener(ChangeListener changeListener) {
		listeners.remove(changeListener);
	}
	
	public boolean add(TodoItem object) {
		boolean added = items.add(object);
		for (ChangeListener changeListener : listeners) {
			changeListener.changed();
		}
		return added;
	}

	public TodoItem get(int location) {
		return items.get(location);
	}

	public TodoItem remove(int location) {
		TodoItem removed = items.remove(location);
		for (ChangeListener changeListener : listeners) {
			changeListener.changed();
		}
		return removed;
	}

	public int size() {
		return items.size();
	}

	@Override
	public String toString() {
		return "TodoList [items=" + items + "]";
	}
}
