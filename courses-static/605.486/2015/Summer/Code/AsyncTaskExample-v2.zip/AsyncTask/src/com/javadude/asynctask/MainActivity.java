package com.javadude.asynctask;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	private static final int PREPARING = 0;
	private static final int PROCESSING = 1;
	private static final int FINISHING = 2;
	private EditText editText;
	private TextView textView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		editText = (EditText) findViewById(R.id.editText);
		textView = (TextView) findViewById(R.id.text);
	}

	public void onGoButtonPressed(View view) {
		
		// AsyncTask runs processing in a background thread with several 
		//   automatic interactions with the user interface thread.
		//   This allows you to perform background processing that updates or reads data from the user interface
		//   The background thread won't block the user interface updates or user interaction
		//   If we just performed this processing in onGoButtonPressed, you wouldn't see the UI update
		//     until all processing was done.

		// For this example, we start the background task when the button is pressed.
		// First, we display "starting task"
		// The background thread:
		//    - pauses for one second
		//    - calls publishProgress to let the user interface know its state is "preparing" (value=0)
		//    - pauses for one second
		//    - calls publishProgress to let the user interface know its state is "processing" (value=1)
		//    - pauses for one second
		//    - calls publishProgress to let the user interface know its state is "finishing" (value=2)
		//    - pauses for one second
		// Finally, display the result returned from the background thread
		// Each step acquires and releases a lock - this allows us to ensure that processing in publishProgress
		//   has completed before we continue the background processing
		// NOTE: these values are arbitrary. Most often, we'll use publishProgress to update a progress bar.
		//        however, here we use it to change states. For your Jewel-matcher assignment,
		//        you can use this to have onProgressUpdate highlight matches, then remove matches, then add in new jewels
		// ALSO NOTE: The positions of the sleeps() set things up so the background thread will wait for 1 second 
		//            then wait for the lock - if the lock is available, we wait one second; if not we wait until it's
		//            available

		new AsyncTask<String, Integer, String>() {
			private Lock lock = new ReentrantLock();
			
			// Invoked on the user-interface thread BEFORE doInBackground is called
			@Override protected void onPreExecute() {
				textView.setText(R.string.starting_task);
			}

			// Invoked on the user-interface thread AFTER doInBackground completes
			@Override protected void onPostExecute(String result) {
				textView.setText(result);
			}
			
			// Invoked on the user-interface thread whenever publishProgress() is called
			@Override protected void onProgressUpdate(Integer... values) {
				try {
					lock.lock();
					switch(values[0]) {
						case PREPARING:
							textView.setText(R.string.preparing);
							break;
	
						case PROCESSING:
							textView.setText(R.string.processing);
							break;
	
						case FINISHING:
							textView.setText(R.string.finishing);
							break;
					}
				} finally {
					lock.unlock();
				}
			}
			
			@Override
			protected String doInBackground(String... params) {
				try {
					Thread.sleep(1000);
					try {
						lock.lock();
						publishProgress(PREPARING);
					} finally {
						lock.unlock();
					}
					Thread.sleep(1000);
					try {
						lock.lock();
						publishProgress(PROCESSING);
					} finally {
						lock.unlock();
					}
					Thread.sleep(1000);
					try {
						lock.lock();
						publishProgress(FINISHING);
					} finally {
						lock.unlock();
					}
					Thread.sleep(1000);
					try {
						lock.lock();
					} finally {
						lock.unlock();
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
				// based on some criteria you may want to return different value
				// if (error)
				//		return getResources().getString(R.string.error);
				return params[0] + ": " + getResources().getString(R.string.success);
			}
			
		}.execute(editText.getText().toString());  // run the task, passing in any parameters
	}

	public void onBadGoButtonPressed(View view) {
		try {
			// Just to show what happens if you don't use the AsyncTask
			// Note that you won't see any change to the TextField until this is complete; the only
			//   change to the field will be to show the "success" message
			//   You will never see the intermediate values
			// ALSO NOTE THAT THE BUTTON STAYS PRESSED! THE UI IS BLOCKED UNTIL THIS METHOD COMPLETES! 
			textView.setText(R.string.starting_task);
			Thread.sleep(1000);
			textView.setText(R.string.preparing);
			Thread.sleep(1000);
			textView.setText(R.string.processing);
			Thread.sleep(1000);
			textView.setText(R.string.finishing);
			Thread.sleep(1000);
			textView.setText(editText.getText().toString() + ": " + getResources().getString(R.string.success));
		} catch (InterruptedException e) {
			textView.setText(R.string.error);
		} 
	}
}
