package com.javadude.slider;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

public class MainFragment extends Fragment {
	public static interface MainFragmentListener {
		void onToggle(boolean fromLeft);
	}
	private MainFragmentListener mainFragmentListener;
	
	public void setMainFragmentListener(MainFragmentListener mainFragmentListener) {
		this.mainFragmentListener = mainFragmentListener;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.main_frag, container, false);
		final CheckBox fromLeft = (CheckBox) view.findViewById(R.id.fromLeft);
		Button toggleButton = (Button) view.findViewById(R.id.toggleButton);
		toggleButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				mainFragmentListener.onToggle(fromLeft.isChecked());
			}});
		return view;
	}
}
