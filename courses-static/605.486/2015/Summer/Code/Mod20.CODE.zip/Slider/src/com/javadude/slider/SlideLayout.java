package com.javadude.slider;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RelativeLayout;

// Custom layout that adds a percentFromRight property
public class SlideLayout extends RelativeLayout {
	public SlideLayout(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	public SlideLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	public SlideLayout(Context context) {
		super(context);
	}
	
    public int getPercentFromRight() {
    	int width = getWidth();
    	int parentWidth = ((View)getParent()).getWidth();
        return (width == 0) ? 0 : (int)(100 * getX() / (float)(parentWidth-width));
    }

    public void setPercentFromRight(int percent) {
    	int width = getWidth();
    	int parentWidth = ((View)getParent()).getWidth();
        int x = parentWidth - (int) (width * ((float)percent/100));
		setX((width == 0) ? 0 : x);
    }
    
    public int getPercentFromLeft() {
    	int width = getWidth();
    	return (width == 0) ? 0 : (int) (((width + getX()) / (float) width) * 100);
    }
    
    public void setPercentFromLeft(int percent) {
    	int width = getWidth();
    	int x = width - (int) (width * ((float)percent/100));
    	setX((width == 0) ? 0 : -x);
    }
}
