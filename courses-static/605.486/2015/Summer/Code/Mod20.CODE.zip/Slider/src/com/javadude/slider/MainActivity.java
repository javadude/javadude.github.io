package com.javadude.slider;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;

import com.javadude.slider.MainFragment.MainFragmentListener;

public class MainActivity extends Activity {
	private Fragment sideFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		final MainFragment mainFragment = (MainFragment) getFragmentManager().findFragmentById(R.id.mainFragment);
		sideFragment = getFragmentManager().findFragmentById(R.id.sideFragment);
		
		// initially hide the sidebar
		FragmentTransaction tx = getFragmentManager().beginTransaction();
		int parentWidth = ((View) sideFragment.getView().getParent()).getWidth();
		sideFragment.getView().setX(parentWidth);
		tx.hide(sideFragment);
		tx.commit();
		
		// when the main fragment says "I'm toggling", toggle the visibility of the sidebar
		// (I used a button here for simplicity, though you could use a swipe gesture)
		mainFragment.setMainFragmentListener(new MainFragmentListener() {
			@Override public void onToggle(boolean fromLeft) {
				toggleMenu(fromLeft);
			}});
	}
	
	private void toggleMenu(boolean fromLeft) {
		FragmentTransaction tx = getFragmentManager().beginTransaction();
		if (fromLeft) {
			tx.setCustomAnimations(R.anim.enter_left, R.anim.exit_left);
		} else {
			tx.setCustomAnimations(R.anim.enter_right, R.anim.exit_right);
		}
		if (sideFragment.isVisible()) {
			tx.hide(sideFragment);
		} else {
			tx.show(sideFragment);
		}
		tx.commit();
	}
}
