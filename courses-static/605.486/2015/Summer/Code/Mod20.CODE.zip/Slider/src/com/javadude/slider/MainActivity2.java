package com.javadude.slider;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity2 extends Activity {
	private GestureDetector detector;
	private boolean sideBarOnLeft = false;
	private Fragment sideFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		sideFragment = getFragmentManager().findFragmentById(R.id.sideFragment);
		
		// initially hide the sidebar
		FragmentTransaction tx = getFragmentManager().beginTransaction();
		int parentWidth = ((View) sideFragment.getView().getParent()).getWidth();
		sideFragment.getView().setX(parentWidth);
		tx.hide(sideFragment);
		tx.commit();
		
		detector = new GestureDetector(this, new OnGestureListener() {
			@Override public boolean onSingleTapUp(MotionEvent e) { return false; }
			@Override public void onShowPress(MotionEvent e) { }
			@Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) { return false; }
			@Override public void onLongPress(MotionEvent e) { }
			@Override public boolean onDown(MotionEvent e) { return false; }
			@Override public boolean onFling(MotionEvent start, MotionEvent finish, float velocityX, float velocityY) {
				if (velocityX < -30) {
					// swipe left
					if (!sideFragment.isVisible()) {
						// slide it in from right
						toggleMenu(false);
						sideBarOnLeft = false;
					} else if (sideBarOnLeft) {
						toggleMenu(true);
					}
				} else if (velocityX > 30){
					// swipe right
					if (!sideFragment.isVisible()) {
						// slide it in from left
						sideBarOnLeft = true;
						toggleMenu(true);
					} else if (!sideBarOnLeft) {
						toggleMenu(false);
					}
				}
				return true;
			}
		});
	}
	
	private void toggleMenu(boolean fromLeft) {
		FragmentTransaction tx = getFragmentManager().beginTransaction();
		if (fromLeft) {
			tx.setCustomAnimations(R.anim.enter_left, R.anim.exit_left);
		} else {
			tx.setCustomAnimations(R.anim.enter_right, R.anim.exit_right);
		}
		if (sideFragment.isVisible()) {
			tx.hide(sideFragment);
		} else {
			tx.show(sideFragment);
		}
		tx.commit();
	}
	
	// NOTE! NEED TO DELEGATE TOUCH EVENTS TO THE GESTURE DETECTOR!!!
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return detector.onTouchEvent(event);
	}
}
