/** Automatically generated file. DO NOT MODIFY */
package com.javadude.slider;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}