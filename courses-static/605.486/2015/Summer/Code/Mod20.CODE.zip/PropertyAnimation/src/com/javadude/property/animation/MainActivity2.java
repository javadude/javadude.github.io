package com.javadude.property.animation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity2 extends Activity {
	private View layout1;
	private View layout2;

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);
		layout1 = findViewById(R.id.layout1);
		layout2 = findViewById(R.id.layout2);
	}
	public void gotoLayout1(View view) {
		// note that animations don't start until the UI thread has control back from this method

		// animate layout2 sliding from x=0 to x=-layout2.width - it slides left out of view
		layout2.setX(0);
		layout2.setVisibility(View.VISIBLE);
		layout2.animate().alpha(0).x(-layout2.getWidth()).setDuration(500).setListener(new AnimatorListenerAdapter() {
			@Override public void onAnimationEnd(Animator animation) {
				// when the animation stops, make the view invisible
				layout2.setVisibility(View.INVISIBLE);
				layout2.animate().setListener(null);
			}});
		
		// animate layout1 sliding from x=layout1.width to x=0 - it slides left into view
		layout1.setAlpha(1);
		layout1.setX(layout1.getWidth());
		layout1.setVisibility(View.VISIBLE);
		layout1.animate().x(0).setDuration(500);
	}

	public void gotoLayout2(View view) {
		// note that animations don't start until the UI thread has control back from this method
		
		// animate layout2 sliding from x=-layout2.width to x=0 - it slides right into view
		layout2.setX(-layout2.getWidth());
		layout2.setVisibility(View.VISIBLE);
		layout2.animate().x(0).setDuration(500);
		layout2.setAlpha(1);

		// animate layout1 sliding from x=0 to x=layout1.width - it slides right out of view
		layout1.setX(0);
		layout1.setVisibility(View.VISIBLE);
		layout1.animate().alpha(0).x(layout1.getWidth()).setDuration(500).setListener(new AnimatorListenerAdapter() {
			@Override public void onAnimationEnd(Animator animation) {
				// after animation is done, hide layout1
				layout1.setVisibility(View.INVISIBLE);
				layout1.animate().setListener(null);
			}});
	}
	@Override public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
}
