package com.javadude.property.animation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

public class MainActivity3 extends Activity {
	private View layout1;
	private View layout2;

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main2);
		layout1 = findViewById(R.id.layout1);
		layout2 = findViewById(R.id.layout2);
	}
	// concept from the ListFlipper class in the ApiDemos example, but a different implementation 
	public void swapLayout(final View in, final View out) {
		out.animate().rotationY(90).setDuration(500).setListener(new AnimatorListenerAdapter() {
			@Override public void onAnimationEnd(Animator animation) {
				out.setVisibility(View.INVISIBLE);
				in.setVisibility(View.VISIBLE);
				in.setRotationY(-90);
				in.animate().rotationY(0).setDuration(500);
				out.animate().setListener(null);
			}});
	}
	public void gotoLayout1(View view) {
		swapLayout(layout1, layout2);
	}
	public void gotoLayout2(View view) {
		swapLayout(layout2, layout1);
	}
	@Override public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
