package com.javadude.property.animation;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.TextView;

public class MainActivity extends Activity {

	private Person person;
	private TextView nameView;
	private TextView ageView;
	private float y = -1;
	private float x = -1;
	private AnimatorSet animatorSet;

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		nameView = (TextView) findViewById(R.id.name);
		ageView = (TextView) findViewById(R.id.age);
		person = new Person();
		
		person.addPropertyChangeListener("name", new PropertyChangeListener() {
			@Override public void propertyChange(PropertyChangeEvent arg0) {
				nameView.setText(person.getName());
			}});
		person.addPropertyChangeListener("age", new PropertyChangeListener() {
			@Override public void propertyChange(PropertyChangeEvent arg0) {
				ageView.setText(person.getAge() + "");
			}});
		
		person.setName("Scott");
		person.setAge(0);
	}
	public void startAging(View view) {
		if (x == -1) {
			x = nameView.getX();
			y = nameView.getY();
		}
		nameView.setX(x);
		nameView.setY(y);
		nameView.setRotationY(0);

		ObjectAnimator ageAnimator = ObjectAnimator.ofInt(person, "age", 0, 100);
		ageAnimator.addListener(new AnimatorListener() {
			@Override public void onAnimationStart(Animator animation) {
				nameView.setText(person.getName());
			}
			@Override public void onAnimationRepeat(Animator animation) {
			}
			@Override public void onAnimationEnd(Animator animation) {
				if (person.getAge() == 100) {
					nameView.setText("Dead " + person.getName());
				}
			}
			@Override public void onAnimationCancel(Animator animation) {
				nameView.setText("Frozen " + person.getName());
			}
		});
		
		animatorSet = new AnimatorSet();
		animatorSet.playTogether(
				ObjectAnimator.ofFloat(nameView, "rotationY", 0, 180),
				ObjectAnimator.ofFloat(nameView, "y", 0, 600),
				ageAnimator
				);
		animatorSet.setDuration(5000);
		animatorSet.setInterpolator(new AccelerateDecelerateInterpolator());
		animatorSet.start();
	}
	public void stopAging(View view) {
		if (animatorSet != null && animatorSet.isRunning()) {
			animatorSet.cancel();
			animatorSet = null;
		}
	}
	public void reverseAging(View view) {
		if (animatorSet != null && animatorSet.isRunning()) {
			// there's no reverse at the set level... must reverse each part individually... sigh...
			ArrayList<Animator> childAnimations = animatorSet.getChildAnimations();
			for (Animator animator : childAnimations) {
				((ObjectAnimator)animator).reverse();
			}
		}
	}

	@Override public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
