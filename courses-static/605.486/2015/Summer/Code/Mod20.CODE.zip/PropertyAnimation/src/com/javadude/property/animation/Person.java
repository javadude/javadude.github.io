package com.javadude.property.animation;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

public class Person {
	private String name;
	private int age;
	private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
	
	public void addPropertyChangeListener(PropertyChangeListener listener) {
		pcs.addPropertyChangeListener(listener);
	}
	public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		pcs.addPropertyChangeListener(propertyName, listener);
	}
	public void removePropertyChangeListener(PropertyChangeListener listener) {
		pcs.removePropertyChangeListener(listener);
	}
	public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		pcs.removePropertyChangeListener(propertyName, listener);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		String old = this.name;
		this.name = name;
		pcs.firePropertyChange("name", old, name);
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		int old = this.age;
		this.age = age;
		pcs.firePropertyChange("age", old, age);
	}
}
