/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\android\\workspace-x\\Services\\src\\com\\javadude\\services2\\RemoteService2Reporter.aidl
 */
package com.javadude.services2;
public interface RemoteService2Reporter extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.javadude.services2.RemoteService2Reporter
{
private static final java.lang.String DESCRIPTOR = "com.javadude.services2.RemoteService2Reporter";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.javadude.services2.RemoteService2Reporter interface,
 * generating a proxy if needed.
 */
public static com.javadude.services2.RemoteService2Reporter asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.javadude.services2.RemoteService2Reporter))) {
return ((com.javadude.services2.RemoteService2Reporter)iin);
}
return new com.javadude.services2.RemoteService2Reporter.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_report:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.report(_arg0);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.javadude.services2.RemoteService2Reporter
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
@Override public void report(int n) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(n);
mRemote.transact(Stub.TRANSACTION_report, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_report = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
}
public void report(int n) throws android.os.RemoteException;
}
