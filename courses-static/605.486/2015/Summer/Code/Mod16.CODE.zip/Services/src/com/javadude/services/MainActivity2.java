package com.javadude.services;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;

import com.javadude.services.BoundService1.Reporter;
import com.javadude.services.BoundService1.SampleServiceBinder;

public class MainActivity2 extends Activity {
	private Reporter reporter = new Reporter() {
		@Override public void report(final int n) {
			Log.d("MainActivity reporter", n+"");
			runOnUiThread(new Runnable() {
				@Override public void run() {
					setProgress(n * 1000);
				}});
		}};
		
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStop() {
    	Log.d("Main", "onStop");
    	sampleService.removeReporter(reporter);
    	unbindService(serviceConnection);
    	super.onStop();
    }
    @Override
    protected void onStart() {
    	Log.d("Main", "onStart");
    	Intent intent = new Intent(this, BoundService1.class);
    	bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    	super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void onResetCounterPressed(View view) {
    	// need to talk to service
    	if (sampleService != null)
    		sampleService.resetCounter();
    }

    public void onOtherActivityPressed(View view) {
    	startActivity(new Intent(this, OtherActivity.class));
    }
    
    private BoundService1.SampleServiceBinder sampleService;
    
    private ServiceConnection serviceConnection = new ServiceConnection() {
		@Override public void onServiceDisconnected(ComponentName name) {
			sampleService = null;
		}
		@Override public void onServiceConnected(ComponentName name, IBinder service) {
			sampleService = (SampleServiceBinder) service;
			sampleService.addReporter(reporter);
		}
	};
}
