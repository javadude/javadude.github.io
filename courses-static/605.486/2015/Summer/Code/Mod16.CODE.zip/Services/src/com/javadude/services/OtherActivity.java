package com.javadude.services;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.View;

import com.javadude.services.BoundService1.Reporter;
import com.javadude.services.BoundService1.SampleServiceBinder;

public class OtherActivity extends Activity {
	private Reporter reporter = new Reporter() {
		@Override public void report(int n) {
			Log.d("OtherActivity reporter", n+"");
		}};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    @Override
    protected void onStart() {
    	Log.d("2", "onStart");
    	super.onStart();
    	bindService(new Intent(this, BoundService1.class), serviceConnection, Context.BIND_AUTO_CREATE);
    }
    @Override
    protected void onStop() {
    	Log.d("2", "onStop");
    	sampleService.removeReporter(reporter);
    	unbindService(serviceConnection);
    	super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void onResetCounterPressed(View view) {
    	// need to talk to service
    	if (sampleService != null)
    		sampleService.resetCounter();
    }

    private BoundService1.SampleServiceBinder sampleService;
    
    private ServiceConnection serviceConnection = new ServiceConnection() {
		@Override public void onServiceDisconnected(ComponentName name) {
			sampleService = null;
		}
		@Override public void onServiceConnected(ComponentName name, IBinder service) {
			sampleService = (SampleServiceBinder) service;
			sampleService.addReporter(reporter);
		}
	};

}
