package com.javadude.services;

import java.util.ArrayList;
import java.util.List;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class BoundService1 extends Service {
	public class SampleServiceBinder extends Binder {
		public void resetCounter() {
			BoundService1.this.resetCounter();
		}
		public void addReporter(Reporter reporter) {
			reporters.add(reporter);
		}
		public void removeReporter(Reporter reporter) {
			reporters.remove(reporter);
		}
	}
	private List<Reporter> reporters = new ArrayList<Reporter>();
	private IBinder binder = new SampleServiceBinder();
	public interface Reporter {
		void report(int n);
	}
	@Override
	public IBinder onBind(Intent intent) {
		Toast.makeText(this, "onBind", Toast.LENGTH_SHORT).show();
		Log.d("SampleService", "onBind(" + intent + ")");
		serviceThread = new ServiceThread();
		serviceThread.start();
		return binder;
	}
	@Override
	public boolean onUnbind(Intent intent) {
		Toast.makeText(this, "onUnbind", Toast.LENGTH_SHORT).show();
		Log.d("SampleService", "onUnbind(" + intent + ")");
		return super.onUnbind(intent);
	}
	
	private int n = 0;
	private class ServiceThread extends Thread {
		@Override public void run() {
			while(!isInterrupted()) {
				n++;
				for (Reporter reporter : reporters) {
					reporter.report(n);
				}
				Log.d("SampleService", "running... " + n);
				try {
					sleep(1000);
				} catch (InterruptedException e) {
					interrupt();
				}
			}
			Log.d("SampleService", "interrupted");
		}
	}
	
	private ServiceThread serviceThread;
	
	public void resetCounter() {
		n = 0; 
		// race condition: chance that it could be set in the middle of (n++) above! 
		// could make it volatile or sync access to it, but does it matter?
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this, "onCreate", Toast.LENGTH_SHORT).show();
		Log.d("SampleService", "onCreate");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d("SampleService", "onStartCommand(" + intent + ", " + flags + ", " + startId + ")");
		Toast.makeText(this, "onStartCommand", Toast.LENGTH_SHORT).show();
		serviceThread = new ServiceThread();
		serviceThread.start();
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		if (serviceThread != null) {
			serviceThread.interrupt();
			serviceThread = null;
		}
		Toast.makeText(this, "onDestroy", Toast.LENGTH_SHORT).show();
		Log.d("SampleService", "onDestroy");
		super.onDestroy();
	}

}
