package com.javadude.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class SampleService extends Service {
	@Override
	public void onCreate() {
		super.onCreate();
		Log.d("SampleService", "onCreate");
	}

	private ServiceThread serviceThread;
	private class ServiceThread extends Thread {
		@Override public void run() {
			for (int i = 0; !isInterrupted() && i < 100; i++) {
				Log.d("SampleService", "running... " + i);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					interrupt();
				}
			}
			stopSelf();
		}
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d("SampleService", "onStartCommand(" + intent + ", " + flags + ", " + startId + ")");
		serviceThread = new ServiceThread();
		serviceThread.start();
		return super.onStartCommand(intent, flags, startId);
	}

	@Override
	public void onDestroy() {
		if (serviceThread != null) {
			serviceThread.interrupt();
			serviceThread = null;
		}
		Log.d("SampleService", "onDestroy");
		super.onDestroy();
	}

	@Override
	public IBinder onBind(Intent intent) {
		Log.d("SampleService", "onBind(" + intent + ")");
		return null;
	}
}
