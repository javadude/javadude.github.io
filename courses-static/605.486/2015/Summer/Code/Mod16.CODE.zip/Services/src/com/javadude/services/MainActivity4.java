package com.javadude.services;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.javadude.services2.RemoteService2;
import com.javadude.services2.RemoteService2Reporter;

public class MainActivity4 extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStop() {
    	Log.d("Main", "onStop");
		try {
			remoteService2.remove(reporter);
		} catch (RemoteException e) {
			Log.e("MainActivity4", "addReporter", e);
		}
    	unbindService(serviceConnection);
    	super.onStop();
    }
    @Override
    protected void onStart() {
    	Log.d("Main", "onStart");
    	Intent intent = new Intent("com.javadude.services2.RemoteService2");
    	if (!bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE))
    		Toast.makeText(getBaseContext(), "Could not bind to service", Toast.LENGTH_LONG).show();
    	super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void onResetCounterPressed(View view) {
    	try {
			remoteService2.reset();
		} catch (RemoteException e) {
			Log.e("MainActivity4", "reset error", e);
		}
    }

    public void onActivity2Pressed(View view) {
    	startActivity(new Intent(this, OtherActivity.class));
    }

    private RemoteService2 remoteService2;
    private ServiceConnection serviceConnection = new ServiceConnection() {
		@Override public void onServiceDisconnected(ComponentName name) {
			remoteService2 = null;
		}
		@Override public void onServiceConnected(ComponentName name, IBinder service) {
			remoteService2 = RemoteService2.Stub.asInterface(service);
			try {
				remoteService2.add(reporter);
			} catch (RemoteException e) {
				Log.e("MainActivity4", "addReporter", e);
			}
		}
	};
	
	private RemoteService2Reporter reporter = new RemoteService2Reporter.Stub() {
		@Override public void report(final int n) throws RemoteException {
			runOnUiThread(new Runnable() {
				@Override public void run() {
					setProgress(n * 1000);
				}});
		}};
}
