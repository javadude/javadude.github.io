package com.javadude.services;

import java.lang.ref.WeakReference;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;

public class MainActivity3 extends Activity {
	private static final int REPORT = 2;
	
	private static class MyHandler extends Handler {
		private WeakReference<MainActivity3> ref;
		public MyHandler(MainActivity3 mainActivity3) {
			ref = new WeakReference<MainActivity3>(mainActivity3);
		}
		
		public void handleMessage(final Message msg) {
			switch(msg.what) {
				case REPORT:
					ref.get().runOnUiThread(new Runnable() {
						@Override public void run() {
							ref.get().setProgress(msg.arg1 * 1000);
						}});
					return;
				default:
					super.handleMessage(msg);
			}
		}
	}
	
	private Messenger messenger = new Messenger(new MyHandler(this));
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_PROGRESS);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStop() {
    	Log.d("Main", "onStop");
		Message message = Message.obtain(null, 3); // REMOVE REPORTER CALL - SHOULD SET UP LIB PROJECT TO SHARE CONSTANTS
		message.replyTo = messenger;
		try {
			remoteService.send(message);
		} catch (RemoteException e) {
			Log.e("MainActivity3", "error", e);
		}
    	unbindService(serviceConnection);
    	super.onStop();
    }
    @Override
    protected void onStart() {
    	Log.d("Main", "onStart");
    	Intent intent = new Intent("com.javadude.services2.RemoteService1");
    	bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    	super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void onResetCounterPressed(View view) {
    	Message message = Message.obtain(null, 1, 0, 0); // RESET CALL - SHOULD SET UP LIB PROJECT TO SHARE CONSTANTS
    	try {
			remoteService.send(message);
		} catch (RemoteException e) {
			Log.e("MainActivity3", "error", e);
		}
    }

    public void onActivity2Pressed(View view) {
    	startActivity(new Intent(this, OtherActivity.class));
    }
    
    private Messenger remoteService;
    
    private ServiceConnection serviceConnection = new ServiceConnection() {
		@Override public void onServiceDisconnected(ComponentName name) {
			remoteService = null;
		}
		@Override public void onServiceConnected(ComponentName name, IBinder service) {
			remoteService = new Messenger(service);
			Message message = Message.obtain(null, 2); // ADD REPORTER CALL - SHOULD SET UP LIB PROJECT TO SHARE CONSTANTS
			message.replyTo = messenger;
			try {
				remoteService.send(message);
			} catch (RemoteException e) {
				Log.e("MainActivity3", "error", e);
			}
		}
	};
}
