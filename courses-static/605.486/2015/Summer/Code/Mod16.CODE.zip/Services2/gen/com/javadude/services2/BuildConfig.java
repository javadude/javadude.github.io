/** Automatically generated file. DO NOT MODIFY */
package com.javadude.services2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}