package com.javadude.services2;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;

public class RemoteService1 extends Service {
	public static final int RESET = 1;
	public static final int ADD_REPORTER = 2;
	public static final int REMOTE_REPORTER = 3;
	
	private static class MyHandler extends Handler {
		private WeakReference<RemoteService1> serviceRef;
		public MyHandler(RemoteService1 service) {
			serviceRef = new WeakReference<RemoteService1>(service);
		}
		
		@Override public void handleMessage(Message msg) {
			switch(msg.what) {
				case RESET:
					serviceRef.get().resetCounter();
					return;
				case ADD_REPORTER:
					serviceRef.get().reporters.add(msg.replyTo);
					return;
				case REMOTE_REPORTER:
					serviceRef.get().reporters.remove(msg.replyTo);
					return;
				default:
					super.handleMessage(msg);
			}
		}
	}

	private Messenger messenger = new Messenger(new MyHandler(this));
	
	private List<Messenger> reporters = new ArrayList<Messenger>();
	@Override
	public IBinder onBind(Intent intent) {
		Toast.makeText(this, "onBind", Toast.LENGTH_SHORT).show();
		Log.d("RemoteService1", "onBind(" + intent + ")");
		serviceThread = new ServiceThread();
		serviceThread.start();
		return messenger.getBinder();
	}
	@Override
	public boolean onUnbind(Intent intent) {
		Toast.makeText(this, "onUnbind", Toast.LENGTH_SHORT).show();
		Log.d("RemoteService1", "onUnbind(" + intent + ")");
		return super.onUnbind(intent);
	}
	
	private int n = 0;
	private class ServiceThread extends Thread {
		@Override public void run() {
			while(!isInterrupted()) {
				Message message = Message.obtain(null, 2, n++, 0);
				for (Messenger messenger : reporters) {
					try {
						messenger.send(message);
					} catch (RemoteException e) {
						Log.e("RemoteService", "report error", e);
					}
				}
				Log.d("RemoteService1", "running... " + n);
				try {
					sleep(1000);
				} catch (InterruptedException e) {
					interrupt();
				}
			}
			Log.d("RemoteService1", "interrupted");
		}
	}
	
	private ServiceThread serviceThread;
	
	public void resetCounter() {
		n = 0; 
		// race condition: chance that it could be set in the middle of (n++) above! 
		// could make it volatile or sync access to it, but does it matter?
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this, "onCreate", Toast.LENGTH_SHORT).show();
		Log.d("RemoteService1", "onCreate");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		Log.d("RemoteService1", "onStartCommand(" + intent + ", " + flags + ", " + startId + ")");
		Toast.makeText(this, "onStartCommand", Toast.LENGTH_SHORT).show();
		serviceThread = new ServiceThread();
		serviceThread.start();
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		if (serviceThread != null) {
			serviceThread.interrupt();
			serviceThread = null;
		}
		Toast.makeText(this, "onDestroy", Toast.LENGTH_SHORT).show();
		Log.d("RemoteService1", "onDestroy");
		super.onDestroy();
	}

}
