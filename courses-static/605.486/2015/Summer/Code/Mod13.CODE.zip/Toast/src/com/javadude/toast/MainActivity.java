package com.javadude.toast;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Button toastLong = (Button) findViewById(R.id.toastLong);
		Button toastShort = (Button) findViewById(R.id.toastShort);
		toastLong.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				Toast.makeText(getBaseContext(), "Hello there!", Toast.LENGTH_LONG).show();
			}});
		toastShort.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				Toast.makeText(getBaseContext(), "Goodbye there!", Toast.LENGTH_SHORT).show();
			}});
	}

	@Override public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
