package com.javadude.notifications;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.view.Menu;
import android.view.View;

public class MainActivity extends Activity {
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void cancelNotification1(View view) {
		cancelNotification(1);
	}
	public void cancelNotification2(View view) {
		cancelNotification(2);
	}
	public void cancelAll(View view) {
		NotificationManager notificationManager =
				(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.cancelAll();
	}
	public void createNotification1(View view) {
		createNotification(1);
	}
	public void createNotification2(View view) {
		createNotification(2);
	}
	private void cancelNotification(int n) {
		NotificationManager notificationManager =
				(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.cancel(n);
	}
	
	private PendingIntent createPending(int requestId, int n, String action) {
		Intent detailIntent = new Intent(this, DetailActivity.class);
		detailIntent.putExtra("data", n);
		detailIntent.putExtra("action", action);
		
		TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
		stackBuilder.addParentStack(DetailActivity.class);
		stackBuilder.addNextIntent(detailIntent);
		return stackBuilder.getPendingIntent(requestId, PendingIntent.FLAG_UPDATE_CURRENT );
	}
	
	private void createNotification(int n) {
		NotificationCompat.InboxStyle inboxStyle = 
				new NotificationCompat.InboxStyle()
					.setBigContentTitle("Details")
					.setSummaryText("Hello World")
					.addLine("Item 1")
					.addLine("Item 2")
					.addLine("Item 3");

		PendingIntent detailPendingIntent = createPending(n, n, "Details");

		PendingIntent playPendingIntent = createPending(n+10, n, "Play");
		PendingIntent stopPendingIntent = createPending(n+20, n, "Stop");
		
		Bitmap icon = BitmapFactory.decodeResource(getResources(), android.R.drawable.ic_menu_gallery);
		Notification notification =
				new NotificationCompat.Builder(this)
						.setNumber(10)
						.setStyle(inboxStyle)
						.setTicker("This is sample notification " + n + ". Wooohoo!")
						.setLargeIcon(icon)
						.setAutoCancel(true)
						.setOngoing(true)
						.setSmallIcon(android.R.drawable.ic_menu_directions)
						.setContentTitle("Sample notification " + n)
						.setContentText("Hello World!")
						.setContentIntent(detailPendingIntent)
						.addAction(R.drawable.ic_action_play, "Play", playPendingIntent)
						.addAction(R.drawable.ic_action_stop, "Stop", stopPendingIntent)
						.build();
		
		NotificationManager notificationManager =
				(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		notificationManager.notify(n, notification);
	}}
