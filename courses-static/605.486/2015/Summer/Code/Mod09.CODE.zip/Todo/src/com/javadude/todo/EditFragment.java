package com.javadude.todo;

import java.util.Calendar;

import com.javadude.todo.DatePickerDialogFragment.OnDatePickerDialogFragmentDateSetListener;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class EditFragment extends Fragment implements OnDatePickerDialogFragmentDateSetListener {
	public interface EditFragmentListener {
		void onDone(TodoItem item);
		void onCancel();
	}
	
	private static final int ANNIVERSARY = 1;
	private static final int BIRTHDAY = 2;

	private EditFragmentListener editFragmentListener;
	
	public void setEditFragmentListener(EditFragmentListener editFragmentListener) {
		this.editFragmentListener = editFragmentListener;
	}

	private TodoItem item;
	private EditText name;
	private EditText description;
	private EditText priority;
	private Button birthdayButton;
	private Button anniversaryButton;
	private Calendar birthday = Calendar.getInstance();
	private Calendar anniversary = Calendar.getInstance();
	
	public void setTodoItemId(long todoItemId) {
		if (todoItemId != -1) {
			item = TodoContentProvider.findTodo(getActivity(), todoItemId);            /*!!!!!!!!*/
		} else {
			item = new TodoItem("", "", 1);                                   /*!!!!!!!!*/
		}
			
		name.setText(item.getName());
		description.setText(item.getDisplayName());
		priority.setText(String.valueOf(item.getPriority()));
	}
	
	
	@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_edit, container, false);
		
		name = (EditText) view.findViewById(R.id.name);
		description = (EditText) view.findViewById(R.id.description);
		priority = (EditText) view.findViewById(R.id.priority);
		birthdayButton = (Button) view.findViewById(R.id.birthdayButton);
		anniversaryButton = (Button) view.findViewById(R.id.anniversaryButton);

		if (savedInstanceState != null) {
			birthday.setTimeInMillis(savedInstanceState.getLong("birthday"));
			anniversary.setTimeInMillis(savedInstanceState.getLong("anniversary"));
		} else {
			birthday.set(1966, 11, 15);
			anniversary.set(2000, 0, 1);
		}
		updateDateButtonText("Birthday", birthdayButton, birthday);
		updateDateButtonText("Anniversary", anniversaryButton, anniversary);
		
		birthdayButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				DatePickerDialogFragment fragment = DatePickerDialogFragment.create(EditFragment.this, BIRTHDAY, birthday);
				fragment.show(getActivity().getSupportFragmentManager(), "setting birthday");
			}});
		anniversaryButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				DatePickerDialogFragment fragment = DatePickerDialogFragment.create(EditFragment.this, ANNIVERSARY, anniversary);
				fragment.show(getActivity().getSupportFragmentManager(), "setting anniversary");
			}});
		
		
		setHasOptionsMenu(true);
		return view;
	}
	
	@Override public void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		outState.putLong("birthday", birthday.getTimeInMillis());
		outState.putLong("anniversary", anniversary.getTimeInMillis());
	}
	private void updateDateButtonText(String header, Button button, Calendar calendar) {
		button.setText(header + ": " + calendar.get(Calendar.YEAR) + "-" + 
								(calendar.get(Calendar.MONTH) + 1) + "-" + 
								calendar.get(Calendar.DAY_OF_MONTH));
	}
	
	@Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// Inflate the menu; this adds items to the action bar if it is present.
		inflater.inflate(R.menu.edit, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_cancel:
				if (editFragmentListener == null)
					throw new RuntimeException("You must set an EditFragmentListener");
				editFragmentListener.onCancel();
				return true;
			case R.id.action_done:
				this.item.setName(name.getText().toString());
				this.item.setDisplayName(description.getText().toString());
				this.item.setPriority(Integer.parseInt(priority.getText().toString()));
				
				TodoContentProvider.updateTodo(getActivity(), this.item);              /*!!!!!!!!*/
				if (editFragmentListener == null)
					throw new RuntimeException("You must set an EditFragmentListener");
				editFragmentListener.onDone(this.item);
				
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}


	@Override public void onDateSet(int dateId, int year, int month, int day) {
		switch(dateId) {
			case ANNIVERSARY:
				anniversary.set(year, month, day);
				updateDateButtonText("Anniversary", anniversaryButton, anniversary);
				break;
			case BIRTHDAY:
				birthday.set(year, month, day);
				updateDateButtonText("Birthday", birthdayButton, birthday);
				break;
			default:
				throw new IllegalStateException("unexpected dateId " + dateId);
		}
	}

}
