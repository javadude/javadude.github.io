package com.javadude.todo;

import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SimpleCursorAdapter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class ListFragment extends Fragment {
	public interface ListFragmentListener {
		void onCreate();
		void onEdit(long id);
	}
	private ListFragmentListener listFragmentListener;
	
	public void setListFragmentListener(ListFragmentListener listFragmentListener) {
		this.listFragmentListener = listFragmentListener;
	}

	private static final int TODO_LOADER = 1;
	private SimpleCursorAdapter cursorAdapter;

	@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_list, container, false);
		
		listView = (ListView) view.findViewById(R.id.listView1);
		
		String[] from = {
				TodoContentProvider.ID,
				TodoContentProvider.NAME,
				TodoContentProvider.DESCRIPTION
		};
		int[] to = {
				-1, // id not displayed in the layout
				R.id.text1,
				R.id.text2
		};

		cursorAdapter = new SimpleCursorAdapter(getActivity(), R.layout.odd, null, from, to, 0);
		listView.setAdapter(cursorAdapter);

		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (listFragmentListener == null)
					throw new RuntimeException("You must register a ListFragmentListener");
				listFragmentListener.onEdit(id);
			}
		});
		
		// start asynchronous loading of the cursor
        getActivity().getSupportLoaderManager().initLoader(TODO_LOADER, null, loaderCallbacks);
        
        setHasOptionsMenu(true);
        return view;
	}
	
	@Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// Inflate the menu; this adds items to the action bar if it is present.
		inflater.inflate(R.menu.main, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_new:
				// bring up the edit activity
				if (listFragmentListener == null)
					throw new RuntimeException("You must register a ListFragmentListener");
				listFragmentListener.onCreate();
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}

    private LoaderCallbacks<Cursor> loaderCallbacks = new LoaderCallbacks<Cursor>() {
		@Override
		public Loader<Cursor> onCreateLoader(int loaderId, Bundle bundle) {
			String[] projection = {
					TodoContentProvider.ID, 
					TodoContentProvider.NAME, 
					TodoContentProvider.DESCRIPTION};
			return new CursorLoader(
					getActivity(), 
					TodoContentProvider.CONTENT_URI, 
					projection, 
					null, null, // selection & args
					TodoContentProvider.NAME + " asc");
		}

		@Override
		public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
			cursorAdapter.swapCursor(cursor); // set the data
		}

		@Override
		public void onLoaderReset(Loader<Cursor> cursor) {
			cursorAdapter.swapCursor(null); // clear the data
		}
	};
	private ListView listView;

	public long getSelectedId() {
		return listView.getAdapter().getItemId(listView.getCheckedItemPosition());
	}
}

