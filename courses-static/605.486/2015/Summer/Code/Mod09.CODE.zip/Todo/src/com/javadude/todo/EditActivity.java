package com.javadude.todo;

import com.javadude.todo.EditFragment.EditFragmentListener;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class EditActivity extends ActionBarActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit);
		
		EditFragment editFragment = 
				(EditFragment) getSupportFragmentManager().findFragmentById(R.id.editFragment);

		long todoItemId = getIntent().getLongExtra("todoItemId", -1);         /*!!!!!!!!*/
		editFragment.setTodoItemId(todoItemId);
		
		editFragment.setEditFragmentListener(new EditFragmentListener() {
			@Override public void onDone(TodoItem item) {
				getIntent().putExtra("todoItemId", item.getId());
				finish();
			}
			@Override public void onCancel() {
				finish();
			}
		});
	}
}
