/** Automatically generated file. DO NOT MODIFY */
package com.javadude.files2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}