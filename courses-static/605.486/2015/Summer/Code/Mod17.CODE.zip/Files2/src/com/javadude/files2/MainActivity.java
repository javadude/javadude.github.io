package com.javadude.files2;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView text = (TextView) findViewById(R.id.text);
        try {
			FileInputStream in = createPackageContext("com.javadude.files1",0).openFileInput("sample.txt");
			InputStreamReader isr = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(isr);
			String line;
			while((line = br.readLine()) != null) {
				text.append("\n");
				text.append(line);
			}
			br.close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
