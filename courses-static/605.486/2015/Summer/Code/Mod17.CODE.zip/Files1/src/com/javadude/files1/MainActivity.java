package com.javadude.files1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        try {
			FileOutputStream fos = openFileOutput("sample.txt", Context.MODE_WORLD_READABLE);
			OutputStreamWriter osw = new OutputStreamWriter(fos);
			PrintWriter pw = new PrintWriter(osw);
			pw.println("This is line 1");
			pw.println("This is line 2");
			pw.println("This is line 3");
			pw.close();
			
			// look at file in emulator using adb shell: /data/data/com.javadude.files1/files/sample.txt
			// try on rooted phone; non-rooted phone
			
			String externalStorageState = Environment.getExternalStorageState();
			if (Environment.MEDIA_MOUNTED.equals(externalStorageState)) {
				File externalFilesDir = getExternalFilesDir(null);
				File outFile = new File(externalFilesDir, "sample2.txt");
				pw = new PrintWriter(outFile);
				pw.println("This is line 1a");
				pw.println("This is line 2a");
				pw.println("This is line 3a");
				pw.close();
				// try to read on rooted phone; note that su not needed in adb shell
				// requires WRITE_EXTERNAL_STORAGE permission (exception is a bit cryptic - try without)
				//    /sdcard/Android/data/com.javadude.files1/files/sample2.txt

				// BOTH OF ABOVE GO AWAY WHEN APP UNINSTALLED!
				
				
			} else {
				Log.d("EXTERNAL STORAGE STATE", externalStorageState);
			}

			File externalFilesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC);
			File outFile = new File(externalFilesDir, "sample3.txt");
			pw = new PrintWriter(outFile);
			pw.println("This is line 1b");
			pw.println("This is line 2b");
			pw.println("This is line 3b");
			pw.close();
			
			// try to read on rooted phone; note that su not needed in adb shell
			// requires WRITE_EXTERNAL_STORAGE permission (exception is a bit cryptic - try without)
			//    /sdcard/Music/sample3.txt
			
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
    }
}
