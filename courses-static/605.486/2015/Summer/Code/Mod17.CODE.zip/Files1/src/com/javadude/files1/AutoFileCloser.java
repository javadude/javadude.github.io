package com.javadude.files1;

import java.io.Closeable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public abstract class AutoFileCloser {
	protected abstract void doWork() throws Throwable;
	private List<Closeable> closeables = new ArrayList<Closeable>();
	protected <T extends Closeable> T watch(T closeable) {
		closeables.add(0, closeable);
		return closeable;
	}
	public AutoFileCloser() {
        Throwable pending = null;
        try {
        	doWork();
        } catch (Throwable t) {
        	pending = t;
        } finally {
        	for (Closeable closeable : closeables) {
				try {
					closeable.close();
				} catch (IOException e) {
					if (pending == null)
						pending = e;
				}
			}
        	if (pending != null) {
        		if (pending instanceof RuntimeException)
        			throw  (RuntimeException) pending;
	        	if (pending instanceof Error)
	        		throw  (Error) pending;
	        	throw new RuntimeException(pending);
        	}
        }
	}
}
