/** Automatically generated file. DO NOT MODIFY */
package com.javadude.files1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}