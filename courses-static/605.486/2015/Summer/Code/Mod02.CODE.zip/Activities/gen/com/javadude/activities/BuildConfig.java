/** Automatically generated file. DO NOT MODIFY */
package com.javadude.activities;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}