package com.javadude.activities;

import android.os.Bundle;
import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

	private EditText name;
	private EditText phone;
	private EditText email;
	private Button pressMeButton;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d("LIFECYCLE", "onCreate");
		setContentView(R.layout.activity_main);
		name = (EditText) findViewById(R.id.name);
		phone = (EditText) findViewById(R.id.phone);
		email = (EditText) findViewById(R.id.email);
		pressMeButton = (Button) findViewById(R.id.pressMeButton);
		
		pressMeButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				Log.d("BUTTON", "onClick!!!");
			}});
		
		name.addTextChangedListener(new TextWatcher() {
			@Override public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
			@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			@Override public void afterTextChanged(Editable s) {
				Log.d("NAME", "change to " + s.toString());
			}
		});
		
		
		name.setText(String.valueOf(42));
		phone.setText("867-5309");
		email.setText("scott@javadude.com");
	}
	
	@Override
	protected void onDestroy() {
		Log.d("LIFECYCLE", "onDestroy");
		super.onDestroy();
	}
	@Override
	protected void onPause() {
		Log.d("LIFECYCLE", "onPause");
		String nameString = name.getText().toString();
		String phoneString = phone.getText().toString();
		String emailString = email.getText().toString();
		
		Log.d("DATA", "name=" + nameString);
		Log.d("DATA", "phone=" + phoneString);
		Log.d("DATA", "email=" + emailString);
		super.onPause();
	}
	@Override
	protected void onRestart() {
		super.onRestart();
		Log.d("LIFECYCLE", "onRestart");
	}
	@Override
	protected void onResume() {
		super.onResume();
		Log.d("LIFECYCLE", "onResume");
	}
	@Override
	protected void onStart() {
		super.onStart();
		Log.d("LIFECYCLE", "onStart");
	}
	@Override
	protected void onStop() {
		Log.d("LIFECYCLE", "onStop");
		super.onStop();
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
