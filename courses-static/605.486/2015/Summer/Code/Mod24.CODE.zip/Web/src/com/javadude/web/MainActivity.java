package com.javadude.web;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebStorage.QuotaUpdater;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
	@SuppressLint("SetJavaScriptEnabled")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = (WebView) findViewById(R.id.web1);
        // CAUTION!!! JavaScript can control the phone! Ensure ONLY your HTML can be displayed!
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new JavaScriptGlue(this, webView), "Android");
//        webView.loadUrl("file:///android_asset/html/test1.html");
        webView.loadUrl("file:///android_asset/html/db.html");
        if (Build.VERSION.SDK_INT >= VERSION_CODES.JELLY_BEAN) 
        	webView.getSettings().setAllowUniversalAccessFromFileURLs(true);

        // keep all links in app
        webView.setWebViewClient(new WebViewClient());
        
        webView.setWebChromeClient(new WebChromeClient() {
        	@Override
        	public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
        		Log.w("ALERT FROM JS", message);
        		webView.loadUrl("javascript:setMessage('ALERT!!!')");
        		return super.onJsAlert(view, url, message, result);
        	}
        	@Override
        	public void onExceededDatabaseQuota(String url, String databaseIdentifier, long quota, long estimatedDatabaseSize, long totalQuota, QuotaUpdater quotaUpdater) {
        		quotaUpdater.updateQuota(estimatedDatabaseSize * 2);
        	}

			@Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
				switch(consoleMessage.messageLevel()) {
					case DEBUG:
					case LOG:
						Log.d("JS CONSOLE", consoleMessage.lineNumber() + ": " + consoleMessage.message());
						break;
					case ERROR:
						Log.e("JS CONSOLE", consoleMessage.lineNumber() + ": " + consoleMessage.message());
						break;
					case TIP:
						Log.i("JS CONSOLE", consoleMessage.lineNumber() + ": " + consoleMessage.message());
						break;
					case WARNING:
						Log.w("JS CONSOLE", consoleMessage.lineNumber() + ": " + consoleMessage.message());
						break;
				}
				return true;
			}});
        
        // database setup
        webView.getSettings().setDatabaseEnabled(true);

        String databasePath = this.getApplicationContext().getDir("database", Context.MODE_PRIVATE).getPath();
        webView.getSettings().setDatabasePath(databasePath);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    @Override
    public void onBackPressed() {
    	if(webView.canGoBack())
    		webView.goBack();
    	else
    		super.onBackPressed();
    }
}
