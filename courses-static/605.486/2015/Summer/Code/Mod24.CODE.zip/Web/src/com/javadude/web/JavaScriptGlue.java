package com.javadude.web;

import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

public class JavaScriptGlue {
	private Context context;
	private final WebView webView;

	public JavaScriptGlue(Context context, WebView webView) {
		this.context = context;
		this.webView = webView;
	}

	@JavascriptInterface
	public void log(String message) {
		Log.d("FROM JAVASCRIPT", message);
	}

	@JavascriptInterface
	public void toast(String message) {
		Toast.makeText(context, message, Toast.LENGTH_LONG).show();
		((MainActivity)context).runOnUiThread(new Runnable() {
			@Override public void run() {
				webView.loadUrl("javascript:setMessage('toast in glue was called!')");
			}});
	}
}
