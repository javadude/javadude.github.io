/** Automatically generated file. DO NOT MODIFY */
package com.javadude.intents;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}