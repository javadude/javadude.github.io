package com.javadude.intents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.EditText;
import android.widget.TextView;

public class Activity4 extends Activity {

	private EditText moreStringData;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main4);
//		String stringData = getIntent().getStringExtra("stringData");
		Person person = (Person) getIntent().getSerializableExtra("person");
		
		TextView textView1 = (TextView) findViewById(R.id.textView1);
//		textView1.setText(stringData);
		textView1.setText(person.getName());

		moreStringData = (EditText) findViewById(R.id.moreStringData);
		
	}
	
	@Override
	public void onBackPressed() {
		Intent data = new Intent();
		data.putExtra("moreStringData", moreStringData.getText().toString());
		setResult(RESULT_OK, data);
		super.onBackPressed();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
