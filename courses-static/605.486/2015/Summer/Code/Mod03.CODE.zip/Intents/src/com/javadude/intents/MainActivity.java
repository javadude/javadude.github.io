package com.javadude.intents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {
	private static final int EDIT_REQUEST = 42;
	private EditText stringData;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		stringData = (EditText) findViewById(R.id.stringData);
	}

	public void goToActivity2(View view) {
		Intent intent = new Intent(this, Activity2.class);
		startActivity(intent);
		// do something else... SKILL EXECUTED
	}
	public void goToFunActivity(View view) {
		Intent intent = new Intent("com.javadude.fun.activity");
		startActivity(intent);
	}
	public void goToJavaDude(View view) {
		Intent intent = new Intent(Intent.ACTION_EDIT);
		intent.setType("application/vnd.javadude.data");
		intent.putExtra("stringData", stringData.getText().toString());
		startActivity(intent);
	}
	public void goToJavaDude2(View view) {
		Intent intent = new Intent(Intent.ACTION_EDIT);
		intent.setType("application/vnd.javadude.data");
		intent.putExtra("stringData", stringData.getText().toString());
		Person person = new Person();
		person.setName("Scott");
		intent.putExtra("person", person);
		
		startActivityForResult(intent, EDIT_REQUEST);
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == EDIT_REQUEST) {
			if (resultCode == RESULT_OK) {
				stringData.setText(data.getStringExtra("moreStringData"));
			}
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
