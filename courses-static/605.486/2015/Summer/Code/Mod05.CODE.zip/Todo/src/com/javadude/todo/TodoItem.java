package com.javadude.todo;

import java.io.Serializable;

public class TodoItem implements Serializable {
	private static final long serialVersionUID = 1L;
	private static int nextId = 1;
	private int id = nextId++;
	private String name;
	private String displayName;
	private int priority;
	
	public TodoItem(String name, String displayName, int priority) {
		this.name = name;
		this.displayName = displayName;
		this.priority = priority;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	@Override
	public String toString() {
		return "TodoItem [name=" + name + ", displayName=" + displayName
				+ ", priority=" + priority + "]";
	}
}
