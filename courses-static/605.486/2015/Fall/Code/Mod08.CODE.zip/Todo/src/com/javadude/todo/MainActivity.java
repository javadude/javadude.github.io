package com.javadude.todo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.javadude.todo.EditFragment.EditFragmentListener;
import com.javadude.todo.ListFragment.ListFragmentListener;

public class MainActivity extends ActionBarActivity {
	private EditFragment editFragment;
	private ListFragment listFragment;
//	private DisplayFragment displayFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		listFragment = (ListFragment) getSupportFragmentManager().findFragmentById(R.id.listFragment);
		editFragment = (EditFragment) getSupportFragmentManager().findFragmentById(R.id.editFragment);
//		displayFragment = (DisplayFragment) getSupportFragmentManager().findFragmentById(R.id.displayFragment);
		

		final boolean dualMode = editFragment != null && editFragment.isInLayout();
//		if (dualMode) {		
//			FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
//			transaction.hide(displayFragment);
//			transaction.commit();
//		}
		
		listFragment.setListFragmentListener(new ListFragmentListener() {
			@Override public void onEdit(long id) {
				if (dualMode) {
					editFragment.setTodoItemId(id);
				} else {
					Intent intent = new Intent(MainActivity.this, EditActivity.class);
					intent.putExtra("todoItemId", id);
					startActivity(intent);
				}
			}
			@Override public void onCreate() {
				if (dualMode) {
					editFragment.setTodoItemId(-1);
					
				} else {
					Intent intent = new Intent(MainActivity.this, EditActivity.class);
					intent.putExtra("todoItemId", (long) -1);
					startActivity(intent);
				}
			}
		});
		
		if (dualMode) {
			editFragment.setEditFragmentListener(new EditFragmentListener() {
				@Override public void onDone(TodoItem item) {
	//				FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
	//				transaction.hide(editFragment);
	//				transaction.show(displayFragment);
	//				transaction.commit();
	//				displayFragment.setTodoItemId(item.getId());
				}
				@Override public void onCancel() {
					editFragment.setTodoItemId(listFragment.getSelectedId());
					
					
					
	//				FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
	//				transaction.hide(editFragment);
	//				transaction.show(displayFragment);
	//				transaction.commit();
				}
			});
		}
	}
}

