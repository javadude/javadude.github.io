package com.javadude.todo;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class EditFragment extends Fragment {
	public interface EditFragmentListener {
		void onDone(TodoItem item);
		void onCancel();
	}

	private EditFragmentListener editFragmentListener;
	
	public void setEditFragmentListener(EditFragmentListener editFragmentListener) {
		this.editFragmentListener = editFragmentListener;
	}

	private TodoItem item;
	private EditText name;
	private EditText description;
	private EditText priority;
	
	public void setTodoItemId(long todoItemId) {
		if (todoItemId != -1) {
			item = TodoContentProvider.findTodo(getActivity(), todoItemId);            /*!!!!!!!!*/
		} else {
			item = new TodoItem("", "", 1);                                   /*!!!!!!!!*/
		}
			
		name.setText(item.getName());
		description.setText(item.getDisplayName());
		priority.setText(String.valueOf(item.getPriority()));
	}
	
	
	@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_edit, container, false);
		
		name = (EditText) view.findViewById(R.id.name);
		description = (EditText) view.findViewById(R.id.description);
		priority = (EditText) view.findViewById(R.id.priority);
			
		setHasOptionsMenu(true);
		return view;
	}
	
	@Override public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		// Inflate the menu; this adds items to the action bar if it is present.
		inflater.inflate(R.menu.edit, menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_cancel:
				if (editFragmentListener == null)
					throw new RuntimeException("You must set an EditFragmentListener");
				editFragmentListener.onCancel();
				return true;
			case R.id.action_done:
				this.item.setName(name.getText().toString());
				this.item.setDisplayName(description.getText().toString());
				this.item.setPriority(Integer.parseInt(priority.getText().toString()));
				
				TodoContentProvider.updateTodo(getActivity(), this.item);              /*!!!!!!!!*/
				if (editFragmentListener == null)
					throw new RuntimeException("You must set an EditFragmentListener");
				editFragmentListener.onDone(this.item);
				
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}

}
