package com.javadude.preferences;

import android.app.backup.BackupAgentHelper;
import android.app.backup.SharedPreferencesBackupHelper;

public class MyBackupAgent extends BackupAgentHelper {
    public void onCreate() {
    	String preferenceName = getPackageName() + "_preferences";
    		// wish we could just access PreferenceManager's getDefaultSharedPreferenceName...
        
    	SharedPreferencesBackupHelper helper =
                new SharedPreferencesBackupHelper(this, preferenceName);
        addHelper("myprefs", helper);
    }
}
