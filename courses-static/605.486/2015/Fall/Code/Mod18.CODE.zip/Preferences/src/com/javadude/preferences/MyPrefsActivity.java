package com.javadude.preferences;

import android.app.Activity;
import android.os.Bundle;

public class MyPrefsActivity extends Activity {
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getFragmentManager()
			.beginTransaction()
				.replace(android.R.id.content, new MyPrefsFragment())
				.commit();
	}
}
