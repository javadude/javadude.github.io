package com.javadude.preferences;

import java.util.Map;

import android.app.Activity;
import android.app.backup.BackupManager;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;

public class MyPrefsFragment extends PreferenceFragment {
	private OnSharedPreferenceChangeListener listener;
	private BackupManager backupManager;					// <-----

	@Override public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Load the preferences from an XML resource
		addPreferencesFromResource(R.xml.prefs);

		SharedPreferences preferences = getPreferenceManager().getSharedPreferences();
		Map<String, ?> all = preferences.getAll();
		for (String key : all.keySet()) {
			updateSummary(findPreference(key));
		}
		
		listener = new OnSharedPreferenceChangeListener() {
			@Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
				updateSummary(findPreference(key));
				backupManager.dataChanged();				// <-----
			}};
	}
	
	@Override public void onAttach(Activity activity) {		// <-----
		super.onAttach(activity);							// <-----
		backupManager = new BackupManager(activity);		// <-----
	}

	private void updateSummary(Preference preference) {
		if (preference instanceof ListPreference) {
			ListPreference listPref = (ListPreference) preference;
			preference.setSummary(listPref.getEntry());
		} else if (preference instanceof EditTextPreference) {
			EditTextPreference editTextPreference = (EditTextPreference) preference;
			preference.setSummary(editTextPreference.getText());
		}
	}
	
	@Override public void onPause() {
		super.onPause();
		getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(listener);
	}

	@Override public void onResume() {
		getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(listener);
		super.onResume();
	}
}
