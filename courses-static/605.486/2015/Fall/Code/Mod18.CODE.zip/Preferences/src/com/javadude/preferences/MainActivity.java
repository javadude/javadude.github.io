package com.javadude.preferences;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView userName;
	private TextView autoLogin;
	private TextView street;
	private TextView city;
	private TextView state;

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

//		// for activity or preference subsets
//		SharedPreferences preferences = getPreferences(MODE_PRIVATE);
//		// same as
//		// getSharedPreferences(getClass().getSimpleName(), MODE_PRIVATE);
//
//		// or for application-level preferences
//		// NOTE: THIS IS WHERE PreferenceFragments STORE PREFS!
//		SharedPreferences preferences2 = 
//				PreferenceManager.getDefaultSharedPreferences(this);
//
//		String name = preferences.getString("name", "nameless");
//
//		Editor editor = preferences.edit();
//		editor.putString("name", "Scott");
//		editor.commit();

		
		userName = (TextView) findViewById(R.id.userName);
		autoLogin = (TextView) findViewById(R.id.autoLogin);
		street = (TextView) findViewById(R.id.street);
		city = (TextView) findViewById(R.id.city);
		state = (TextView) findViewById(R.id.state);
	}

	@Override protected void onResume() {
		super.onResume();
		SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
		userName.setText(preferences.getString("userName", null));
		autoLogin.setText(preferences.getBoolean("autoLogin", false)?"TRUE":"FALSE");
		street.setText(preferences.getString("street", null));
		city.setText(preferences.getString("city", null));
		state.setText(preferences.getString("state", null));
	}
	
	@Override public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_settings:
				startActivity(new Intent(this, MyPrefsActivity.class));
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
}
