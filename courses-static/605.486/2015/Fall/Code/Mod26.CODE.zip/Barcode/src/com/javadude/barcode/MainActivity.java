package com.javadude.barcode;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	public void scanBarcode(View view) {
		IntentIntegrator integrator = new IntentIntegrator(this);
		integrator.initiateScan();		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		IntentResult scanResult = 
				IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
		if (scanResult != null) {
			String contents = scanResult.getContents();
			((TextView)findViewById(R.id.textView1)).setText(contents);
		}
		// else continue with any other code you need in the method
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
