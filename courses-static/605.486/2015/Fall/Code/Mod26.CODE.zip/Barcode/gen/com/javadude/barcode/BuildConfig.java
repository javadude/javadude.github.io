/** Automatically generated file. DO NOT MODIFY */
package com.javadude.barcode;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}