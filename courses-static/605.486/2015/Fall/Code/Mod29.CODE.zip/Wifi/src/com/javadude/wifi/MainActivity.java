package com.javadude.wifi;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	private Socket socket; // the socket over which we are communicating
	private DataOutputStream out; // the output stream
	private DataInputStream in; // the input stream
	private ReceiveThread receiveThread; // the thread that is receiving events

	private Button hello;
	private Button print;
	private Button connect;
	private EditText data;
	private EditText message;
	private EditText ipAddress;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hello = (Button) findViewById(R.id.hello);
        print = (Button) findViewById(R.id.print);
        connect = (Button) findViewById(R.id.connect);
        data = (EditText) findViewById(R.id.data);
        message = (EditText) findViewById(R.id.message);
        ipAddress = (EditText) findViewById(R.id.ipAddress);
        
        connect.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				new Thread() {
					@Override public void run() {
						try {
							socket = new Socket(ipAddress.getText().toString(), 4242);
							socket.setSoTimeout(500);
							in = new DataInputStream(socket.getInputStream());
							out = new DataOutputStream(socket.getOutputStream());
							receiveThread = new ReceiveThread();
							receiveThread.start();
						} catch (IOException e) {
							report("Error setting up socket", e);
						}
					}
				}.start();
			}});
        hello.setOnClickListener(new OnClickListener() {
        	@Override public void onClick(View v) {
        		send('h',null);
        	}});
        print.setOnClickListener(new OnClickListener() {
        	@Override public void onClick(View v) {
        		send('p', message.getText().toString());
        	}});
    }

    @Override protected void onStop() {
    	super.onStop();
    	if (receiveThread != null)
    		receiveThread.interrupt();
    }
    
    private void send(final char c, final String data) {
    	new Thread() {
    		@Override public void run() {
    			Socket s = null;
    			try {
    				Log.d("send", "sending " + c + " " + data);
    				report("sending " + c + " " + data);
    				out.writeChar(c);
    				if (c == 'p')
    					out.writeUTF(data);
    				out.flush();
    			} catch (Exception e) {
    				throw new RuntimeException(e);
    			} finally {
    				if (s != null) {
    					try {
    						s.close();
    					} catch (IOException e) {
    						report("close error", e);
    					}
    				}
    			}
    		}
    	}.start();
    }
    
	private void report(final String message, final Throwable t) {
		runOnUiThread(new Runnable() {
			@Override public void run() {
				data.append(message);
				data.append("\n");
				if (t != null) {
					StringWriter sw = new StringWriter();
					PrintWriter pw = new PrintWriter(sw);
					t.printStackTrace(pw);
					pw.close();
					data.append(sw.toString());
				}
			}});
	}
	
	private void report(String message) {
		report(message, null);
	}
	
	private class ReceiveThread extends Thread {
		public ReceiveThread() {
			super("Receive");
		}
		public void run() {
			try {
				while (!isInterrupted()) {
					// read an event from the stream
					try {
						char c = in.readChar();
						String s = null;
						if (c != 'x')
							s = in.readUTF();
						processReceivedEvent(c, s);
					} catch (SocketTimeoutException e) {
						continue;
					}
				}
				Log.d("client", "thread interrupted - cleaning up");
				send('x', null);
				in.readChar(); // ack
				cleanUp();
			} catch (ThreadDeath t) {
				throw t;
			} catch (Throwable t) {
				report("RECEIVE THREAD: error reading " + ipAddress.getText().toString(), t);
			}
		}
	}

	private synchronized void cleanUp() {
		if (in != null) {
			try {
				report("closing input stream");
				in.close(); 
				in = null;
			} catch (IOException e) {
				report("error closing input stream",e);
			}
		}
		if (out != null) {
			try {
				report("closing output stream");
				out.close();
				out = null;
			} catch (IOException e) {
				report("error closing output stream",e);
			}
		}
		if (socket != null) {
			try {
				report("closing socket");
				socket.close(); 
				socket = null;
			} catch (IOException e) {
				report("error closing socket",e);
			}
		}
	}

	private void processReceivedEvent(char c, String s) {
		report("received: " + c + ": " + s);
	}
}