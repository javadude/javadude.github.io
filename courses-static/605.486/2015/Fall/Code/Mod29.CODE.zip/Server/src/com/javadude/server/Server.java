package com.javadude.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class Server {
	public static void main(String[] args) {
		new Server().go();
	}
	public void go() {
		System.out.println(getLocalIP());
		AcceptThread acceptThread = new AcceptThread();
		acceptThread.start();
	}
	private String getLocalIP() {
		try {
			InetAddress inetAddress = InetAddress.getLocalHost();
			String ipAddress = inetAddress.getHostAddress();
			return ipAddress;
		} catch (UnknownHostException e) {
			;
		}

		//If the easy method didnt work, then do some extra work:
			try {
				Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
				for (NetworkInterface netint : Collections.list(nets)) {
					Enumeration<InetAddress> inetAddresses = netint.getInetAddresses();
					for (InetAddress inetAddress : Collections.list(inetAddresses)) {
						//Make sure its the IPv4 address, and also not 127.0.0.1
						if ( inetAddress.isLoopbackAddress() ) {
							continue;
						}
						//Lazy attempt at checking IPv4:
						String ip = inetAddress.toString();
						int len = ip.split("\\.").length;
						if (len != 4) {
							continue;
						}
						//On LINUX, the ip starts with slash such as /192.168.1.4
						if (ip.charAt(0) == '/' ) {
							ip = ip.substring(1);
						}
						return ip;
					}
				}
			} catch (SocketException e) {
				;
			}
			return "Could not detect IP";
	}
	private void report(String message, Throwable t) {
		System.err.println(message);
		t.printStackTrace();
	}
	private void report(String message) {
		System.out.println(message);
	}
	private class AcceptThread extends Thread {
		private List<SocketHandler> socketHandlers = new ArrayList<SocketHandler>();
		@Override public void run() {
			try {
				report("setting up server socket");
				// create a new ServerSocket on port 4242 to accept connections
				ServerSocket serverSocket = new ServerSocket(4242);
				try {
					report("server socket started");
		
					// listen forever (until an error occurs)
					while (!isInterrupted()) {
						// accept the incoming client connection
						report("accepting");
						
						// accept a connection
						Socket socket = serverSocket.accept();
						report("connection accepted");
						
						// hand the socket off to another thread so we can accept more incoming requests
						// note that the SocketHandler must register itself with this class (a SocketHandlerHolder) to avoid being collected
						SocketHandler socketHandler = new SocketHandler(this, socket);
						socketHandlers.add(socketHandler);
						socketHandler.start();
					}
				} finally {
					serverSocket.close();
				}
			} catch (ThreadDeath t) {
				throw t;
			} catch (Throwable t) {
				report("error accepting socket", t);
			}
		}
		public void removeSocketHandler(SocketHandler s) {
			socketHandlers.remove(s);
		}
	}
	
	private class SocketHandler {
		private Socket socket; // the socket over which we are communicating
		private DataOutputStream out; // the output stream
		private DataInputStream in; // the input stream
		private String remoteAddress; // the IP address of the remote side of the socket
		private SendThread sendThread = new SendThread(); // the thread that is sending events
		private ReceiveThread receiveThread = new ReceiveThread(); // the thread that is receiving events
		private final AcceptThread acceptThread; // holds a reference to this handler, so we can remove ourselves when closed
	
		/** constructor */
		public SocketHandler(AcceptThread socketHandlerHolder, Socket socket) {
			this.acceptThread = socketHandlerHolder;
			this.socket = socket;
			remoteAddress = socket.getRemoteSocketAddress().toString();
		}
		
		private void report(String message, Throwable t) {
			System.err.println("SOCKET HANDLER: " + message);
			t.printStackTrace();
		}
		private void report(String message) {
			System.out.println("SOCKET HANDLER: " + message);
		}
		
		/** start the threads */
		public void start() {
			try {
				out = new DataOutputStream(socket.getOutputStream());
				in = new DataInputStream(socket.getInputStream());
				receiveThread.start();
				sendThread.start();
			} catch (IOException e) {
				report("START: error getting input and/or output stream for " + remoteAddress, e);
			}
		}
	
		/** send an event via the send thread */
		public void send(char c, String stuff) {
			sendThread.send(c, stuff);
		}
		
		/**
		 * A thread that sends events on our behalf
		 * This thread will send events as long as the queue contains them, then wait for more data.
		 */
		private class SendThread extends Thread {
			private class Entry {
				private char c;
				private String stuff;
				public Entry(char c, String stuff) {
					this.c = c;
					this.stuff = stuff;
				}
				public char getC() { return c; }
				public String getStuff() { return stuff; }
			}
			private List<Entry> queue = new ArrayList<Entry>();
			
			public SendThread() {
				super("Send");
			}
			public synchronized void send(char c, String stuff) {
				queue.add(new Entry(c, stuff));
				notifyAll();
			}
			public void run() {
				while (!isInterrupted()) {
					try {
						synchronized (this) {
							if (queue.isEmpty()) {
								wait(); // wait until we're passed data
							}
						}
						Entry entry = queue.remove(0);
						out.writeChar(entry.getC());
						if (entry.getStuff() != null)
							out.writeUTF(entry.getStuff());
						out.flush();
					} catch (InterruptedException e) {
						interrupt();
					} catch (ThreadDeath t) {
						throw t;
					} catch (Throwable t) {
						report("SEND THREAD: error reading " + remoteAddress, t);
					}
				}
				cleanUp(this);
			}
		}
		
		/**
		 * A thread that receives events
		 */
		private class ReceiveThread extends Thread {
			public ReceiveThread() {
				super("Receive");
			}
			public void run() {
				try {
					while (!isInterrupted()) {
						// read an event from the stream
						char c = in.readChar();
						switch (c) {
							case 'h':
								System.out.println("got 'hello'");
								send(c, "Hello to you too!");
								break;
							case 'p':
								String s = in.readUTF();
								System.out.println(s);
								send(c, "Printed " + s);
								break;
							case 'x':
								send('y', null);
								interrupt();
								break;
						}
					}
					cleanUp(this);
				} catch (ThreadDeath t) {
					throw t;
				} catch (Throwable t) {
					report("RECEIVE THREAD: error reading " + remoteAddress, t);
				}
			}
		}
	
		private synchronized void cleanUp(Thread thread) {
			// stop the other thread
			if (thread == sendThread) {
				if (receiveThread != null) {
					report("initiate close from server side for " + remoteAddress);
					receiveThread.interrupt();
					receiveThread = null;
				}
			} else {
				if (sendThread != null) {
					report("initiate close from client side for " + remoteAddress);
					sendThread.interrupt();
					sendThread = null;
				}
			}
			acceptThread.removeSocketHandler(this);
			if (in != null) {
				try {
					report("closing input stream for " + remoteAddress);
					in.close(); 
					in = null;
				} catch (IOException e) {
					report("error closing input stream",e);
				}
			}
			if (out != null) {
				try {
					report("closing output stream for " + remoteAddress);
					out.close();
					out = null;
				} catch (IOException e) {
					report("error closing output stream",e);
				}
			}
			if (socket != null) {
				try {
					report("closing socket for " + remoteAddress);
					socket.close(); 
					socket = null;
				} catch (IOException e) {
					report("error closing socket",e);
				}
			}
		}
	}
}
