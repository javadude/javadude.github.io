/** Automatically generated file. DO NOT MODIFY */
package com.javadude.p2p;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}