package com.javadude.p2p;

import java.nio.charset.Charset;
import java.util.Locale;

import android.app.Activity;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.nfc.NfcEvent;
import android.os.Bundle;
import android.widget.EditText;

public class MainActivity extends Activity {

	private EditText editText;

	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		editText = (EditText) findViewById(R.id.editText1);
	}
	@Override
	protected void onResume() {
		super.onResume();
		// needed pre-honeycomb
//		NfcAdapter.getDefaultAdapter(this).enableForegroundNdefPush(this, messageToPush);
//		NdefMessage messageToPush = new NdefMessage(new NdefRecord[] {createText("Foo!")});
//		NfcAdapter.getDefaultAdapter(this).setNdefPushMessage(messageToPush, this);
		NfcAdapter.getDefaultAdapter(this).setNdefPushMessageCallback(new CreateNdefMessageCallback() {
			@Override public NdefMessage createNdefMessage(NfcEvent event) {
				return new NdefMessage(new NdefRecord[] {createText(editText.getText().toString())});
			}
		}, this);
	}

	// needed pre-honeycomb
//	@Override
//	protected void onPause() {
//		NfcAdapter.getDefaultAdapter(this).disableForegroundNdefPush(this);
//		super.onPause();
//	}
	
	private NdefRecord createText(String string) {
		byte[] language = Locale.getDefault().getLanguage().getBytes(Charset.forName("US-ASCII"));
		Charset utf16 = Charset.forName("UTF-16");
		byte[] text = string.getBytes(utf16);
		int utf = 1 << 7;
		byte[] data = new byte[1+language.length + text.length];
		data[0] = (byte) (utf + language.length);
		System.arraycopy(language, 0, data, 1, language.length);
		System.arraycopy(text, 0, data, 1 + language.length, text.length);
		return new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], data);
	}
}
