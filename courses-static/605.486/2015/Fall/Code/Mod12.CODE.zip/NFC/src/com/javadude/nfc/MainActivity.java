package com.javadude.nfc;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Locale;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private TextView textView;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textView = (TextView) findViewById(R.id.textView1);
		writeTextButton = (Button) findViewById(R.id.writeTextButton);
		writeURIButton = (Button) findViewById(R.id.writeURIButton);
		writeURIButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
//				NdefRecord record2 = NdefRecord.createUri("http://javadude.com/fee");
				byte[] uriBytes = "javadude.com/fee".getBytes(Charset.forName("US-ASCII"));
				byte[] payload = new byte[uriBytes.length + 1];
				payload[0] = 0x01; // prefix: 01 = "http://www.", 02 = "https://www.", 03="http://" ...
				System.arraycopy(uriBytes, 0, payload, 1, uriBytes.length);
				NdefRecord record = new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_URI, NO_ID, payload);
				messageToWrite = new NdefMessage(new NdefRecord[] {record});
				enableWrite();
		        Toast.makeText(MainActivity.this, "Touch tag to write", Toast.LENGTH_SHORT).show();
			}});
		writeTextButton.setOnClickListener(new OnClickListener() {
			@Override public void onClick(View v) {
				byte[] language = Locale.getDefault().getLanguage().getBytes(Charset.forName("US-ASCII"));
				Charset utf16 = Charset.forName("UTF-16");
				byte[] text = "This is a message".getBytes(utf16);
				int utf = 1 << 7;
				byte[] data = new byte[1+language.length + text.length];
				data[0] = (byte) (utf + language.length);
				System.arraycopy(language, 0, data, 1, language.length);
				System.arraycopy(text, 0, data, 1 + language.length, text.length);
				NdefRecord record = new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], data);
				messageToWrite = new NdefMessage(new NdefRecord[] {record});
				enableWrite();
				Toast.makeText(MainActivity.this, "Touch tag to write", Toast.LENGTH_SHORT).show();
			}});
		
		try {
			pendingIntent = PendingIntent.getActivity(
				    this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
			IntentFilter ndefJavaDudeDiscovered = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
			ndefJavaDudeDiscovered.addDataScheme("http");
			ndefJavaDudeDiscovered.addDataAuthority("www.javadude.com", null);

			IntentFilter ndefTextDiscovered = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED, "text/plain");
			readFilters = new IntentFilter[] { ndefJavaDudeDiscovered, ndefTextDiscovered };
			IntentFilter tagDiscovered = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
			writeFilters = new IntentFilter[] { tagDiscovered };
		} catch (MalformedMimeTypeException e) {
			throw new RuntimeException(e);
		}
		
		processNFC(getIntent());
	}

	private IntentFilter[] writeFilters; 
	private Button writeTextButton;
	private Button writeURIButton;
	private NdefMessage messageToWrite;
	private static byte[] NO_ID = new byte[0];
	private PendingIntent pendingIntent;
	private IntentFilter[] readFilters; 
	@Override
	protected void onPause() {
		super.onPause();
		disable();
	}
	@Override
	protected void onResume() {
		super.onResume();
		if (messageToWrite != null)
			enableWrite();
		else
			enableRead();
	}
	
	private void enableRead() {
		NfcAdapter.getDefaultAdapter(this).enableForegroundDispatch(this, pendingIntent, readFilters, null);
	}
	private void enableWrite() {
		NfcAdapter.getDefaultAdapter(this).enableForegroundDispatch(this, pendingIntent, writeFilters, null);
	}
	private void disable() {
		NfcAdapter.getDefaultAdapter(this).disableForegroundDispatch(this);
	}
	
	
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		processNFC(intent);
	}

	private void processNFC(Intent intent) {
		if (messageToWrite != null) {
			if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())
				||NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())) {
				writeTag(intent);
			}
		} else {
			if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
				readTag(intent);
			}
		}
	}
	private void writeTag(Intent intent) {
        Tag tag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        Ndef ndef = Ndef.get(tag);
        if (ndef != null) {
            try {
				ndef.connect();
				// should check if writeable and has enough space

				ndef.writeNdefMessage(messageToWrite);
				messageToWrite = null;
				Toast.makeText(MainActivity.this, "Wrote tag!", Toast.LENGTH_SHORT).show();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
        }
		messageToWrite = null;
	}


	private void readTag(Intent intent) {
		Parcelable[] messages = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
		if (messages != null) {
			for (Parcelable message : messages) {
				NdefMessage ndefMessage = (NdefMessage) message;
				NdefRecord[] records = ndefMessage.getRecords();
				textView.setText("");
				for (NdefRecord record : records) {
					switch (record.getTnf()) {
						case NdefRecord.TNF_WELL_KNOWN:
							textView.append("TNF_WELL_KNOWN\n");
							if (Arrays.equals(record.getType(), NdefRecord.RTD_URI)) {
								textView.append("  URI: ");
								textView.append(new String(record.getPayload()));
								textView.append("\n");
							} else if (Arrays.equals(record.getType(), NdefRecord.RTD_TEXT)) {
								textView.append("  TEXT: ");
								textView.append(new String(record.getPayload())); // includes encoding and language info in first few bytes
								textView.append("\n");
							}
							break;
						case NdefRecord.TNF_ABSOLUTE_URI:
							textView.append("TNF_ABSOLUTE_URI\n");
							break;
						case NdefRecord.TNF_EMPTY:
							textView.append("TNF_EMPTY\n");
							break;
						case NdefRecord.TNF_EXTERNAL_TYPE:
							textView.append("TNF_EXTERNAL_TYPE\n");
							textView.append("  ID: ");
							textView.append(new String(record.getId()));
							textView.append("\n");
							textView.append("  TYPE: ");
							textView.append(new String(record.getType()));
							textView.append("\n");
							textView.append("  PAYLOAD: ");
							textView.append(new String(record.getPayload()));
							textView.append("\n");
							break;
						case NdefRecord.TNF_MIME_MEDIA:
							textView.append("TNF_MIME_MEDIA\n");
							break;
						case NdefRecord.TNF_UNCHANGED:
							textView.append("TNF_UNCHANGED\n");
							break;
						case NdefRecord.TNF_UNKNOWN:
							textView.append("TNF_UNKNOWN\n");
							break;
					}
				}
			}
		}
	}
}
