/** Automatically generated file. DO NOT MODIFY */
package com.javadude.nfc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}