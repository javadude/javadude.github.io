package com.javadude.navigation;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

// most of this code is from http://developer.android.com/training/implementing-navigation/nav-drawer.html 
public class NavDrawerActivity extends ActionBarActivity {

	private String[] hubs = {"Home", "Albums", "Playlist", "Now Playing"};
	private int[] icons = {
			R.drawable.ic_action_home,  
			R.drawable.ic_action_albums,  
			R.drawable.ic_action_playlist,  
			R.drawable.ic_action_now_playing  
	};
	private Fragment[] fragments = {
			new HomeFragment(),
			new AlbumsFragment(),
			new PlaylistFragment(),
			new NowPlayingFragment()
	};
	private int selectedFragment;
	private DrawerLayout drawerLayout;
	private ListView drawerList;
	private ActionBarDrawerToggle drawerToggle;
	
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_nav_drawer);

        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setHomeButtonEnabled(true);
        
		drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		drawerList = (ListView) findViewById(R.id.left_drawer);

		// Set the adapter for the list view
		drawerList.setAdapter(new DrawerAdapter(icons, hubs));
        
		drawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);

		// Set the list's click listener
		drawerList.setOnItemClickListener(new OnItemClickListener() {
			@Override public void onItemClick(AdapterView<?> list, View view, int position, long id) {
				selectItem(position);
			}});
		
		drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
				R.drawable.ic_drawer, R.string.drawer_open, R.string.drawer_close) {

			/** Called when a drawer has settled in a completely closed state. */
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(hubs[selectedFragment]);
				invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
			}

			/** Called when a drawer has settled in a completely open state. */
			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(hubs[selectedFragment]);
				invalidateOptionsMenu(); // creates call to onPrepareOptionsMenu()
			}
		};

        // Set the drawer toggle as the DrawerListener
        drawerLayout.setDrawerListener(drawerToggle);
		
		selectItem(0);
	}

	/** Swaps fragments in the main content view */
	private void selectItem(int position) {
		selectedFragment = position;
		
		// Insert the fragment by replacing any existing fragment
		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction()
			.replace(R.id.content_frame, fragments[position])
			.commit();

		// Highlight the selected item, update the title, and close the drawer
		drawerList.setItemChecked(position, true);
		setTitle(hubs[selectedFragment]);
		drawerLayout.closeDrawer(drawerList);
	}

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Pass any configuration change to the drawer toggls
        drawerToggle.onConfigurationChanged(newConfig);
    }
    
    /* Called whenever we call invalidateOptionsMenu() */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // If the nav drawer is open, hide action items related to the content view
        boolean drawerOpen = drawerLayout.isDrawerOpen(drawerList);
        menu.findItem(R.id.action_edit).setVisible(!drawerOpen);
        return super.onPrepareOptionsMenu(menu);
    }	
	
	@Override
	public void setTitle(CharSequence title) {
		getActionBar().setTitle(title);
	}

	@Override public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.nav, menu);
		return true;
	}
	
	private class DrawerAdapter extends BaseAdapter {
		private int[] icons;
		private String[] titles;

		public DrawerAdapter(int[] icons, String[] titles) {
			this.icons = icons;
			this.titles = titles;
		}

		@Override public int getCount() {
			return icons.length;
		}

		@Override public Object getItem(int position) {
			return titles[position];
		}

		@Override public long getItemId(int position) {
			return position;
		}

		@Override public View getView(int position, View convertView, ViewGroup parent) {
			TextView textView = (TextView) convertView;
			if (textView == null) {
				textView = (TextView) getLayoutInflater().inflate(R.layout.drawer_item, null);
			}
			textView.setText(titles[position]);
			Drawable drawable = getResources().getDrawable(icons[position]);
			int intrinsicWidth = drawable.getIntrinsicWidth();
			int intrinsicHeight = drawable.getIntrinsicHeight();
			drawable.setBounds(0,0,intrinsicWidth, intrinsicHeight);
			textView.setCompoundDrawables(drawable, null, null, null);
			return textView;
		}
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// The action bar home/up action should open or close the drawer.
		// ActionBarDrawerToggle will take care of this.
		if (drawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action buttons
		switch(item.getItemId()) {
			// handle buttons as normal
			// ...
			default:
				return super.onOptionsItemSelected(item);
		}
	}

	//------------------------------------------
	// FRAGMENTS
	//------------------------------------------
	public static class HomeFragment extends Fragment {
		@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			return inflater.inflate(R.layout.home_fragment, container, false);
		}
	};
	public static class AlbumsFragment extends Fragment {
		@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			return inflater.inflate(R.layout.albums_fragment, container, false);
		}
	};
	public static class PlaylistFragment extends Fragment {
		@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			return inflater.inflate(R.layout.playlist_fragment, container, false);
		}
	};
	public static class NowPlayingFragment extends Fragment {
		@Override public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
			return inflater.inflate(R.layout.now_playing_fragment, container, false);
		}
	};
}
