package com.javadude.todo;

import android.os.Parcel;
import android.os.Parcelable;

public class TodoItem implements Parcelable {
	private static int nextId = 1;
	private int id;
	private String name;
	private String displayName;
	private int priority;
	
	public TodoItem(String name, String displayName, int priority) {
		this.id = nextId++;
		this.name = name;
		this.displayName = displayName;
		this.priority = priority;
	}
	private TodoItem(int id, String name, String displayName, int priority) {
		this.id = id;
		this.name = name;
		this.displayName = displayName;
		this.priority = priority;
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	@Override
	public String toString() {
		return "TodoItem [name=" + name + ", displayName=" + displayName
				+ ", priority=" + priority + "]";
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(id);
		dest.writeString(name);
		dest.writeString(displayName);
		dest.writeInt(priority);
	}
	
	public static Parcelable.Creator<TodoItem> CREATOR = new Creator<TodoItem>() {
		@Override public TodoItem[] newArray(int size) {
			return new TodoItem[size];
		}
		@Override public TodoItem createFromParcel(Parcel source) {
			int id = source.readInt();
			String name = source.readString();
			String displayName = source.readString();
			int priority = source.readInt();
			return new TodoItem(id, name, displayName, priority);
		}
	};
}
