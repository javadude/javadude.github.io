package com.javadude.todo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public class MainActivity extends ActionBarActivity {
	private static final int NEW_REQUEST = 42;
	private static final int EDIT_REQUEST = 43;
	private TodoList todoList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ListView listView = (ListView) findViewById(R.id.listView1);
		
		if (savedInstanceState == null) {
			todoList = new TodoList();
			todoList.add(new TodoItem("Wash Car", "Wash the car really well", 2));
			todoList.add(new TodoItem("Wash Cat", "Watch the claws", 15));
			todoList.add(new TodoItem("Fix the garage door", "The door has never worked. Fix it", 3));
			todoList.add(new TodoItem("Something Else", "Blah Blah Blah Blah Blah Blah Blah ", 8));
		} else {
			todoList = savedInstanceState.getParcelable("todoList");
		}
		listView.setAdapter(new TodoListAdapter2(todoList, getLayoutInflater()));
	
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.d("List", "Clicked " + position);
				TodoItem todoItem = todoList.get(position);
				Log.d("List", "Clicked " + todoItem);
				
				Intent intent = new Intent(MainActivity.this, EditActivity.class);
				intent.putExtra("todoItem", todoItem);
				startActivityForResult(intent, NEW_REQUEST);
			}
		});
	}
	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		// save our todolist
		outState.putParcelable("todoList", todoList);
	}
	private int n = 42;
	public void addItem(View view) {
		TodoItem newItem = new TodoItem("New" + n, "Display" + n, n);
		n++;
		todoList.add(newItem);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()) {
			case R.id.action_new:
				// bring up the edit activity
				Intent intent = new Intent(this, EditActivity.class);
				intent.putExtra("todoItem", new TodoItem("", "", 1));
				startActivityForResult(intent, NEW_REQUEST);
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode == RESULT_CANCELED)
			return;
		
		switch(requestCode) {
			case NEW_REQUEST:
			case EDIT_REQUEST:
				TodoItem item = (TodoItem) data.getParcelableExtra("todoItem");
				todoList.merge(item);
				break;
			default:
				super.onActivityResult(requestCode, resultCode, data);
				break;
		}
	}
	
}
