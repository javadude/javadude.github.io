package com.javadude.todo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.javadude.todo.TodoList.ChangeListener;

public class TodoListAdapter2 extends BaseAdapter {
	private TodoList todoList;
	private LayoutInflater layoutInflater;
	
	public TodoListAdapter2(TodoList todoList, LayoutInflater layoutInflater) {
		this.todoList = todoList;
		this.layoutInflater = layoutInflater;
		
		todoList.addChangeListener(new ChangeListener() {
			@Override public void changed() {
				notifyDataSetChanged();
			}
		});
	}

	@Override
	public int getCount() {
		return todoList.size();
	}

	@Override
	public Object getItem(int position) {
		return todoList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	
	private class ViewHolder {
		private TextView text1;
		private TextView text2;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder viewHolder;
		if (convertView == null) {
			if (position % 2 == 0)
				convertView = layoutInflater.inflate(R.layout.even, null);
			else
				convertView = layoutInflater.inflate(R.layout.odd, null);
			viewHolder = new ViewHolder();
			viewHolder.text1 = (TextView) convertView.findViewById(R.id.text1);
			viewHolder.text2 = (TextView) convertView.findViewById(R.id.text2);
			convertView.setTag(viewHolder);
		} else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		
		TodoItem todoItem = (TodoItem) getItem(position);
		viewHolder.text1.setText(todoItem.getName());
		viewHolder.text2.setText(String.valueOf(todoItem.getPriority()));

		return convertView;
	}

	@Override
	public int getItemViewType(int position) {
		return position % 2;
	}

	@Override
	public int getViewTypeCount() {
		return 2;
	}

	@Override
	public boolean isEmpty() {
		return todoList.size() == 0;
	}

	@Override
	public boolean areAllItemsEnabled() {
		return true;
	}

	@Override
	public boolean isEnabled(int position) {
		return true;
	}
}
