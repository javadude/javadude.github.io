package com.javadude.todo;

import java.util.ArrayList;
import java.util.List;

import android.os.Parcel;
import android.os.Parcelable;

public class TodoList implements Parcelable {
	public interface ChangeListener {
		void changed();
	}
	private List<ChangeListener> listeners = new ArrayList<ChangeListener>();
	private List<TodoItem> items = new ArrayList<TodoItem>();

	public void addChangeListener(ChangeListener changeListener) {
		listeners.add(changeListener);
	}
	public void removeChangeListener(ChangeListener changeListener) {
		listeners.remove(changeListener);
	}

	public void merge(TodoItem item) {
		boolean found = false;
		for (TodoItem itemInList : items) {
			if (itemInList.getId() == item.getId()) {
				itemInList.setDisplayName(item.getDisplayName());
				itemInList.setName(item.getName());
				itemInList.setPriority(item.getPriority());
				found = true;
				break;
			}
		}
		if (!found)
			items.add(item);
		for (ChangeListener changeListener : listeners) {
			changeListener.changed();
		}
	}
	public boolean add(TodoItem object) {
		boolean added = items.add(object);
		for (ChangeListener changeListener : listeners) {
			changeListener.changed();
		}
		return added;
	}

	public TodoItem get(int location) {
		return items.get(location);
	}

	public TodoItem remove(int location) {
		TodoItem removed = items.remove(location);
		for (ChangeListener changeListener : listeners) {
			changeListener.changed();
		}
		return removed;
	}

	public int size() {
		return items.size();
	}

	@Override
	public String toString() {
		return "TodoList [items=" + items + "]";
	}
	@Override
	public int describeContents() {
		return 0;
	}
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(items.size());
		for (TodoItem item : items) {
			dest.writeParcelable(item, 0);
		}
	}
	
	public static Parcelable.Creator<TodoList> CREATOR = new Creator<TodoList>() {
		@Override public TodoList[] newArray(int size) {
			return new TodoList[size];
		}
		
		@Override public TodoList createFromParcel(Parcel source) {
			TodoList list = new TodoList();
			int size = source.readInt();
			for(int i = 0; i < size; i++) {
				TodoItem item = source.readParcelable(getClass().getClassLoader());
				list.add(item);
			}
			return list;
		}
	};
}
