package com.javadude.shapeeditor;

import android.graphics.RectF;

public class Thing {
	private RectF bounds = new RectF();
	private Type type;
	public static enum Type {
		Square, Circle, Triangle;
	}
	public Thing(Type type) {
		this.type = type;
	}
	public RectF getBounds() {
		return bounds;
	}
	public Type getType() {
		return type;
	}
}
