package com.javadude.shapeeditor;

import java.util.ArrayList;
import java.util.List;

import com.javadude.shapeeditor.Thing.Type;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;

public class MainActivity extends Activity {
	private static enum Mode {
		DrawCircle,
		DrawSquare,
		DrawTriangle,
		Select,
		ChooseEnd1,
		ChooseEnd2
	}
	private ShapeDrawable triangle;
	private Drawable square;
	private Drawable circle;
	private Mode mode = Mode.Select;
	
	@Override protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		square = getResources().getDrawable(R.drawable.square);
		circle = getResources().getDrawable(R.drawable.circle);
		
		ImageButton triangleButton = (ImageButton) findViewById(R.id.triangeButton);
		int shapeSize = (int) getResources().getDimension(R.dimen.shape_size);
		float strokeSize = getResources().getDimension(R.dimen.stroke_size);
		triangle = new ShapeDrawable(new Triangle(strokeSize));
		triangle.setIntrinsicWidth(shapeSize);
		triangle.setIntrinsicHeight(shapeSize);
		triangleButton.setImageDrawable(triangle);

		triangle = new ShapeDrawable(new Triangle(strokeSize));
		triangle.setIntrinsicWidth(shapeSize);
		triangle.setIntrinsicHeight(shapeSize);
		
		ViewGroup main = (ViewGroup) findViewById(R.id.main);
		DrawingView drawingView = new DrawingView(this);
		LinearLayout.LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1);
		drawingView.setLayoutParams(params);
		main.addView(drawingView);
	}

	public void squarePressed(View view) {mode = Mode.DrawSquare;}
	public void circlePressed(View view) {mode = Mode.DrawCircle;}
	public void trianglePressed(View view) {mode = Mode.DrawTriangle;}
	public void selectPressed(View view) {mode = Mode.Select;}
	public void linePressed(View view) {mode = Mode.ChooseEnd1;}
	
	@Override public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private class DrawingView extends View {
		private List<Thing> things = new ArrayList<Thing>();
		private List<Line> lines = new ArrayList<Line>();
		private Paint paint;
		private Rect rect = new Rect();
		private Thing thing1;
		private Thing thing2;
		private Thing selected;
		private float selectionOffsetX = 0;
		private float selectionOffsetY = 0;
		
		public DrawingView(Context context, AttributeSet attrs, int defStyle) {
			super(context, attrs, defStyle);
		}
		public DrawingView(Context context, AttributeSet attrs) {
			super(context, attrs);
		}
		public DrawingView(Context context) {
			super(context);
		}
		private void init() {
			paint = new Paint();
			paint.setColor(Color.DKGRAY);
		}
		
		@Override public boolean onTouchEvent(MotionEvent event) {
			Thing thing = null;
			Drawable drawable = null;
			switch(event.getAction()) {
				case MotionEvent.ACTION_MOVE:
					if (selected != null) {
						RectF bounds = selected.getBounds();
						float width = bounds.right - bounds.left;
						float height = bounds.bottom - bounds.top;
						bounds.set(
								event.getX() - selectionOffsetX,
								event.getY() - selectionOffsetY, 
								event.getX() - selectionOffsetX + width, 
								event.getY() - selectionOffsetY + height);
						invalidate();
					}
					break;
				case MotionEvent.ACTION_UP:
					selected = null;
					break;
				case MotionEvent.ACTION_DOWN:
					switch(mode) {
						case DrawCircle:
							thing = new Thing(Type.Circle);
							drawable = circle;
							break;
						case DrawSquare:
							thing = new Thing(Type.Square);
							drawable = square;
							break;
						case DrawTriangle:
							thing = new Thing(Type.Triangle);
							drawable = triangle;
							break;
						case ChooseEnd1:
							thing1 = findThingAt(event.getX(), event.getY());
							if (thing1 != null) {
								mode = Mode.ChooseEnd2;
							}
							break;
						case ChooseEnd2:
							thing2 = findThingAt(event.getX(), event.getY());
							if (thing2 != null) {
								Line line = new Line(thing1, thing2);
								lines.add(line);
								thing1 = thing2 = null;
								mode = Mode.ChooseEnd1;
								invalidate();
							}
							break;
						case Select:
							selected = findThingAt(event.getX(), event.getY());
							if (selected != null) {
								RectF bounds = selected.getBounds();
								selectionOffsetX = event.getX() - bounds.left; 
								selectionOffsetY = event.getY() - bounds.top; 
							}
							break;
						default:
							break;
					}
			}
			
			if (drawable != null) {
				thing.getBounds().set(
						event.getX() - drawable.getIntrinsicWidth()/2,
						event.getY() - drawable.getIntrinsicHeight()/2,
						event.getX() + drawable.getIntrinsicWidth()/2,
						event.getY() + drawable.getIntrinsicHeight()/2
						);
				things.add(thing);
				invalidate();
				return true;
			}			
			return true;
		}
		
		private Thing findThingAt(float x, float y) {
			for(int i = things.size()-1; i >=0; i--) {
				Thing thing = things.get(i);
				if (thing.getBounds().contains(x, y)) {
					return thing;
				}
			}
			return null;
		}
		@Override protected void onDraw(Canvas canvas) {
			if (paint == null)
				init();
			for (Line line : lines) {
				RectF bounds1 = line.getThing1().getBounds();
				RectF bounds2 = line.getThing2().getBounds();
				canvas.drawLine(
						bounds1.centerX(), bounds1.centerY(),
						bounds2.centerX(), bounds2.centerY(),
						paint);
			}
			for (Thing thing : things) {
				switch(thing.getType()) {
					case Circle:
						thing.getBounds().round(rect);
						circle.setBounds(rect);
						circle.draw(canvas);
						break;
					case Square:
						thing.getBounds().round(rect);
						square.setBounds(rect);
						square.draw(canvas);
						break;
					case Triangle:
						thing.getBounds().round(rect);
						triangle.setBounds(rect);
						triangle.draw(canvas);
						break;
					default:
						break;
				}
			}
		}
	}

}
