package com.javadude.shapeeditor;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.drawable.shapes.Shape;

public class Triangle extends Shape {
	private float strokeSize;
	private Path path;
	
	public Triangle(float strokeSize) {
		this.strokeSize = strokeSize;
	}

	@Override protected void onResize(float width, float height) {
		super.onResize(width, height);
		path = new Path();
		path.moveTo(width/2, 0);
		path.lineTo(0, height);
		path.lineTo(width, height);
		path.close();
	}
	
	@Override public void draw(Canvas canvas, Paint paint) {
		paint.setColor(Color.RED);
		paint.setStyle(Style.FILL);
		canvas.drawPath(path, paint);
		
		paint.setColor(Color.BLACK);
		paint.setStyle(Style.STROKE);
		paint.setStrokeWidth(strokeSize);
		canvas.drawPath(path, paint);
	}
}
