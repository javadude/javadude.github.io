package com.javadude.shapeeditor;

public class Line {
	private Thing thing1;
	private Thing thing2;
	public Line(Thing thing1, Thing thing2) {
		this.thing1 = thing1;
		this.thing2 = thing2;
	}
	public Thing getThing1() {
		return thing1;
	}
	public Thing getThing2() {
		return thing2;
	}
}
