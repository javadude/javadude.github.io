/** Automatically generated file. DO NOT MODIFY */
package com.javadude.shapeeditor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}